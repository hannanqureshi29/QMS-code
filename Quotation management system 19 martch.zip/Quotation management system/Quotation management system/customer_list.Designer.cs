﻿
namespace Quotation_management_system
{
    partial class customer_list
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Customer_List_Table = new System.Windows.Forms.DataGridView();
            this.btnaddproduct = new System.Windows.Forms.Button();
            this.lblproductlist = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_time = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.user_logged = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.txt_search_customer = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_List_Table)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Customer_List_Table
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.Customer_List_Table.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.Customer_List_Table.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Customer_List_Table.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Customer_List_Table.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.Customer_List_Table.ColumnHeadersHeight = 55;
            this.Customer_List_Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.Customer_List_Table.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Customer_List_Table.Location = new System.Drawing.Point(0, 209);
            this.Customer_List_Table.Name = "Customer_List_Table";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.Customer_List_Table.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.Customer_List_Table.Size = new System.Drawing.Size(1412, 620);
            this.Customer_List_Table.TabIndex = 17;
            // 
            // btnaddproduct
            // 
            this.btnaddproduct.BackColor = System.Drawing.Color.DarkCyan;
            this.btnaddproduct.FlatAppearance.BorderSize = 0;
            this.btnaddproduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnaddproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.btnaddproduct.ForeColor = System.Drawing.Color.White;
            this.btnaddproduct.Location = new System.Drawing.Point(1076, 94);
            this.btnaddproduct.Name = "btnaddproduct";
            this.btnaddproduct.Size = new System.Drawing.Size(336, 67);
            this.btnaddproduct.TabIndex = 20;
            this.btnaddproduct.Text = "Add New Customer";
            this.btnaddproduct.UseVisualStyleBackColor = false;
            this.btnaddproduct.Click += new System.EventHandler(this.btnaddproduct_Click);
            // 
            // lblproductlist
            // 
            this.lblproductlist.AutoSize = true;
            this.lblproductlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblproductlist.ForeColor = System.Drawing.Color.White;
            this.lblproductlist.Location = new System.Drawing.Point(721, 9);
            this.lblproductlist.Name = "lblproductlist";
            this.lblproductlist.Size = new System.Drawing.Size(141, 26);
            this.lblproductlist.TabIndex = 19;
            this.lblproductlist.Text = "CustomerList";
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.ForeColor = System.Drawing.Color.White;
            this.lbl_date.Location = new System.Drawing.Point(6, 13);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(63, 29);
            this.lbl_date.TabIndex = 23;
            this.lbl_date.Text = "Date";
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lbl_time.ForeColor = System.Drawing.Color.White;
            this.lbl_time.Location = new System.Drawing.Point(173, 11);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(69, 29);
            this.lbl_time.TabIndex = 24;
            this.lbl_time.Text = "Time";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.user_logged);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.lblproductlist);
            this.panel1.Controls.Add(this.lbl_date);
            this.panel1.Controls.Add(this.lbl_time);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1582, 50);
            this.panel1.TabIndex = 25;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // user_logged
            // 
            this.user_logged.AutoSize = true;
            this.user_logged.Font = new System.Drawing.Font("Arial", 15.75F);
            this.user_logged.ForeColor = System.Drawing.Color.White;
            this.user_logged.Location = new System.Drawing.Point(1260, 9);
            this.user_logged.Name = "user_logged";
            this.user_logged.Size = new System.Drawing.Size(152, 24);
            this.user_logged.TabIndex = 28;
            this.user_logged.Text = "user_logged_in";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 15.75F);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(1203, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 24);
            this.label12.TabIndex = 27;
            this.label12.Text = "User:";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // txt_search_customer
            // 
            this.txt_search_customer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_search_customer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_search_customer.BackColor = System.Drawing.Color.White;
            this.txt_search_customer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search_customer.ForeColor = System.Drawing.Color.Black;
            this.txt_search_customer.Location = new System.Drawing.Point(965, 167);
            this.txt_search_customer.MaxLength = 15;
            this.txt_search_customer.Name = "txt_search_customer";
            this.txt_search_customer.Size = new System.Drawing.Size(447, 26);
            this.txt_search_customer.TabIndex = 26;
            this.txt_search_customer.Text = "Search Customer";
            this.txt_search_customer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_search_customer.TextChanged += new System.EventHandler(this.txt_search_quot_TextChanged);
            this.txt_search_customer.Enter += new System.EventHandler(this.txt_search_quot_Enter);
            this.txt_search_customer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_search_quot_KeyDown);
            this.txt_search_customer.Leave += new System.EventHandler(this.txt_search_quot_Leave);
            // 
            // customer_list
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(1424, 841);
            this.Controls.Add(this.txt_search_customer);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnaddproduct);
            this.Controls.Add(this.Customer_List_Table);
            this.Name = "customer_list";
            this.Text = "customer_list";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.customer_list_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Customer_List_Table)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Customer_List_Table;
        private System.Windows.Forms.Button btnaddproduct;
        private System.Windows.Forms.Label lblproductlist;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txt_search_customer;
        public System.Windows.Forms.Label user_logged;
        private System.Windows.Forms.Label label12;
    }
}