﻿
namespace Quotation_management_system
{
    partial class Preview_Orders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txt_issued = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_validity = new System.Windows.Forms.DateTimePicker();
            this.txt_T_Condition = new System.Windows.Forms.TextBox();
            this.lbl_T_Condititon = new System.Windows.Forms.Label();
            this.txt_Pay_Term = new System.Windows.Forms.TextBox();
            this.lbl_Pay_Term = new System.Windows.Forms.Label();
            this.lbl_Val_upto = new System.Windows.Forms.Label();
            this.txt_Lead_Time = new System.Windows.Forms.TextBox();
            this.lbl_Lead_Time = new System.Windows.Forms.Label();
            this.txt_Subject = new System.Windows.Forms.TextBox();
            this.lbl_Subject = new System.Windows.Forms.Label();
            this.txt_Year = new System.Windows.Forms.TextBox();
            this.lbl_Year = new System.Windows.Forms.Label();
            this.txt_Update_Status = new System.Windows.Forms.TextBox();
            this.lbl_Update_Status = new System.Windows.Forms.Label();
            this.txt_Rev_Sta = new System.Windows.Forms.TextBox();
            this.lbl_Rev_Sta = new System.Windows.Forms.Label();
            this.txt_Quot_Num = new System.Windows.Forms.TextBox();
            this.lbl_Quot_Num = new System.Windows.Forms.Label();
            this.txt_Ref = new System.Windows.Forms.TextBox();
            this.lbl_Ref = new System.Windows.Forms.Label();
            this.txt_c_id = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.txt_Fax = new System.Windows.Forms.TextBox();
            this.lbl_Fax = new System.Windows.Forms.Label();
            this.txt_Tele = new System.Windows.Forms.TextBox();
            this.lbl_Tele = new System.Windows.Forms.Label();
            this.txt_Desig = new System.Windows.Forms.TextBox();
            this.lbl_Desig = new System.Windows.Forms.Label();
            this.txt_Cell = new System.Windows.Forms.TextBox();
            this.lbl_Cell = new System.Windows.Forms.Label();
            this.lbl_Cont_Per = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_approved = new System.Windows.Forms.Label();
            this.lbl_order_date = new System.Windows.Forms.Label();
            this.lbl_created = new System.Windows.Forms.Label();
            this.lbl_created_by = new System.Windows.Forms.Label();
            this.lbl_approved_by = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_Cont_Per = new System.Windows.Forms.TextBox();
            this.txt_Comp_N = new System.Windows.Forms.TextBox();
            this.lbl_Comp_N = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.user_logged = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_time = new System.Windows.Forms.Label();
            this.txtGSTAmount = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Orders_Table = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_total_price = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_disc = new System.Windows.Forms.TextBox();
            this.txt_discount_price = new System.Windows.Forms.TextBox();
            this.btn_save_preview = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtTotalPriceGST = new System.Windows.Forms.TextBox();
            this.txtGST = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_note2 = new System.Windows.Forms.TextBox();
            this.txt_note1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panlel_grid_3 = new System.Windows.Forms.Panel();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.txt_product_no = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Orders_Table)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panlel_grid_3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_issued
            // 
            this.txt_issued.CustomFormat = "dd/M/yyyy";
            this.txt_issued.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_issued.Location = new System.Drawing.Point(939, 53);
            this.txt_issued.Margin = new System.Windows.Forms.Padding(4);
            this.txt_issued.Name = "txt_issued";
            this.txt_issued.Size = new System.Drawing.Size(123, 26);
            this.txt_issued.TabIndex = 20;
            this.txt_issued.Value = new System.DateTime(2021, 12, 10, 0, 0, 0, 0);
            this.txt_issued.ValueChanged += new System.EventHandler(this.txt_issued_ValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.txt_issued);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txt_validity);
            this.groupBox1.Controls.Add(this.txt_T_Condition);
            this.groupBox1.Controls.Add(this.lbl_T_Condititon);
            this.groupBox1.Controls.Add(this.txt_Pay_Term);
            this.groupBox1.Controls.Add(this.lbl_Pay_Term);
            this.groupBox1.Controls.Add(this.lbl_Val_upto);
            this.groupBox1.Controls.Add(this.txt_Lead_Time);
            this.groupBox1.Controls.Add(this.lbl_Lead_Time);
            this.groupBox1.Controls.Add(this.txt_Subject);
            this.groupBox1.Controls.Add(this.lbl_Subject);
            this.groupBox1.Controls.Add(this.txt_Year);
            this.groupBox1.Controls.Add(this.lbl_Year);
            this.groupBox1.Controls.Add(this.txt_Update_Status);
            this.groupBox1.Controls.Add(this.lbl_Update_Status);
            this.groupBox1.Controls.Add(this.txt_Rev_Sta);
            this.groupBox1.Controls.Add(this.lbl_Rev_Sta);
            this.groupBox1.Controls.Add(this.txt_Quot_Num);
            this.groupBox1.Controls.Add(this.lbl_Quot_Num);
            this.groupBox1.Controls.Add(this.txt_Ref);
            this.groupBox1.Controls.Add(this.lbl_Ref);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(2, 74);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(1399, 108);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quotation Details";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(937, 29);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "Issued At";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txt_validity
            // 
            this.txt_validity.CustomFormat = "dd/M/yyyy";
            this.txt_validity.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_validity.Location = new System.Drawing.Point(1068, 53);
            this.txt_validity.Margin = new System.Windows.Forms.Padding(4);
            this.txt_validity.Name = "txt_validity";
            this.txt_validity.Size = new System.Drawing.Size(120, 26);
            this.txt_validity.TabIndex = 9;
            this.txt_validity.Value = new System.DateTime(2021, 12, 10, 0, 0, 0, 0);
            // 
            // txt_T_Condition
            // 
            this.txt_T_Condition.Location = new System.Drawing.Point(1192, 36);
            this.txt_T_Condition.Margin = new System.Windows.Forms.Padding(4);
            this.txt_T_Condition.Multiline = true;
            this.txt_T_Condition.Name = "txt_T_Condition";
            this.txt_T_Condition.Size = new System.Drawing.Size(199, 49);
            this.txt_T_Condition.TabIndex = 10;
            this.txt_T_Condition.Text = "\r\n";
            // 
            // lbl_T_Condititon
            // 
            this.lbl_T_Condititon.AutoSize = true;
            this.lbl_T_Condititon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_T_Condititon.ForeColor = System.Drawing.Color.Black;
            this.lbl_T_Condititon.Location = new System.Drawing.Point(1188, 17);
            this.lbl_T_Condititon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_T_Condititon.Name = "lbl_T_Condititon";
            this.lbl_T_Condititon.Size = new System.Drawing.Size(139, 16);
            this.lbl_T_Condititon.TabIndex = 19;
            this.lbl_T_Condititon.Text = "Terms and Conditions";
            // 
            // txt_Pay_Term
            // 
            this.txt_Pay_Term.Location = new System.Drawing.Point(809, 53);
            this.txt_Pay_Term.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Pay_Term.Name = "txt_Pay_Term";
            this.txt_Pay_Term.Size = new System.Drawing.Size(127, 26);
            this.txt_Pay_Term.TabIndex = 8;
            // 
            // lbl_Pay_Term
            // 
            this.lbl_Pay_Term.AutoSize = true;
            this.lbl_Pay_Term.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pay_Term.ForeColor = System.Drawing.Color.Black;
            this.lbl_Pay_Term.Location = new System.Drawing.Point(806, 29);
            this.lbl_Pay_Term.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Pay_Term.Name = "lbl_Pay_Term";
            this.lbl_Pay_Term.Size = new System.Drawing.Size(103, 16);
            this.lbl_Pay_Term.TabIndex = 17;
            this.lbl_Pay_Term.Text = "Payment Terms";
            // 
            // lbl_Val_upto
            // 
            this.lbl_Val_upto.AutoSize = true;
            this.lbl_Val_upto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Val_upto.ForeColor = System.Drawing.Color.Black;
            this.lbl_Val_upto.Location = new System.Drawing.Point(1065, 30);
            this.lbl_Val_upto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Val_upto.Name = "lbl_Val_upto";
            this.lbl_Val_upto.Size = new System.Drawing.Size(71, 16);
            this.lbl_Val_upto.TabIndex = 15;
            this.lbl_Val_upto.Text = "Valid Upto";
            // 
            // txt_Lead_Time
            // 
            this.txt_Lead_Time.Location = new System.Drawing.Point(690, 53);
            this.txt_Lead_Time.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Lead_Time.Name = "txt_Lead_Time";
            this.txt_Lead_Time.Size = new System.Drawing.Size(115, 26);
            this.txt_Lead_Time.TabIndex = 7;
            // 
            // lbl_Lead_Time
            // 
            this.lbl_Lead_Time.AutoSize = true;
            this.lbl_Lead_Time.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lead_Time.ForeColor = System.Drawing.Color.Black;
            this.lbl_Lead_Time.Location = new System.Drawing.Point(687, 29);
            this.lbl_Lead_Time.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Lead_Time.Name = "lbl_Lead_Time";
            this.lbl_Lead_Time.Size = new System.Drawing.Size(73, 16);
            this.lbl_Lead_Time.TabIndex = 13;
            this.lbl_Lead_Time.Text = "Lead Time";
            // 
            // txt_Subject
            // 
            this.txt_Subject.Location = new System.Drawing.Point(566, 53);
            this.txt_Subject.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Subject.Name = "txt_Subject";
            this.txt_Subject.Size = new System.Drawing.Size(121, 26);
            this.txt_Subject.TabIndex = 6;
            // 
            // lbl_Subject
            // 
            this.lbl_Subject.AutoSize = true;
            this.lbl_Subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subject.ForeColor = System.Drawing.Color.Black;
            this.lbl_Subject.Location = new System.Drawing.Point(562, 27);
            this.lbl_Subject.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Subject.Name = "lbl_Subject";
            this.lbl_Subject.Size = new System.Drawing.Size(53, 16);
            this.lbl_Subject.TabIndex = 11;
            this.lbl_Subject.Text = "Subject";
            // 
            // txt_Year
            // 
            this.txt_Year.Location = new System.Drawing.Point(486, 53);
            this.txt_Year.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Year.Name = "txt_Year";
            this.txt_Year.Size = new System.Drawing.Size(76, 26);
            this.txt_Year.TabIndex = 5;
            // 
            // lbl_Year
            // 
            this.lbl_Year.AutoSize = true;
            this.lbl_Year.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Year.ForeColor = System.Drawing.Color.Black;
            this.lbl_Year.Location = new System.Drawing.Point(483, 27);
            this.lbl_Year.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Year.Name = "lbl_Year";
            this.lbl_Year.Size = new System.Drawing.Size(37, 16);
            this.lbl_Year.TabIndex = 9;
            this.lbl_Year.Text = "Year";
            // 
            // txt_Update_Status
            // 
            this.txt_Update_Status.Location = new System.Drawing.Point(236, 53);
            this.txt_Update_Status.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Update_Status.Name = "txt_Update_Status";
            this.txt_Update_Status.Size = new System.Drawing.Size(115, 26);
            this.txt_Update_Status.TabIndex = 3;
            this.txt_Update_Status.Text = "0";
            // 
            // lbl_Update_Status
            // 
            this.lbl_Update_Status.AutoSize = true;
            this.lbl_Update_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Update_Status.ForeColor = System.Drawing.Color.Black;
            this.lbl_Update_Status.Location = new System.Drawing.Point(232, 27);
            this.lbl_Update_Status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Update_Status.Name = "lbl_Update_Status";
            this.lbl_Update_Status.Size = new System.Drawing.Size(93, 16);
            this.lbl_Update_Status.TabIndex = 7;
            this.lbl_Update_Status.Text = "Update Status";
            // 
            // txt_Rev_Sta
            // 
            this.txt_Rev_Sta.Location = new System.Drawing.Point(355, 53);
            this.txt_Rev_Sta.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Rev_Sta.Name = "txt_Rev_Sta";
            this.txt_Rev_Sta.Size = new System.Drawing.Size(128, 26);
            this.txt_Rev_Sta.TabIndex = 4;
            // 
            // lbl_Rev_Sta
            // 
            this.lbl_Rev_Sta.AutoSize = true;
            this.lbl_Rev_Sta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rev_Sta.ForeColor = System.Drawing.Color.Black;
            this.lbl_Rev_Sta.Location = new System.Drawing.Point(352, 27);
            this.lbl_Rev_Sta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Rev_Sta.Name = "lbl_Rev_Sta";
            this.lbl_Rev_Sta.Size = new System.Drawing.Size(101, 16);
            this.lbl_Rev_Sta.TabIndex = 5;
            this.lbl_Rev_Sta.Text = "Revision Status";
            // 
            // txt_Quot_Num
            // 
            this.txt_Quot_Num.Location = new System.Drawing.Point(116, 53);
            this.txt_Quot_Num.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Quot_Num.Name = "txt_Quot_Num";
            this.txt_Quot_Num.Size = new System.Drawing.Size(116, 26);
            this.txt_Quot_Num.TabIndex = 2;
            // 
            // lbl_Quot_Num
            // 
            this.lbl_Quot_Num.AutoSize = true;
            this.lbl_Quot_Num.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quot_Num.ForeColor = System.Drawing.Color.Black;
            this.lbl_Quot_Num.Location = new System.Drawing.Point(111, 27);
            this.lbl_Quot_Num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Quot_Num.Name = "lbl_Quot_Num";
            this.lbl_Quot_Num.Size = new System.Drawing.Size(116, 16);
            this.lbl_Quot_Num.TabIndex = 3;
            this.lbl_Quot_Num.Text = "Quotation Number";
            // 
            // txt_Ref
            // 
            this.txt_Ref.Location = new System.Drawing.Point(2, 53);
            this.txt_Ref.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Ref.Name = "txt_Ref";
            this.txt_Ref.Size = new System.Drawing.Size(110, 26);
            this.txt_Ref.TabIndex = 1;
            this.txt_Ref.Text = "0";
            // 
            // lbl_Ref
            // 
            this.lbl_Ref.AutoSize = true;
            this.lbl_Ref.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ref.ForeColor = System.Drawing.Color.Black;
            this.lbl_Ref.Location = new System.Drawing.Point(2, 27);
            this.lbl_Ref.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Ref.Name = "lbl_Ref";
            this.lbl_Ref.Size = new System.Drawing.Size(81, 16);
            this.lbl_Ref.TabIndex = 0;
            this.lbl_Ref.Text = "Reference #";
            // 
            // txt_c_id
            // 
            this.txt_c_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_c_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_c_id.Location = new System.Drawing.Point(4, 52);
            this.txt_c_id.Margin = new System.Windows.Forms.Padding(4);
            this.txt_c_id.Name = "txt_c_id";
            this.txt_c_id.Size = new System.Drawing.Size(33, 26);
            this.txt_c_id.TabIndex = 1003;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(1, 27);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 16);
            this.label6.TabIndex = 1002;
            this.label6.Text = "ID";
            // 
            // txt_Email
            // 
            this.txt_Email.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_Email.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Email.Location = new System.Drawing.Point(1015, 52);
            this.txt_Email.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(184, 26);
            this.txt_Email.TabIndex = 17;
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email.ForeColor = System.Drawing.Color.Black;
            this.lbl_Email.Location = new System.Drawing.Point(1012, 26);
            this.lbl_Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(42, 16);
            this.lbl_Email.TabIndex = 17;
            this.lbl_Email.Text = "Email";
            // 
            // txt_Fax
            // 
            this.txt_Fax.Location = new System.Drawing.Point(843, 52);
            this.txt_Fax.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Fax.Name = "txt_Fax";
            this.txt_Fax.Size = new System.Drawing.Size(169, 26);
            this.txt_Fax.TabIndex = 16;
            // 
            // lbl_Fax
            // 
            this.lbl_Fax.AutoSize = true;
            this.lbl_Fax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fax.ForeColor = System.Drawing.Color.Black;
            this.lbl_Fax.Location = new System.Drawing.Point(843, 26);
            this.lbl_Fax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Fax.Name = "lbl_Fax";
            this.lbl_Fax.Size = new System.Drawing.Size(40, 16);
            this.lbl_Fax.TabIndex = 13;
            this.lbl_Fax.Text = "Fax #";
            // 
            // txt_Tele
            // 
            this.txt_Tele.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_Tele.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Tele.Location = new System.Drawing.Point(689, 52);
            this.txt_Tele.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Tele.Name = "txt_Tele";
            this.txt_Tele.Size = new System.Drawing.Size(150, 26);
            this.txt_Tele.TabIndex = 15;
            // 
            // lbl_Tele
            // 
            this.lbl_Tele.AutoSize = true;
            this.lbl_Tele.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tele.ForeColor = System.Drawing.Color.Black;
            this.lbl_Tele.Location = new System.Drawing.Point(685, 26);
            this.lbl_Tele.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Tele.Name = "lbl_Tele";
            this.lbl_Tele.Size = new System.Drawing.Size(74, 16);
            this.lbl_Tele.TabIndex = 9;
            this.lbl_Tele.Text = "Telephone";
            // 
            // txt_Desig
            // 
            this.txt_Desig.Location = new System.Drawing.Point(341, 52);
            this.txt_Desig.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Desig.Name = "txt_Desig";
            this.txt_Desig.Size = new System.Drawing.Size(183, 26);
            this.txt_Desig.TabIndex = 13;
            // 
            // lbl_Desig
            // 
            this.lbl_Desig.AutoSize = true;
            this.lbl_Desig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Desig.ForeColor = System.Drawing.Color.Black;
            this.lbl_Desig.Location = new System.Drawing.Point(338, 26);
            this.lbl_Desig.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Desig.Name = "lbl_Desig";
            this.lbl_Desig.Size = new System.Drawing.Size(80, 16);
            this.lbl_Desig.TabIndex = 7;
            this.lbl_Desig.Text = "Designation";
            // 
            // txt_Cell
            // 
            this.txt_Cell.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Cell.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Cell.Location = new System.Drawing.Point(527, 52);
            this.txt_Cell.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Cell.Name = "txt_Cell";
            this.txt_Cell.Size = new System.Drawing.Size(158, 26);
            this.txt_Cell.TabIndex = 14;
            // 
            // lbl_Cell
            // 
            this.lbl_Cell.AutoSize = true;
            this.lbl_Cell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cell.ForeColor = System.Drawing.Color.Black;
            this.lbl_Cell.Location = new System.Drawing.Point(523, 26);
            this.lbl_Cell.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Cell.Name = "lbl_Cell";
            this.lbl_Cell.Size = new System.Drawing.Size(41, 16);
            this.lbl_Cell.TabIndex = 5;
            this.lbl_Cell.Text = "Cell #";
            // 
            // lbl_Cont_Per
            // 
            this.lbl_Cont_Per.AutoSize = true;
            this.lbl_Cont_Per.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cont_Per.ForeColor = System.Drawing.Color.Black;
            this.lbl_Cont_Per.Location = new System.Drawing.Point(187, 26);
            this.lbl_Cont_Per.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Cont_Per.Name = "lbl_Cont_Per";
            this.lbl_Cont_Per.Size = new System.Drawing.Size(99, 16);
            this.lbl_Cont_Per.TabIndex = 3;
            this.lbl_Cont_Per.Text = "Contact Person";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Location = new System.Drawing.Point(0, 52);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1411, 291);
            this.panel2.TabIndex = 40;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.lbl_approved);
            this.groupBox3.Controls.Add(this.lbl_order_date);
            this.groupBox3.Controls.Add(this.lbl_created);
            this.groupBox3.Controls.Add(this.lbl_created_by);
            this.groupBox3.Controls.Add(this.lbl_approved_by);
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Location = new System.Drawing.Point(3, -1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1398, 68);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Order Detail";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(1009, 28);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 24);
            this.label7.TabIndex = 1018;
            this.label7.Text = "Order Date:";
            this.label7.UseMnemonic = false;
            // 
            // lbl_approved
            // 
            this.lbl_approved.AutoSize = true;
            this.lbl_approved.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lbl_approved.ForeColor = System.Drawing.Color.Black;
            this.lbl_approved.Location = new System.Drawing.Point(788, 27);
            this.lbl_approved.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_approved.Name = "lbl_approved";
            this.lbl_approved.Size = new System.Drawing.Size(82, 24);
            this.lbl_approved.TabIndex = 1017;
            this.lbl_approved.Text = "Approve";
            // 
            // lbl_order_date
            // 
            this.lbl_order_date.AutoSize = true;
            this.lbl_order_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lbl_order_date.ForeColor = System.Drawing.Color.Black;
            this.lbl_order_date.Location = new System.Drawing.Point(1193, 28);
            this.lbl_order_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_order_date.Name = "lbl_order_date";
            this.lbl_order_date.Size = new System.Drawing.Size(48, 24);
            this.lbl_order_date.TabIndex = 1016;
            this.lbl_order_date.Text = "Date";
            // 
            // lbl_created
            // 
            this.lbl_created.AutoSize = true;
            this.lbl_created.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lbl_created.ForeColor = System.Drawing.Color.Black;
            this.lbl_created.Location = new System.Drawing.Point(386, 26);
            this.lbl_created.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_created.Name = "lbl_created";
            this.lbl_created.Size = new System.Drawing.Size(76, 24);
            this.lbl_created.TabIndex = 1015;
            this.lbl_created.Text = "Created";
            // 
            // lbl_created_by
            // 
            this.lbl_created_by.AutoSize = true;
            this.lbl_created_by.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lbl_created_by.ForeColor = System.Drawing.Color.Black;
            this.lbl_created_by.Location = new System.Drawing.Point(158, 27);
            this.lbl_created_by.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_created_by.Name = "lbl_created_by";
            this.lbl_created_by.Size = new System.Drawing.Size(107, 24);
            this.lbl_created_by.TabIndex = 1013;
            this.lbl_created_by.Text = "Created By:";
            // 
            // lbl_approved_by
            // 
            this.lbl_approved_by.AutoSize = true;
            this.lbl_approved_by.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lbl_approved_by.ForeColor = System.Drawing.Color.Black;
            this.lbl_approved_by.Location = new System.Drawing.Point(592, 28);
            this.lbl_approved_by.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_approved_by.Name = "lbl_approved_by";
            this.lbl_approved_by.Size = new System.Drawing.Size(124, 24);
            this.lbl_approved_by.TabIndex = 1014;
            this.lbl_approved_by.Text = "Approved By:";
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.Controls.Add(this.txt_address);
            this.groupBox2.Controls.Add(this.txt_c_id);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txt_Email);
            this.groupBox2.Controls.Add(this.lbl_Email);
            this.groupBox2.Controls.Add(this.txt_Fax);
            this.groupBox2.Controls.Add(this.lbl_Fax);
            this.groupBox2.Controls.Add(this.txt_Tele);
            this.groupBox2.Controls.Add(this.lbl_Tele);
            this.groupBox2.Controls.Add(this.txt_Desig);
            this.groupBox2.Controls.Add(this.lbl_Desig);
            this.groupBox2.Controls.Add(this.txt_Cell);
            this.groupBox2.Controls.Add(this.lbl_Cell);
            this.groupBox2.Controls.Add(this.txt_Cont_Per);
            this.groupBox2.Controls.Add(this.lbl_Cont_Per);
            this.groupBox2.Controls.Add(this.txt_Comp_N);
            this.groupBox2.Controls.Add(this.lbl_Comp_N);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(2, 187);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox2.Size = new System.Drawing.Size(1399, 102);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CustomerDetails";
            // 
            // txt_address
            // 
            this.txt_address.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_address.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_address.Location = new System.Drawing.Point(1203, 52);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(186, 26);
            this.txt_address.TabIndex = 1009;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(1199, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 16);
            this.label8.TabIndex = 1008;
            this.label8.Text = "Address";
            // 
            // txt_Cont_Per
            // 
            this.txt_Cont_Per.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Cont_Per.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Cont_Per.Location = new System.Drawing.Point(190, 52);
            this.txt_Cont_Per.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Cont_Per.Name = "txt_Cont_Per";
            this.txt_Cont_Per.Size = new System.Drawing.Size(143, 26);
            this.txt_Cont_Per.TabIndex = 12;
            // 
            // txt_Comp_N
            // 
            this.txt_Comp_N.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Comp_N.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Comp_N.Location = new System.Drawing.Point(42, 52);
            this.txt_Comp_N.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Comp_N.Name = "txt_Comp_N";
            this.txt_Comp_N.Size = new System.Drawing.Size(144, 26);
            this.txt_Comp_N.TabIndex = 11;
            // 
            // lbl_Comp_N
            // 
            this.lbl_Comp_N.AutoSize = true;
            this.lbl_Comp_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Comp_N.ForeColor = System.Drawing.Color.Black;
            this.lbl_Comp_N.Location = new System.Drawing.Point(39, 27);
            this.lbl_Comp_N.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Comp_N.Name = "lbl_Comp_N";
            this.lbl_Comp_N.Size = new System.Drawing.Size(106, 16);
            this.lbl_Comp_N.TabIndex = 0;
            this.lbl_Comp_N.Text = "Company Name";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(587, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Preview Orders";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.user_logged);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lbl_date);
            this.panel1.Controls.Add(this.lbl_time);
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1427, 50);
            this.panel1.TabIndex = 38;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 15.75F);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(1245, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(152, 24);
            this.label12.TabIndex = 36;
            this.label12.Text = "user_logged_in";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 15.75F);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(1188, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 24);
            this.label13.TabIndex = 35;
            this.label13.Text = "User:";
            // 
            // user_logged
            // 
            this.user_logged.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.user_logged.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.user_logged.ForeColor = System.Drawing.Color.White;
            this.user_logged.Location = new System.Drawing.Point(2107, 34);
            this.user_logged.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.user_logged.Name = "user_logged";
            this.user_logged.Size = new System.Drawing.Size(133, 36);
            this.user_logged.TabIndex = 20;
            this.user_logged.Text = "Hannan";
            this.user_logged.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(1971, 34);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 36);
            this.label3.TabIndex = 19;
            this.label3.Text = "USER:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.ForeColor = System.Drawing.Color.White;
            this.lbl_date.Location = new System.Drawing.Point(16, 11);
            this.lbl_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(63, 29);
            this.lbl_date.TabIndex = 9;
            this.lbl_date.Text = "Date";
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lbl_time.ForeColor = System.Drawing.Color.White;
            this.lbl_time.Location = new System.Drawing.Point(184, 11);
            this.lbl_time.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(69, 29);
            this.lbl_time.TabIndex = 10;
            this.lbl_time.Text = "Time";
            // 
            // txtGSTAmount
            // 
            this.txtGSTAmount.Location = new System.Drawing.Point(15, 271);
            this.txtGSTAmount.Margin = new System.Windows.Forms.Padding(4);
            this.txtGSTAmount.Name = "txtGSTAmount";
            this.txtGSTAmount.Size = new System.Drawing.Size(223, 23);
            this.txtGSTAmount.TabIndex = 31;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Orders_Table
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.Orders_Table.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.Orders_Table.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Orders_Table.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Orders_Table.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.Orders_Table.ColumnHeadersHeight = 50;
            this.Orders_Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Orders_Table.DefaultCellStyle = dataGridViewCellStyle3;
            this.Orders_Table.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Orders_Table.Location = new System.Drawing.Point(7, 4);
            this.Orders_Table.Margin = new System.Windows.Forms.Padding(4);
            this.Orders_Table.Name = "Orders_Table";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.Orders_Table.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.Orders_Table.Size = new System.Drawing.Size(1154, 379);
            this.Orders_Table.TabIndex = 11;
            this.Orders_Table.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Orders_Table_CellContentClick);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.txt_total_price);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.txt_disc);
            this.panel4.Controls.Add(this.txt_discount_price);
            this.panel4.Controls.Add(this.btn_save_preview);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.txtGSTAmount);
            this.panel4.Controls.Add(this.txtTotalPriceGST);
            this.panel4.Controls.Add(this.txtGST);
            this.panel4.Controls.Add(this.label35);
            this.panel4.Location = new System.Drawing.Point(1163, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(244, 488);
            this.panel4.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(10, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 16);
            this.label2.TabIndex = 1023;
            this.label2.Text = "Total Price Exclusive GST";
            // 
            // txt_total_price
            // 
            this.txt_total_price.Location = new System.Drawing.Point(14, 41);
            this.txt_total_price.Margin = new System.Windows.Forms.Padding(4);
            this.txt_total_price.Name = "txt_total_price";
            this.txt_total_price.Size = new System.Drawing.Size(224, 23);
            this.txt_total_price.TabIndex = 1024;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(13, 134);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 16);
            this.label10.TabIndex = 1022;
            this.label10.Text = "Total Discount Price";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(12, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 16);
            this.label9.TabIndex = 1021;
            this.label9.Text = "Total Discount %";
            // 
            // txt_disc
            // 
            this.txt_disc.Location = new System.Drawing.Point(15, 92);
            this.txt_disc.Name = "txt_disc";
            this.txt_disc.Size = new System.Drawing.Size(223, 23);
            this.txt_disc.TabIndex = 1019;
            this.txt_disc.Text = "0";
            // 
            // txt_discount_price
            // 
            this.txt_discount_price.Location = new System.Drawing.Point(18, 154);
            this.txt_discount_price.Name = "txt_discount_price";
            this.txt_discount_price.Size = new System.Drawing.Size(220, 23);
            this.txt_discount_price.TabIndex = 1020;
            this.txt_discount_price.Text = "0";
            // 
            // btn_save_preview
            // 
            this.btn_save_preview.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_save_preview.FlatAppearance.BorderSize = 0;
            this.btn_save_preview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save_preview.ForeColor = System.Drawing.Color.White;
            this.btn_save_preview.Location = new System.Drawing.Point(62, 417);
            this.btn_save_preview.Name = "btn_save_preview";
            this.btn_save_preview.Size = new System.Drawing.Size(121, 39);
            this.btn_save_preview.TabIndex = 35;
            this.btn_save_preview.Text = "PDF";
            this.btn_save_preview.UseVisualStyleBackColor = false;
            this.btn_save_preview.Click += new System.EventHandler(this.btn_save_preview_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(15, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.TabIndex = 34;
            this.label4.Text = "GST %";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(13, 309);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(127, 16);
            this.label25.TabIndex = 28;
            this.label25.Text = "Total Price Incl GST";
            // 
            // txtTotalPriceGST
            // 
            this.txtTotalPriceGST.Location = new System.Drawing.Point(16, 330);
            this.txtTotalPriceGST.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalPriceGST.Name = "txtTotalPriceGST";
            this.txtTotalPriceGST.Size = new System.Drawing.Size(222, 23);
            this.txtTotalPriceGST.TabIndex = 29;
            // 
            // txtGST
            // 
            this.txtGST.Location = new System.Drawing.Point(15, 210);
            this.txtGST.Margin = new System.Windows.Forms.Padding(4);
            this.txtGST.Name = "txtGST";
            this.txtGST.Size = new System.Drawing.Size(223, 23);
            this.txtGST.TabIndex = 27;
            this.txtGST.Text = "17";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(13, 252);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(84, 16);
            this.label35.TabIndex = 30;
            this.label35.Text = "GST Amount";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.txt_note2);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.txt_note1);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.Orders_Table);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Location = new System.Drawing.Point(0, 345);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1411, 496);
            this.panel3.TabIndex = 39;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkCyan;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(1016, 385);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 39);
            this.button1.TabIndex = 1025;
            this.button1.Text = "Export ToExcel";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_note2
            // 
            this.txt_note2.BackColor = System.Drawing.Color.White;
            this.txt_note2.Location = new System.Drawing.Point(72, 424);
            this.txt_note2.Name = "txt_note2";
            this.txt_note2.Size = new System.Drawing.Size(633, 23);
            this.txt_note2.TabIndex = 1028;
            // 
            // txt_note1
            // 
            this.txt_note1.BackColor = System.Drawing.Color.White;
            this.txt_note1.Location = new System.Drawing.Point(72, 390);
            this.txt_note1.Name = "txt_note1";
            this.txt_note1.Size = new System.Drawing.Size(633, 23);
            this.txt_note1.TabIndex = 1027;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(8, 427);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 17);
            this.label14.TabIndex = 1026;
            this.label14.Text = "Note :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(8, 395);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 17);
            this.label15.TabIndex = 1025;
            this.label15.Text = "Note :";
            // 
            // panlel_grid_3
            // 
            this.panlel_grid_3.Controls.Add(this.hScrollBar1);
            this.panlel_grid_3.Location = new System.Drawing.Point(843, 931);
            this.panlel_grid_3.Margin = new System.Windows.Forms.Padding(4);
            this.panlel_grid_3.Name = "panlel_grid_3";
            this.panlel_grid_3.Size = new System.Drawing.Size(412, 40);
            this.panlel_grid_3.TabIndex = 41;
            this.panlel_grid_3.Visible = false;
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.Location = new System.Drawing.Point(3, 33);
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(1904, 17);
            this.hScrollBar1.TabIndex = 0;
            this.hScrollBar1.Visible = false;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // txt_product_no
            // 
            this.txt_product_no.Location = new System.Drawing.Point(141, 812);
            this.txt_product_no.Name = "txt_product_no";
            this.txt_product_no.Size = new System.Drawing.Size(100, 23);
            this.txt_product_no.TabIndex = 47;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 815);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 17);
            this.label11.TabIndex = 46;
            this.label11.Text = "Product Order No";
            // 
            // Preview_Orders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1424, 841);
            this.Controls.Add(this.txt_product_no);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panlel_grid_3);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Preview_Orders";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Preview_Orders_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Orders_Table)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panlel_grid_3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker txt_issued;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker txt_validity;
        private System.Windows.Forms.TextBox txt_T_Condition;
        private System.Windows.Forms.Label lbl_T_Condititon;
        private System.Windows.Forms.TextBox txt_Pay_Term;
        private System.Windows.Forms.Label lbl_Pay_Term;
        private System.Windows.Forms.Label lbl_Val_upto;
        private System.Windows.Forms.TextBox txt_Lead_Time;
        private System.Windows.Forms.Label lbl_Lead_Time;
        private System.Windows.Forms.TextBox txt_Subject;
        private System.Windows.Forms.Label lbl_Subject;
        private System.Windows.Forms.TextBox txt_Year;
        private System.Windows.Forms.Label lbl_Year;
        public System.Windows.Forms.TextBox txt_Update_Status;
        private System.Windows.Forms.Label lbl_Update_Status;
        public System.Windows.Forms.TextBox txt_Rev_Sta;
        private System.Windows.Forms.Label lbl_Rev_Sta;
        public System.Windows.Forms.TextBox txt_Quot_Num;
        private System.Windows.Forms.Label lbl_Quot_Num;
        public System.Windows.Forms.TextBox txt_Ref;
        private System.Windows.Forms.Label lbl_Ref;
        private System.Windows.Forms.TextBox txt_c_id;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.TextBox txt_Fax;
        private System.Windows.Forms.Label lbl_Fax;
        private System.Windows.Forms.TextBox txt_Tele;
        private System.Windows.Forms.Label lbl_Tele;
        private System.Windows.Forms.TextBox txt_Desig;
        private System.Windows.Forms.Label lbl_Desig;
        private System.Windows.Forms.TextBox txt_Cell;
        private System.Windows.Forms.Label lbl_Cell;
        private System.Windows.Forms.Label lbl_Cont_Per;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_Cont_Per;
        private System.Windows.Forms.TextBox txt_Comp_N;
        private System.Windows.Forms.Label lbl_Comp_N;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label user_logged;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.TextBox txtGSTAmount;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataGridView Orders_Table;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtTotalPriceGST;
        private System.Windows.Forms.TextBox txtGST;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panlel_grid_3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_save_preview;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_disc;
        private System.Windows.Forms.TextBox txt_discount_price;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_total_price;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_approved;
        private System.Windows.Forms.Label lbl_order_date;
        private System.Windows.Forms.Label lbl_created;
        private System.Windows.Forms.Label lbl_created_by;
        private System.Windows.Forms.Label lbl_approved_by;
        private System.Windows.Forms.TextBox txt_product_no;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_note2;
        private System.Windows.Forms.TextBox txt_note1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button1;
    }
}