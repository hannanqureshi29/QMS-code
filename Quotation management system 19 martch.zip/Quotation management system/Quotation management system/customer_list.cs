﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace Quotation_management_system
{
    public partial class customer_list : Form
    {
        private MySqlConnection con;
        public customer_list()
        {
            InitializeComponent();
             con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            // con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");

        }
        private void view_cutomers_list()
        {

            DataTable dt = new DataTable();

            MySqlCommand cmd = new MySqlCommand("CALL `customer_list`()", con);


            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);

            con.Close();


            Customer_List_Table.DataSource = dt;
            Customer_List_Table.Columns[0].HeaderText = "C-id";
            Customer_List_Table.Columns[1].HeaderText = "Company-name";
            Customer_List_Table.Columns[2].HeaderText = "Contact-person";
            Customer_List_Table.Columns[3].HeaderText = "Designation";
            Customer_List_Table.Columns[4].HeaderText = "Cell-num";
            Customer_List_Table.Columns[5].HeaderText = "TEL-num";
            Customer_List_Table.Columns[6].HeaderText = "Fax-num";
            Customer_List_Table.Columns[7].HeaderText = "Email";
            Customer_List_Table.Columns[8].HeaderText = "Address";



            Customer_List_Table.Columns[0].Width = 50;
            Customer_List_Table.Columns[1].Width = 100;
            Customer_List_Table.Columns[2].Width = 100;
            Customer_List_Table.Columns[3].Width = 100;
            Customer_List_Table.Columns[4].Width = 100;
            Customer_List_Table.Columns[5].Width = 100;
            Customer_List_Table.Columns[6].Width = 100;
            Customer_List_Table.Columns[7].Width = 120;
            Customer_List_Table.Columns[8].Width = 300;

        }

        private void customer_list_Load(object sender, EventArgs e)
        {
            view_cutomers_list();
            user_logged.Text = Login.u_name;
            search_from_customer();
        }

        private void btnaddproduct_Click(object sender, EventArgs e)
        {
            var dash = new AddCustomers();
            dash.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_date.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
        private void search_from_customer()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM customer ", con);
            //  SELECT quotations.q_num,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection collection = new AutoCompleteStringCollection();

            while (reader.Read())
            {
                collection.Add(reader.GetString(0));
                collection.Add(reader.GetString(1));
               // collection.Add(reader.GetString(2));
            }
            txt_search_customer.AutoCompleteCustomSource = collection;
            con.Close();
        }

        private void txt_search_quot_Enter(object sender, EventArgs e)
        {
            if (txt_search_customer.Text == "Search Customer")
            {
                txt_search_customer.Text = "";
            }
        }

        private void txt_search_quot_KeyDown(object sender, KeyEventArgs e)
        {
            
                if (e.KeyCode == Keys.Enter)
                {
                    DataTable dt = new DataTable();

                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM customer WHERE company_name = '"+ txt_search_customer.Text + "' OR contact_person =  '" + txt_search_customer.Text + "'", con);
                    // MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id WHERE quotations.q_num = '" + txt_search_quote.Text + "' OR quotations.q_ref = '" + txt_search_quote.Text + "' OR customer.company_name = '" + txt_search_quote.Text + "' OR customer.contact_person = '" + txt_search_quote.Text + "' GROUP BY quotations.q_num", con);

                    //MySqlParameter[] prm = new MySqlParameter[2];

                    //prm[0] = new MySqlParameter("qnum", MySqlDbType.VarChar);
                    //prm[0].Value = txt_search_quot.Text;
                    //prm[1] = new MySqlParameter("qref", MySqlDbType.VarChar);
                    //prm[1].Value = txt_search_quot.Text;
                    //prm[2] = new MySqlParameter("companyname", MySqlDbType.VarChar);
                    //prm[2].Value = txt_search_quot.Text;
                    //prm[3] = new MySqlParameter("contactperson", MySqlDbType.VarChar);
                    //prm[3].Value = txt_search_quot.Text;

                    //MySqlCommand cmnd = new MySqlCommand();
                    //cmnd.Connection = con;
                    //cmnd.CommandType = CommandType.StoredProcedure;
                    //cmnd.CommandText = "search_quotation_bar";
                    //cmnd.Parameters.AddRange(prm);

                    con.Open();
                    MySqlDataReader sdr = cmd.ExecuteReader();
                    dt.Load(sdr);
                    con.Close();


                    Customer_List_Table.DataSource = dt;
                    Customer_List_Table.Columns[0].HeaderText = "C-id";
                    Customer_List_Table.Columns[1].HeaderText = "Company-name";
                    Customer_List_Table.Columns[2].HeaderText = "Contact-person";
                    Customer_List_Table.Columns[3].HeaderText = "Designation";
                    Customer_List_Table.Columns[4].HeaderText = "Cell-num";
                    Customer_List_Table.Columns[5].HeaderText = "TEL-num";
                    Customer_List_Table.Columns[6].HeaderText = "Fax-num";
                    Customer_List_Table.Columns[7].HeaderText = "Email";
                    Customer_List_Table.Columns[8].HeaderText = "Address";





                Customer_List_Table.Columns[0].Width = 50;
                Customer_List_Table.Columns[1].Width = 100;
                Customer_List_Table.Columns[2].Width = 100;
                Customer_List_Table.Columns[3].Width = 100;
                Customer_List_Table.Columns[4].Width = 100;
                Customer_List_Table.Columns[5].Width = 100;
                Customer_List_Table.Columns[6].Width = 100;
                Customer_List_Table.Columns[7].Width = 120;
                Customer_List_Table.Columns[8].Width = 300;

            }
            
        }

        private void txt_search_quot_Leave(object sender, EventArgs e)
        {
            if (txt_search_customer.Text == "")
            {
                txt_search_customer.Text = "Search Customer";
                 view_cutomers_list();
            
            }
        }

        private void txt_search_quot_TextChanged(object sender, EventArgs e)
        {
            if (txt_search_customer.Text == "")
            {
                 view_cutomers_list();
               
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }

}
