﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Quotation_management_system
{
    public partial class SearchProduct : Form
    {
        private MySqlConnection con;
        
        public SearchProduct()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            //con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");



        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_date.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void SearchProduct_Load(object sender, EventArgs e)
        {
            search_from_product();
            view_product_list();
            label12.Text = Login.u_name;
        }
        private void search_from_product()
        {
            //MySqlCommand cmd = new MySqlCommand("SELECT * FROM work_book2", con);
            ////  SELECT quotations.q_num,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
            //con.Open();
            //MySqlDataReader reader = cmd.ExecuteReader();
            //AutoCompleteStringCollection collection = new AutoCompleteStringCollection();

            //while (reader.Read())
            //{
            //    collection.Add(reader.GetString(3));
            //    //collection.add(reader.getstring(1));
            //    //collection.add(reader.getstring(2));
            //    //collection.add(reader.getstring(3));
            //    //collection.add(reader.getstring(4));

            //}
            //txt_search_products.AutoCompleteCustomSource = collection;
            //con.Close();
        }
        private void view_product_list()
        {
            
            DataTable dt = new DataTable();

             MySqlCommand cmd = new MySqlCommand("SELECT * FROM products LIMIT 50", con);
           // MySqlCommand cmd = new MySqlCommand("SELECT p_code,p_size,p_desc,p_unit,p_unit_price FROM products",con);




            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);

            


            Search_product_table.DataSource = dt;

            //Search_product_table.Columns[0].HeaderText = "Sr#";
            //Search_product_table.Columns[1].HeaderText = "Size";
            //Search_product_table.Columns[2].HeaderText = "description";
            //Search_product_table.Columns[3].HeaderText = "Unit";
            //Search_product_table.Columns[4].HeaderText = "Unit-price";


            //Search_product_table.Columns[0].Width = 10;
            //Search_product_table.Columns[1].Width = 20;
            //Search_product_table.Columns[2].Width = 150;
            //Search_product_table.Columns[3].Width = 100;
            //Search_product_table.Columns[4].Width = 100;



            //Search_product_table.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //Search_product_table.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //Search_product_table.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            con.Close();
        }

        private void txt_search_product_Enter(object sender, EventArgs e)
        {
            if (txt_search_products.Text == "Search Product")
            {
                txt_search_products.Text = "";
            }
        }

        private void txt_search_product_KeyDown(object sender, KeyEventArgs e)
        {
        if (e.KeyCode == Keys.Enter)
        {
            DataTable dt = new DataTable();
            //OR p_type =  '" + txt_search_product.Text + "' OR p_size ='" + txt_search_product.Text + "'  OR p_type = '"+txt_search_products.Text+"'
            MySqlCommand cmd = new MySqlCommand("SELECT p_code,p_size,p_description,p_unit,p_unit_price FROM products WHERE p_description = '" + txt_search_products.Text + "' ", con);
            // MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id WHERE quotations.q_num = '" + txt_search_quote.Text + "' OR quotations.q_ref = '" + txt_search_quote.Text + "' OR customer.company_name = '" + txt_search_quote.Text + "' OR customer.contact_person = '" + txt_search_quote.Text + "' GROUP BY quotations.q_num", con);


            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            Search_product_table.DataSource = dt;


                Search_product_table.Columns[0].HeaderText = "Sr#";
                Search_product_table.Columns[1].HeaderText = "Size";
                Search_product_table.Columns[2].HeaderText = "description";
                Search_product_table.Columns[3].HeaderText = "Unit";
                Search_product_table.Columns[4].HeaderText = "Unit-price";


                Search_product_table.Columns[0].Width = 10;
                Search_product_table.Columns[1].Width = 20;
                Search_product_table.Columns[2].Width = 150;
                Search_product_table.Columns[3].Width = 100;
                Search_product_table.Columns[4].Width = 100;



                Search_product_table.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Search_product_table.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Search_product_table.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }

        private void txt_search_product_Leave(object sender, EventArgs e)
        {
            if (txt_search_products.Text == "")
            {
                txt_search_products.Text = "Search product";
                view_product_list();
            }
        }

        private void txt_search_product_TextChanged(object sender, EventArgs e)
        {
        if (txt_search_products.Text == "")
        {
            view_product_list();
        }
        }

        private void Search_product_table_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void Search_product_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            //New_Quote edt = new New_Quote();
            New_Quote edt = (New_Quote)Application.OpenForms["New_Quote"];
            int row = Search_product_table.CurrentRow.Index;
            edt.txt_p_id.Text = Convert.ToString(Search_product_table[0, row].Value);
            edt.txtPsize.Text = Convert.ToString(Search_product_table[1, row].Value);
            edt.txt_desc.Text = Convert.ToString(Search_product_table[2, row].Value);
            edt.txtUnit.Text = Convert.ToString(Search_product_table[3, row].Value);
            edt.txtUnitPrice.Text = Convert.ToString(Search_product_table[4, row].Value);

            // edt.ShowDialog();
            // string[] row_1 = { edt.txt_p_id.Text, edt.txtPsize.Text, edt.txtPdesc.Text, edt.txtUnit.Text, edt.txtUnitPrice.Text };
            // DataGridViewRow row_ = (DataGridViewRow)
            // edt.Products_Table.Rows[0].Cells.Value =Add(row_1[0].ToString());

            try
            {

                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(edt.Products_Table);
                newRow.Cells[0].Value = edt.txt_p_id.Text;
                newRow.Cells[1].Value = edt.txtPsize.Text;
                newRow.Cells[2].Value = edt.txt_desc.Text;
                newRow.Cells[3].Value = edt.txtUnit.Text;
                newRow.Cells[5].Value = edt.txtUnitPrice.Text;
                edt.Products_Table.Rows.Add(newRow);
            }
            catch { }

            edt.txt_p_id.Text = "";
            edt.txtPsize.Text = "";
            edt.txt_desc.Text = "";
            edt.txtUnit.Text = "";
            edt.txtUnitPrice.Text = "";

           

        }

        private void Search_product_table_Enter(object sender, EventArgs e)
        {
           
        }

        private void Search_product_table_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void Search_product_table_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void Search_product_table_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                //New_Quote edt = new New_Quote();
                New_Quote edt = (New_Quote)Application.OpenForms["New_Quote"];
                int row = Search_product_table.CurrentRow.Index;
                edt.txt_p_id.Text = Convert.ToString(Search_product_table[0, row].Value);
                edt.txtPsize.Text = Convert.ToString(Search_product_table[1, row].Value);
                edt.txt_desc.Text = Convert.ToString(Search_product_table[2, row].Value);
                edt.txtUnit.Text = Convert.ToString(Search_product_table[3, row].Value);
                edt.txtUnitPrice.Text = Convert.ToString(Search_product_table[4, row].Value);

                // edt.ShowDialog();
                // string[] row_1 = { edt.txt_p_id.Text, edt.txtPsize.Text, edt.txtPdesc.Text, edt.txtUnit.Text, edt.txtUnitPrice.Text };
                // DataGridViewRow row_ = (DataGridViewRow)
                // edt.Products_Table.Rows[0].Cells.Value =Add(row_1[0].ToString());

                try
                {

                    DataGridViewRow newRow = new DataGridViewRow();
                    newRow.CreateCells(edt.Products_Table);
                    newRow.Cells[0].Value = edt.txt_p_id.Text;
                    newRow.Cells[1].Value = edt.txtPsize.Text;
                    newRow.Cells[2].Value = edt.txt_desc.Text;
                    newRow.Cells[3].Value = edt.txtUnit.Text;
                    newRow.Cells[5].Value = edt.txtUnitPrice.Text;
                    edt.Products_Table.Rows.Add(newRow);
                }
                catch { }

                edt.txt_p_id.Text = "";
                edt.txtPsize.Text = "";
                edt.txt_desc.Text = "";
                edt.txtUnit.Text = "";
                edt.txtUnitPrice.Text = "";
                e.SuppressKeyPress = true;

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }  
}
