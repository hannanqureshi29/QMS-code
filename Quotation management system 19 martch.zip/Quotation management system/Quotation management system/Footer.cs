﻿using iTextSharp.text.pdf;

namespace Quotation_management_system
{
    //internal class Footer : IPdfPageEvent
    //{
    //}
}