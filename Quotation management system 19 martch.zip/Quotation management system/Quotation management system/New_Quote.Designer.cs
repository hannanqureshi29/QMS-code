﻿
namespace Quotation_management_system
{
    partial class New_Quote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_previous = new System.Windows.Forms.TextBox();
            this.txt_issued = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_validity = new System.Windows.Forms.DateTimePicker();
            this.txt_T_Condition = new System.Windows.Forms.TextBox();
            this.lbl_T_Condititon = new System.Windows.Forms.Label();
            this.txt_Pay_Term = new System.Windows.Forms.TextBox();
            this.lbl_Pay_Term = new System.Windows.Forms.Label();
            this.lbl_Val_upto = new System.Windows.Forms.Label();
            this.txt_Lead_Time = new System.Windows.Forms.TextBox();
            this.lbl_Lead_Time = new System.Windows.Forms.Label();
            this.txt_Subject = new System.Windows.Forms.TextBox();
            this.lbl_Subject = new System.Windows.Forms.Label();
            this.txt_Year = new System.Windows.Forms.TextBox();
            this.lbl_Year = new System.Windows.Forms.Label();
            this.txt_Update_Status = new System.Windows.Forms.TextBox();
            this.lbl_Update_Status = new System.Windows.Forms.Label();
            this.txt_Rev_Sta = new System.Windows.Forms.TextBox();
            this.lbl_Rev_Sta = new System.Windows.Forms.Label();
            this.txt_Quot_Num = new System.Windows.Forms.TextBox();
            this.lbl_Quot_Num = new System.Windows.Forms.Label();
            this.txt_Ref = new System.Windows.Forms.TextBox();
            this.lbl_Ref = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_c_id = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.txt_Fax = new System.Windows.Forms.TextBox();
            this.lbl_Fax = new System.Windows.Forms.Label();
            this.txt_Tele = new System.Windows.Forms.TextBox();
            this.lbl_Tele = new System.Windows.Forms.Label();
            this.txt_Desig = new System.Windows.Forms.TextBox();
            this.lbl_Desig = new System.Windows.Forms.Label();
            this.txt_Cell = new System.Windows.Forms.TextBox();
            this.lbl_Cell = new System.Windows.Forms.Label();
            this.txt_Cont_Per = new System.Windows.Forms.TextBox();
            this.lbl_Cont_Per = new System.Windows.Forms.Label();
            this.txt_Comp_N = new System.Windows.Forms.TextBox();
            this.lbl_Comp_N = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_discount_price = new System.Windows.Forms.Label();
            this.lbl_discount = new System.Windows.Forms.Label();
            this.txt_Discount = new System.Windows.Forms.TextBox();
            this.txt_disc_price = new System.Windows.Forms.TextBox();
            this.txt_desc = new System.Windows.Forms.ComboBox();
            this.txt_p_id = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_Model = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lbl_Quantity = new System.Windows.Forms.Label();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.lbl_Unit_Price = new System.Windows.Forms.Label();
            this.txtUnit = new System.Windows.Forms.TextBox();
            this.lbl_Unit = new System.Windows.Forms.Label();
            this.lbl_Make_O = new System.Windows.Forms.Label();
            this.txtPsize = new System.Windows.Forms.TextBox();
            this.lbl_Size = new System.Windows.Forms.Label();
            this.lbl_Desc = new System.Windows.Forms.Label();
            this.lbl_Pro_Type = new System.Windows.Forms.Label();
            this.lbl_PID = new System.Windows.Forms.Label();
            this.txt_from_excel = new System.Windows.Forms.Button();
            this.txtGSTAmount = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtTotalPriceGST = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtGST = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Products_Table = new System.Windows.Forms.DataGridView();
            this.btn_save = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.unit_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.txt_discnum = new System.Windows.Forms.TextBox();
            this.product_table_pdf = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_total_price = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_disc = new System.Windows.Forms.TextBox();
            this.txt_discount_price = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.panlel_grid_3 = new System.Windows.Forms.Panel();
            this.lbl_time = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.user_logged = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Products_Table)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.product_table_pdf)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.txt_previous);
            this.groupBox1.Controls.Add(this.txt_issued);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txt_validity);
            this.groupBox1.Controls.Add(this.txt_T_Condition);
            this.groupBox1.Controls.Add(this.lbl_T_Condititon);
            this.groupBox1.Controls.Add(this.txt_Pay_Term);
            this.groupBox1.Controls.Add(this.lbl_Pay_Term);
            this.groupBox1.Controls.Add(this.lbl_Val_upto);
            this.groupBox1.Controls.Add(this.txt_Lead_Time);
            this.groupBox1.Controls.Add(this.lbl_Lead_Time);
            this.groupBox1.Controls.Add(this.txt_Subject);
            this.groupBox1.Controls.Add(this.lbl_Subject);
            this.groupBox1.Controls.Add(this.txt_Year);
            this.groupBox1.Controls.Add(this.lbl_Year);
            this.groupBox1.Controls.Add(this.txt_Update_Status);
            this.groupBox1.Controls.Add(this.lbl_Update_Status);
            this.groupBox1.Controls.Add(this.txt_Rev_Sta);
            this.groupBox1.Controls.Add(this.lbl_Rev_Sta);
            this.groupBox1.Controls.Add(this.txt_Quot_Num);
            this.groupBox1.Controls.Add(this.lbl_Quot_Num);
            this.groupBox1.Controls.Add(this.txt_Ref);
            this.groupBox1.Controls.Add(this.lbl_Ref);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(2, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(1413, 112);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quotation Details";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txt_previous
            // 
            this.txt_previous.Location = new System.Drawing.Point(133, 14);
            this.txt_previous.Name = "txt_previous";
            this.txt_previous.Size = new System.Drawing.Size(49, 26);
            this.txt_previous.TabIndex = 22;
            this.txt_previous.Visible = false;
            // 
            // txt_issued
            // 
            this.txt_issued.CustomFormat = "dd/M/yyyy";
            this.txt_issued.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_issued.Location = new System.Drawing.Point(913, 63);
            this.txt_issued.Name = "txt_issued";
            this.txt_issued.Size = new System.Drawing.Size(126, 26);
            this.txt_issued.TabIndex = 9;
            this.txt_issued.Value = new System.DateTime(2021, 12, 10, 0, 0, 0, 0);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(910, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "Issued At";
            // 
            // txt_validity
            // 
            this.txt_validity.CustomFormat = "dd/M/yyyy";
            this.txt_validity.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_validity.Location = new System.Drawing.Point(1045, 63);
            this.txt_validity.Name = "txt_validity";
            this.txt_validity.Size = new System.Drawing.Size(128, 26);
            this.txt_validity.TabIndex = 10;
            this.txt_validity.Value = new System.DateTime(2021, 12, 10, 0, 0, 0, 0);
            // 
            // txt_T_Condition
            // 
            this.txt_T_Condition.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_T_Condition.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_T_Condition.Location = new System.Drawing.Point(1180, 36);
            this.txt_T_Condition.Multiline = true;
            this.txt_T_Condition.Name = "txt_T_Condition";
            this.txt_T_Condition.Size = new System.Drawing.Size(220, 53);
            this.txt_T_Condition.TabIndex = 11;
            this.txt_T_Condition.Text = "17% GST will be Extra ";
            // 
            // lbl_T_Condititon
            // 
            this.lbl_T_Condititon.AutoSize = true;
            this.lbl_T_Condititon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_T_Condititon.ForeColor = System.Drawing.Color.Black;
            this.lbl_T_Condititon.Location = new System.Drawing.Point(1178, 18);
            this.lbl_T_Condititon.Name = "lbl_T_Condititon";
            this.lbl_T_Condititon.Size = new System.Drawing.Size(139, 16);
            this.lbl_T_Condititon.TabIndex = 19;
            this.lbl_T_Condititon.Text = "Terms and Conditions";
            // 
            // txt_Pay_Term
            // 
            this.txt_Pay_Term.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Pay_Term.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Pay_Term.Location = new System.Drawing.Point(781, 64);
            this.txt_Pay_Term.Name = "txt_Pay_Term";
            this.txt_Pay_Term.Size = new System.Drawing.Size(127, 26);
            this.txt_Pay_Term.TabIndex = 8;
            this.txt_Pay_Term.Text = " Advance";
            this.txt_Pay_Term.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // lbl_Pay_Term
            // 
            this.lbl_Pay_Term.AutoSize = true;
            this.lbl_Pay_Term.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pay_Term.ForeColor = System.Drawing.Color.Black;
            this.lbl_Pay_Term.Location = new System.Drawing.Point(779, 41);
            this.lbl_Pay_Term.Name = "lbl_Pay_Term";
            this.lbl_Pay_Term.Size = new System.Drawing.Size(103, 16);
            this.lbl_Pay_Term.TabIndex = 17;
            this.lbl_Pay_Term.Text = "Payment Terms";
            // 
            // lbl_Val_upto
            // 
            this.lbl_Val_upto.AutoSize = true;
            this.lbl_Val_upto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Val_upto.ForeColor = System.Drawing.Color.Black;
            this.lbl_Val_upto.Location = new System.Drawing.Point(1042, 41);
            this.lbl_Val_upto.Name = "lbl_Val_upto";
            this.lbl_Val_upto.Size = new System.Drawing.Size(71, 16);
            this.lbl_Val_upto.TabIndex = 15;
            this.lbl_Val_upto.Text = "Valid Upto";
            // 
            // txt_Lead_Time
            // 
            this.txt_Lead_Time.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Lead_Time.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Lead_Time.Location = new System.Drawing.Point(669, 64);
            this.txt_Lead_Time.Name = "txt_Lead_Time";
            this.txt_Lead_Time.Size = new System.Drawing.Size(106, 26);
            this.txt_Lead_Time.TabIndex = 7;
            this.txt_Lead_Time.Text = "7 Days";
            // 
            // lbl_Lead_Time
            // 
            this.lbl_Lead_Time.AutoSize = true;
            this.lbl_Lead_Time.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lead_Time.ForeColor = System.Drawing.Color.Black;
            this.lbl_Lead_Time.Location = new System.Drawing.Point(666, 42);
            this.lbl_Lead_Time.Name = "lbl_Lead_Time";
            this.lbl_Lead_Time.Size = new System.Drawing.Size(73, 16);
            this.lbl_Lead_Time.TabIndex = 13;
            this.lbl_Lead_Time.Text = "Lead Time";
            this.lbl_Lead_Time.Click += new System.EventHandler(this.label10_Click);
            // 
            // txt_Subject
            // 
            this.txt_Subject.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Subject.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Subject.Location = new System.Drawing.Point(553, 64);
            this.txt_Subject.Name = "txt_Subject";
            this.txt_Subject.Size = new System.Drawing.Size(111, 26);
            this.txt_Subject.TabIndex = 6;
            this.txt_Subject.Text = "Quotation";
            // 
            // lbl_Subject
            // 
            this.lbl_Subject.AutoSize = true;
            this.lbl_Subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subject.ForeColor = System.Drawing.Color.Black;
            this.lbl_Subject.Location = new System.Drawing.Point(550, 42);
            this.lbl_Subject.Name = "lbl_Subject";
            this.lbl_Subject.Size = new System.Drawing.Size(53, 16);
            this.lbl_Subject.TabIndex = 11;
            this.lbl_Subject.Text = "Subject";
            this.lbl_Subject.Click += new System.EventHandler(this.label11_Click);
            // 
            // txt_Year
            // 
            this.txt_Year.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Year.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Year.Location = new System.Drawing.Point(471, 64);
            this.txt_Year.Name = "txt_Year";
            this.txt_Year.Size = new System.Drawing.Size(77, 26);
            this.txt_Year.TabIndex = 5;
            this.txt_Year.Text = "2022";
            // 
            // lbl_Year
            // 
            this.lbl_Year.AutoSize = true;
            this.lbl_Year.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Year.ForeColor = System.Drawing.Color.Black;
            this.lbl_Year.Location = new System.Drawing.Point(472, 42);
            this.lbl_Year.Name = "lbl_Year";
            this.lbl_Year.Size = new System.Drawing.Size(37, 16);
            this.lbl_Year.TabIndex = 9;
            this.lbl_Year.Text = "Year";
            // 
            // txt_Update_Status
            // 
            this.txt_Update_Status.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Update_Status.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Update_Status.Location = new System.Drawing.Point(243, 64);
            this.txt_Update_Status.Name = "txt_Update_Status";
            this.txt_Update_Status.Size = new System.Drawing.Size(109, 26);
            this.txt_Update_Status.TabIndex = 3;
            this.txt_Update_Status.Text = "0";
            // 
            // lbl_Update_Status
            // 
            this.lbl_Update_Status.AutoSize = true;
            this.lbl_Update_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Update_Status.ForeColor = System.Drawing.Color.Black;
            this.lbl_Update_Status.Location = new System.Drawing.Point(240, 42);
            this.lbl_Update_Status.Name = "lbl_Update_Status";
            this.lbl_Update_Status.Size = new System.Drawing.Size(93, 16);
            this.lbl_Update_Status.TabIndex = 7;
            this.lbl_Update_Status.Text = "Update Status";
            // 
            // txt_Rev_Sta
            // 
            this.txt_Rev_Sta.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Rev_Sta.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Rev_Sta.Location = new System.Drawing.Point(358, 64);
            this.txt_Rev_Sta.Name = "txt_Rev_Sta";
            this.txt_Rev_Sta.Size = new System.Drawing.Size(108, 26);
            this.txt_Rev_Sta.TabIndex = 4;
            this.txt_Rev_Sta.Text = "0";
            // 
            // lbl_Rev_Sta
            // 
            this.lbl_Rev_Sta.AutoSize = true;
            this.lbl_Rev_Sta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rev_Sta.ForeColor = System.Drawing.Color.Black;
            this.lbl_Rev_Sta.Location = new System.Drawing.Point(355, 42);
            this.lbl_Rev_Sta.Name = "lbl_Rev_Sta";
            this.lbl_Rev_Sta.Size = new System.Drawing.Size(101, 16);
            this.lbl_Rev_Sta.TabIndex = 5;
            this.lbl_Rev_Sta.Text = "Revision Status";
            // 
            // txt_Quot_Num
            // 
            this.txt_Quot_Num.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Quot_Num.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Quot_Num.Location = new System.Drawing.Point(124, 64);
            this.txt_Quot_Num.Name = "txt_Quot_Num";
            this.txt_Quot_Num.Size = new System.Drawing.Size(113, 26);
            this.txt_Quot_Num.TabIndex = 2;
            this.txt_Quot_Num.TextChanged += new System.EventHandler(this.txt_Quot_Num_TextChanged);
            this.txt_Quot_Num.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Quot_Num_KeyDown);
            // 
            // lbl_Quot_Num
            // 
            this.lbl_Quot_Num.AutoSize = true;
            this.lbl_Quot_Num.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quot_Num.ForeColor = System.Drawing.Color.Black;
            this.lbl_Quot_Num.Location = new System.Drawing.Point(121, 43);
            this.lbl_Quot_Num.Name = "lbl_Quot_Num";
            this.lbl_Quot_Num.Size = new System.Drawing.Size(116, 16);
            this.lbl_Quot_Num.TabIndex = 3;
            this.lbl_Quot_Num.Text = "Quotation Number";
            // 
            // txt_Ref
            // 
            this.txt_Ref.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Ref.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Ref.Location = new System.Drawing.Point(3, 64);
            this.txt_Ref.Name = "txt_Ref";
            this.txt_Ref.Size = new System.Drawing.Size(117, 26);
            this.txt_Ref.TabIndex = 1;
            this.txt_Ref.Text = "0";
            this.txt_Ref.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txt_Ref.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Ref_KeyDown);
            // 
            // lbl_Ref
            // 
            this.lbl_Ref.AutoSize = true;
            this.lbl_Ref.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ref.ForeColor = System.Drawing.Color.Black;
            this.lbl_Ref.Location = new System.Drawing.Point(3, 42);
            this.lbl_Ref.Name = "lbl_Ref";
            this.lbl_Ref.Size = new System.Drawing.Size(81, 16);
            this.lbl_Ref.TabIndex = 0;
            this.lbl_Ref.Text = "Reference #";
            this.lbl_Ref.Click += new System.EventHandler(this.label2_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkCyan;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(1276, 27);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 49);
            this.button2.TabIndex = 30;
            this.button2.Text = "Add New Product";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkCyan;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(1178, 27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 49);
            this.button1.TabIndex = 29;
            this.button1.Text = "Add Below";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkCyan;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(1176, 30);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 49);
            this.button3.TabIndex = 20;
            this.button3.Text = "Add New Customer";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkCyan;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(1300, 30);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(107, 49);
            this.button4.TabIndex = 21;
            this.button4.Text = "Customer List";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.Controls.Add(this.txt_address);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txt_c_id);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.txt_Email);
            this.groupBox2.Controls.Add(this.lbl_Email);
            this.groupBox2.Controls.Add(this.txt_Fax);
            this.groupBox2.Controls.Add(this.lbl_Fax);
            this.groupBox2.Controls.Add(this.txt_Tele);
            this.groupBox2.Controls.Add(this.lbl_Tele);
            this.groupBox2.Controls.Add(this.txt_Desig);
            this.groupBox2.Controls.Add(this.lbl_Desig);
            this.groupBox2.Controls.Add(this.txt_Cell);
            this.groupBox2.Controls.Add(this.lbl_Cell);
            this.groupBox2.Controls.Add(this.txt_Cont_Per);
            this.groupBox2.Controls.Add(this.lbl_Cont_Per);
            this.groupBox2.Controls.Add(this.txt_Comp_N);
            this.groupBox2.Controls.Add(this.lbl_Comp_N);
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(2, 114);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox2.Size = new System.Drawing.Size(1412, 101);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CustomerDetails";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // txt_address
            // 
            this.txt_address.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_address.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_address.Location = new System.Drawing.Point(1010, 53);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(162, 26);
            this.txt_address.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(1009, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 16);
            this.label8.TabIndex = 1004;
            this.label8.Text = "Address";
            // 
            // txt_c_id
            // 
            this.txt_c_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_c_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_c_id.Location = new System.Drawing.Point(6, 53);
            this.txt_c_id.Name = "txt_c_id";
            this.txt_c_id.Size = new System.Drawing.Size(19, 26);
            this.txt_c_id.TabIndex = 1003;
            this.txt_c_id.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtID_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(4, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 16);
            this.label6.TabIndex = 1002;
            this.label6.Text = "ID";
            // 
            // txt_Email
            // 
            this.txt_Email.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_Email.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Email.Location = new System.Drawing.Point(846, 53);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(161, 26);
            this.txt_Email.TabIndex = 18;
            this.txt_Email.TextChanged += new System.EventHandler(this.txt_Email_TextChanged);
            this.txt_Email.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Email_KeyDown);
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email.ForeColor = System.Drawing.Color.Black;
            this.lbl_Email.Location = new System.Drawing.Point(842, 31);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(42, 16);
            this.lbl_Email.TabIndex = 17;
            this.lbl_Email.Text = "Email";
            // 
            // txt_Fax
            // 
            this.txt_Fax.Location = new System.Drawing.Point(704, 53);
            this.txt_Fax.Name = "txt_Fax";
            this.txt_Fax.Size = new System.Drawing.Size(140, 26);
            this.txt_Fax.TabIndex = 17;
            // 
            // lbl_Fax
            // 
            this.lbl_Fax.AutoSize = true;
            this.lbl_Fax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fax.ForeColor = System.Drawing.Color.Black;
            this.lbl_Fax.Location = new System.Drawing.Point(702, 30);
            this.lbl_Fax.Name = "lbl_Fax";
            this.lbl_Fax.Size = new System.Drawing.Size(40, 16);
            this.lbl_Fax.TabIndex = 13;
            this.lbl_Fax.Text = "Fax #";
            this.lbl_Fax.Click += new System.EventHandler(this.label15_Click);
            // 
            // txt_Tele
            // 
            this.txt_Tele.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_Tele.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Tele.Location = new System.Drawing.Point(580, 53);
            this.txt_Tele.Name = "txt_Tele";
            this.txt_Tele.Size = new System.Drawing.Size(121, 26);
            this.txt_Tele.TabIndex = 16;
            this.txt_Tele.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Tele_KeyDown);
            // 
            // lbl_Tele
            // 
            this.lbl_Tele.AutoSize = true;
            this.lbl_Tele.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tele.ForeColor = System.Drawing.Color.Black;
            this.lbl_Tele.Location = new System.Drawing.Point(577, 30);
            this.lbl_Tele.Name = "lbl_Tele";
            this.lbl_Tele.Size = new System.Drawing.Size(74, 16);
            this.lbl_Tele.TabIndex = 9;
            this.lbl_Tele.Text = "Telephone";
            // 
            // txt_Desig
            // 
            this.txt_Desig.Location = new System.Drawing.Point(330, 53);
            this.txt_Desig.Name = "txt_Desig";
            this.txt_Desig.Size = new System.Drawing.Size(117, 26);
            this.txt_Desig.TabIndex = 14;
            // 
            // lbl_Desig
            // 
            this.lbl_Desig.AutoSize = true;
            this.lbl_Desig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Desig.ForeColor = System.Drawing.Color.Black;
            this.lbl_Desig.Location = new System.Drawing.Point(327, 30);
            this.lbl_Desig.Name = "lbl_Desig";
            this.lbl_Desig.Size = new System.Drawing.Size(80, 16);
            this.lbl_Desig.TabIndex = 7;
            this.lbl_Desig.Text = "Designation";
            // 
            // txt_Cell
            // 
            this.txt_Cell.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Cell.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Cell.Location = new System.Drawing.Point(449, 53);
            this.txt_Cell.Name = "txt_Cell";
            this.txt_Cell.Size = new System.Drawing.Size(128, 26);
            this.txt_Cell.TabIndex = 15;
            this.txt_Cell.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Cell_KeyDown);
            // 
            // lbl_Cell
            // 
            this.lbl_Cell.AutoSize = true;
            this.lbl_Cell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cell.ForeColor = System.Drawing.Color.Black;
            this.lbl_Cell.Location = new System.Drawing.Point(448, 30);
            this.lbl_Cell.Name = "lbl_Cell";
            this.lbl_Cell.Size = new System.Drawing.Size(41, 16);
            this.lbl_Cell.TabIndex = 5;
            this.lbl_Cell.Text = "Cell #";
            // 
            // txt_Cont_Per
            // 
            this.txt_Cont_Per.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Cont_Per.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Cont_Per.Location = new System.Drawing.Point(200, 53);
            this.txt_Cont_Per.Name = "txt_Cont_Per";
            this.txt_Cont_Per.Size = new System.Drawing.Size(127, 26);
            this.txt_Cont_Per.TabIndex = 13;
            this.txt_Cont_Per.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Cont_Per_KeyDown);
            // 
            // lbl_Cont_Per
            // 
            this.lbl_Cont_Per.AutoSize = true;
            this.lbl_Cont_Per.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cont_Per.ForeColor = System.Drawing.Color.Black;
            this.lbl_Cont_Per.Location = new System.Drawing.Point(197, 29);
            this.lbl_Cont_Per.Name = "lbl_Cont_Per";
            this.lbl_Cont_Per.Size = new System.Drawing.Size(99, 16);
            this.lbl_Cont_Per.TabIndex = 3;
            this.lbl_Cont_Per.Text = "Contact Person";
            // 
            // txt_Comp_N
            // 
            this.txt_Comp_N.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Comp_N.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Comp_N.Location = new System.Drawing.Point(31, 53);
            this.txt_Comp_N.Name = "txt_Comp_N";
            this.txt_Comp_N.Size = new System.Drawing.Size(165, 26);
            this.txt_Comp_N.TabIndex = 12;
            this.txt_Comp_N.TextChanged += new System.EventHandler(this.txt_Comp_N_TextChanged);
            this.txt_Comp_N.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Comp_N_KeyDown);
            // 
            // lbl_Comp_N
            // 
            this.lbl_Comp_N.AutoSize = true;
            this.lbl_Comp_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Comp_N.ForeColor = System.Drawing.Color.Black;
            this.lbl_Comp_N.Location = new System.Drawing.Point(28, 30);
            this.lbl_Comp_N.Name = "lbl_Comp_N";
            this.lbl_Comp_N.Size = new System.Drawing.Size(106, 16);
            this.lbl_Comp_N.TabIndex = 0;
            this.lbl_Comp_N.Text = "Company Name";
            // 
            // groupBox3
            // 
            this.groupBox3.AutoSize = true;
            this.groupBox3.Controls.Add(this.txtTotal);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.lbl_discount_price);
            this.groupBox3.Controls.Add(this.lbl_discount);
            this.groupBox3.Controls.Add(this.txt_Discount);
            this.groupBox3.Controls.Add(this.txt_disc_price);
            this.groupBox3.Controls.Add(this.txt_desc);
            this.groupBox3.Controls.Add(this.txt_p_id);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.lbl_Model);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txtQuantity);
            this.groupBox3.Controls.Add(this.lbl_Quantity);
            this.groupBox3.Controls.Add(this.txtUnitPrice);
            this.groupBox3.Controls.Add(this.lbl_Unit_Price);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.txtUnit);
            this.groupBox3.Controls.Add(this.lbl_Unit);
            this.groupBox3.Controls.Add(this.lbl_Make_O);
            this.groupBox3.Controls.Add(this.txtPsize);
            this.groupBox3.Controls.Add(this.lbl_Size);
            this.groupBox3.Controls.Add(this.lbl_Desc);
            this.groupBox3.Controls.Add(this.lbl_Pro_Type);
            this.groupBox3.Controls.Add(this.lbl_PID);
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Location = new System.Drawing.Point(2, 219);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox3.Size = new System.Drawing.Size(1412, 99);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Product Details";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.SystemColors.Window;
            this.txtTotal.Location = new System.Drawing.Point(1040, 50);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(135, 26);
            this.txtTotal.TabIndex = 1015;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(1037, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(88, 16);
            this.label23.TabIndex = 1014;
            this.label23.Text = "Product Total";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(903, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 16);
            this.label11.TabIndex = 1013;
            this.label11.Text = "%";
            // 
            // lbl_discount_price
            // 
            this.lbl_discount_price.AutoSize = true;
            this.lbl_discount_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_discount_price.ForeColor = System.Drawing.Color.Black;
            this.lbl_discount_price.Location = new System.Drawing.Point(924, 27);
            this.lbl_discount_price.Name = "lbl_discount_price";
            this.lbl_discount_price.Size = new System.Drawing.Size(110, 16);
            this.lbl_discount_price.TabIndex = 1012;
            this.lbl_discount_price.Text = "Discounted Price";
            // 
            // lbl_discount
            // 
            this.lbl_discount.AutoSize = true;
            this.lbl_discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_discount.ForeColor = System.Drawing.Color.Black;
            this.lbl_discount.Location = new System.Drawing.Point(830, 27);
            this.lbl_discount.Name = "lbl_discount";
            this.lbl_discount.Size = new System.Drawing.Size(60, 16);
            this.lbl_discount.TabIndex = 1011;
            this.lbl_discount.Text = "Discount";
            // 
            // txt_Discount
            // 
            this.txt_Discount.Location = new System.Drawing.Point(832, 50);
            this.txt_Discount.Name = "txt_Discount";
            this.txt_Discount.Size = new System.Drawing.Size(68, 26);
            this.txt_Discount.TabIndex = 27;
            this.txt_Discount.Text = "0";
            this.txt_Discount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Discount_KeyDown);
            this.txt_Discount.Leave += new System.EventHandler(this.textBox2_Leave);
            // 
            // txt_disc_price
            // 
            this.txt_disc_price.BackColor = System.Drawing.SystemColors.Window;
            this.txt_disc_price.Location = new System.Drawing.Point(926, 50);
            this.txt_disc_price.Name = "txt_disc_price";
            this.txt_disc_price.ReadOnly = true;
            this.txt_disc_price.Size = new System.Drawing.Size(110, 26);
            this.txt_disc_price.TabIndex = 28;
            this.txt_disc_price.Text = "0";
            this.txt_disc_price.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_disc_price_KeyDown);
            this.txt_disc_price.Leave += new System.EventHandler(this.txt_disc_price_Leave);
            // 
            // txt_desc
            // 
            this.txt_desc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_desc.DropDownWidth = 416;
            this.txt_desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_desc.FormattingEnabled = true;
            this.txt_desc.IntegralHeight = false;
            this.txt_desc.ItemHeight = 15;
            this.txt_desc.Location = new System.Drawing.Point(104, 52);
            this.txt_desc.MaxDropDownItems = 10;
            this.txt_desc.Name = "txt_desc";
            this.txt_desc.Size = new System.Drawing.Size(484, 23);
            this.txt_desc.TabIndex = 23;
            this.txt_desc.SelectedIndexChanged += new System.EventHandler(this.txt_desc_SelectedIndexChanged);
            this.txt_desc.TextUpdate += new System.EventHandler(this.comboBox1_TextUpdate);
            this.txt_desc.Enter += new System.EventHandler(this.comboBox1_Enter);
            this.txt_desc.KeyDown += new System.Windows.Forms.KeyEventHandler(this.comboBox1_KeyDown);
            this.txt_desc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_desc_KeyPress);
            this.txt_desc.ImeModeChanged += new System.EventHandler(this.txt_desc_ImeModeChanged);
            // 
            // txt_p_id
            // 
            this.txt_p_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_p_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_p_id.Location = new System.Drawing.Point(6, 50);
            this.txt_p_id.Name = "txt_p_id";
            this.txt_p_id.Size = new System.Drawing.Size(44, 26);
            this.txt_p_id.TabIndex = 1006;
            this.txt_p_id.TextChanged += new System.EventHandler(this.txt_p_id_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(4, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(21, 16);
            this.label7.TabIndex = 1005;
            this.label7.Text = "ID";
            // 
            // lbl_Model
            // 
            this.lbl_Model.AutoSize = true;
            this.lbl_Model.Location = new System.Drawing.Point(532, -33);
            this.lbl_Model.Name = "lbl_Model";
            this.lbl_Model.Size = new System.Drawing.Size(52, 20);
            this.lbl_Model.TabIndex = 32;
            this.lbl_Model.Text = "Model";
            this.lbl_Model.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(732, 55);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 16);
            this.label16.TabIndex = 1002;
            this.label16.Text = "X";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(662, 50);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(66, 26);
            this.txtQuantity.TabIndex = 25;
            this.txtQuantity.TextChanged += new System.EventHandler(this.txtQuantity_TextChanged);
            this.txtQuantity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox13_KeyDown);
            this.txtQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuantity_KeyPress);
            this.txtQuantity.Leave += new System.EventHandler(this.txtQuantity_Leave);
            // 
            // lbl_Quantity
            // 
            this.lbl_Quantity.AutoSize = true;
            this.lbl_Quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quantity.ForeColor = System.Drawing.Color.Black;
            this.lbl_Quantity.Location = new System.Drawing.Point(658, 27);
            this.lbl_Quantity.Name = "lbl_Quantity";
            this.lbl_Quantity.Size = new System.Drawing.Size(56, 16);
            this.lbl_Quantity.TabIndex = 21;
            this.lbl_Quantity.Text = "Quantity";
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtUnitPrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtUnitPrice.Location = new System.Drawing.Point(749, 50);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(77, 26);
            this.txtUnitPrice.TabIndex = 26;
            this.txtUnitPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtUnitPrice_KeyDown);
            this.txtUnitPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUnitPrice_KeyPress);
            this.txtUnitPrice.Leave += new System.EventHandler(this.txtUnitPrice_Leave);
            // 
            // lbl_Unit_Price
            // 
            this.lbl_Unit_Price.AutoSize = true;
            this.lbl_Unit_Price.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Unit_Price.ForeColor = System.Drawing.Color.Black;
            this.lbl_Unit_Price.Location = new System.Drawing.Point(747, 28);
            this.lbl_Unit_Price.Name = "lbl_Unit_Price";
            this.lbl_Unit_Price.Size = new System.Drawing.Size(65, 16);
            this.lbl_Unit_Price.TabIndex = 19;
            this.lbl_Unit_Price.Text = "Unit Price";
            // 
            // txtUnit
            // 
            this.txtUnit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtUnit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtUnit.Location = new System.Drawing.Point(591, 50);
            this.txtUnit.Name = "txtUnit";
            this.txtUnit.Size = new System.Drawing.Size(67, 26);
            this.txtUnit.TabIndex = 24;
            this.txtUnit.TextChanged += new System.EventHandler(this.txtUnit_TextChanged);
            // 
            // lbl_Unit
            // 
            this.lbl_Unit.AutoSize = true;
            this.lbl_Unit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Unit.ForeColor = System.Drawing.Color.Black;
            this.lbl_Unit.Location = new System.Drawing.Point(589, 27);
            this.lbl_Unit.Name = "lbl_Unit";
            this.lbl_Unit.Size = new System.Drawing.Size(31, 16);
            this.lbl_Unit.TabIndex = 17;
            this.lbl_Unit.Text = "Unit";
            this.lbl_Unit.Click += new System.EventHandler(this.label22_Click);
            // 
            // lbl_Make_O
            // 
            this.lbl_Make_O.AutoSize = true;
            this.lbl_Make_O.Location = new System.Drawing.Point(883, -33);
            this.lbl_Make_O.Name = "lbl_Make_O";
            this.lbl_Make_O.Size = new System.Drawing.Size(124, 20);
            this.lbl_Make_O.TabIndex = 9;
            this.lbl_Make_O.Text = "Make and Origin";
            this.lbl_Make_O.Visible = false;
            this.lbl_Make_O.Click += new System.EventHandler(this.label26_Click);
            // 
            // txtPsize
            // 
            this.txtPsize.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtPsize.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPsize.Location = new System.Drawing.Point(56, 50);
            this.txtPsize.Name = "txtPsize";
            this.txtPsize.Size = new System.Drawing.Size(44, 26);
            this.txtPsize.TabIndex = 22;
            this.txtPsize.TextChanged += new System.EventHandler(this.txtPsize_TextChanged);
            // 
            // lbl_Size
            // 
            this.lbl_Size.AutoSize = true;
            this.lbl_Size.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Size.ForeColor = System.Drawing.Color.Black;
            this.lbl_Size.Location = new System.Drawing.Point(55, 27);
            this.lbl_Size.Name = "lbl_Size";
            this.lbl_Size.Size = new System.Drawing.Size(34, 16);
            this.lbl_Size.TabIndex = 7;
            this.lbl_Size.Text = "Size";
            // 
            // lbl_Desc
            // 
            this.lbl_Desc.AutoSize = true;
            this.lbl_Desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Desc.ForeColor = System.Drawing.Color.Black;
            this.lbl_Desc.Location = new System.Drawing.Point(103, 27);
            this.lbl_Desc.Name = "lbl_Desc";
            this.lbl_Desc.Size = new System.Drawing.Size(76, 16);
            this.lbl_Desc.TabIndex = 5;
            this.lbl_Desc.Text = "Description";
            this.lbl_Desc.Click += new System.EventHandler(this.lbl_Desc_Click);
            // 
            // lbl_Pro_Type
            // 
            this.lbl_Pro_Type.AutoSize = true;
            this.lbl_Pro_Type.Location = new System.Drawing.Point(206, -33);
            this.lbl_Pro_Type.Name = "lbl_Pro_Type";
            this.lbl_Pro_Type.Size = new System.Drawing.Size(102, 20);
            this.lbl_Pro_Type.TabIndex = 3;
            this.lbl_Pro_Type.Text = "Product Type";
            this.lbl_Pro_Type.Visible = false;
            // 
            // lbl_PID
            // 
            this.lbl_PID.AutoSize = true;
            this.lbl_PID.Location = new System.Drawing.Point(63, -33);
            this.lbl_PID.Name = "lbl_PID";
            this.lbl_PID.Size = new System.Drawing.Size(106, 20);
            this.lbl_PID.TabIndex = 0;
            this.lbl_PID.Text = "Product Code";
            this.lbl_PID.Visible = false;
            // 
            // txt_from_excel
            // 
            this.txt_from_excel.BackColor = System.Drawing.Color.DarkCyan;
            this.txt_from_excel.FlatAppearance.BorderSize = 0;
            this.txt_from_excel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_from_excel.Location = new System.Drawing.Point(213, 4);
            this.txt_from_excel.Name = "txt_from_excel";
            this.txt_from_excel.Size = new System.Drawing.Size(246, 30);
            this.txt_from_excel.TabIndex = 1007;
            this.txt_from_excel.Text = "Paste Description From Excel";
            this.txt_from_excel.UseVisualStyleBackColor = false;
            this.txt_from_excel.Click += new System.EventHandler(this.txt_from_excel_Click);
            this.txt_from_excel.Enter += new System.EventHandler(this.txt_from_excel_Enter);
            this.txt_from_excel.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_from_excel_KeyDown);
            this.txt_from_excel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_from_excel_KeyPress);
            // 
            // txtGSTAmount
            // 
            this.txtGSTAmount.Location = new System.Drawing.Point(12, 239);
            this.txtGSTAmount.Name = "txtGSTAmount";
            this.txtGSTAmount.Size = new System.Drawing.Size(186, 22);
            this.txtGSTAmount.TabIndex = 36;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(10, 218);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(84, 16);
            this.label35.TabIndex = 30;
            this.label35.Text = "GST Amount";
            // 
            // txtTotalPriceGST
            // 
            this.txtTotalPriceGST.Location = new System.Drawing.Point(12, 287);
            this.txtTotalPriceGST.Name = "txtTotalPriceGST";
            this.txtTotalPriceGST.Size = new System.Drawing.Size(186, 22);
            this.txtTotalPriceGST.TabIndex = 36;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(9, 265);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(127, 16);
            this.label25.TabIndex = 28;
            this.label25.Text = "Total Price Incl GST";
            // 
            // txtGST
            // 
            this.txtGST.Location = new System.Drawing.Point(12, 192);
            this.txtGST.Name = "txtGST";
            this.txtGST.Size = new System.Drawing.Size(186, 22);
            this.txtGST.TabIndex = 35;
            this.txtGST.Text = "0";
            this.txtGST.TextChanged += new System.EventHandler(this.txtGST_TextChanged);
            this.txtGST.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtGST_KeyDown);
            this.txtGST.Leave += new System.EventHandler(this.txtGST_Leave);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(12, 170);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(51, 16);
            this.label24.TabIndex = 26;
            this.label24.Text = "GST %";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Products_Table
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.Products_Table.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.Products_Table.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Products_Table.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Products_Table.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.Products_Table.ColumnHeadersHeight = 50;
            this.Products_Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.Products_Table.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Products_Table.Location = new System.Drawing.Point(3, 36);
            this.Products_Table.Name = "Products_Table";
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            this.Products_Table.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.Products_Table.Size = new System.Drawing.Size(1197, 428);
            this.Products_Table.TabIndex = 31;
            this.Products_Table.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellClick);
            this.Products_Table.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.Products_Table.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellContentDoubleClick);
            this.Products_Table.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellEndEdit);
            this.Products_Table.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellEnter);
            this.Products_Table.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellLeave);
            this.Products_Table.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellValueChanged);
            this.Products_Table.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.Products_Table_EditingControlShowing);
            this.Products_Table.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.Products_Table_UserDeletedRow);
            this.Products_Table.Enter += new System.EventHandler(this.Products_Table_Enter);
            this.Products_Table.Leave += new System.EventHandler(this.Products_Table_Leave);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_save.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(15, 328);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(185, 32);
            this.btn_save.TabIndex = 37;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(15, 373);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(185, 32);
            this.button6.TabIndex = 38;
            this.button6.Text = "PDF";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Location = new System.Drawing.Point(0, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1581, 961);
            this.panel2.TabIndex = 32;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.unit_txt);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.txt_discnum);
            this.panel3.Controls.Add(this.product_table_pdf);
            this.panel3.Controls.Add(this.txt_from_excel);
            this.panel3.Controls.Add(this.Products_Table);
            this.panel3.Location = new System.Drawing.Point(0, 371);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1203, 468);
            this.panel3.TabIndex = 32;
            // 
            // unit_txt
            // 
            this.unit_txt.Location = new System.Drawing.Point(477, 7);
            this.unit_txt.Name = "unit_txt";
            this.unit_txt.Size = new System.Drawing.Size(76, 26);
            this.unit_txt.TabIndex = 1017;
            this.unit_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.unit_txt_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(734, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 1016;
            this.label3.Text = "Discount";
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DarkCyan;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(1016, 3);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(183, 32);
            this.button12.TabIndex = 1014;
            this.button12.Text = "Export To Excel";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkCyan;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(4, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(92, 32);
            this.button8.TabIndex = 1010;
            this.button8.Text = "Clear";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // txt_discnum
            // 
            this.txt_discnum.Location = new System.Drawing.Point(798, 9);
            this.txt_discnum.Name = "txt_discnum";
            this.txt_discnum.Size = new System.Drawing.Size(76, 26);
            this.txt_discnum.TabIndex = 1009;
            this.txt_discnum.TextChanged += new System.EventHandler(this.txt_discnum_TextChanged);
            this.txt_discnum.Enter += new System.EventHandler(this.txt_discnum_Enter);
            this.txt_discnum.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_discnum_KeyDown);
            // 
            // product_table_pdf
            // 
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.product_table_pdf.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.product_table_pdf.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.product_table_pdf.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.product_table_pdf.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.product_table_pdf.ColumnHeadersHeight = 50;
            this.product_table_pdf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.product_table_pdf.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.product_table_pdf.Location = new System.Drawing.Point(63, 184);
            this.product_table_pdf.Name = "product_table_pdf";
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            this.product_table_pdf.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.product_table_pdf.Size = new System.Drawing.Size(939, 188);
            this.product_table_pdf.TabIndex = 1008;
            this.product_table_pdf.Visible = false;
            this.product_table_pdf.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.product_table_pdf_CellLeave);
            this.product_table_pdf.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.product_table_pdf_EditingControlShowing);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(8, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 16);
            this.label2.TabIndex = 32;
            this.label2.Text = "Total Price Exclusive GST";
            // 
            // txt_total_price
            // 
            this.txt_total_price.Location = new System.Drawing.Point(12, 49);
            this.txt_total_price.Name = "txt_total_price";
            this.txt_total_price.Size = new System.Drawing.Size(186, 22);
            this.txt_total_price.TabIndex = 32;
            this.txt_total_price.TextChanged += new System.EventHandler(this.txt_total_price_TextChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.txt_disc);
            this.panel4.Controls.Add(this.txt_discount_price);
            this.panel4.Controls.Add(this.button7);
            this.panel4.Controls.Add(this.button6);
            this.panel4.Controls.Add(this.btn_save);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.txtGSTAmount);
            this.panel4.Controls.Add(this.txtTotalPriceGST);
            this.panel4.Controls.Add(this.txt_total_price);
            this.panel4.Controls.Add(this.txtGST);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.label35);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(1201, 371);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(213, 464);
            this.panel4.TabIndex = 500;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(12, 123);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 16);
            this.label10.TabIndex = 1014;
            this.label10.Text = "Total Discount Price";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(12, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 16);
            this.label9.TabIndex = 1013;
            this.label9.Text = "Total Discount %";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txt_disc
            // 
            this.txt_disc.Location = new System.Drawing.Point(13, 97);
            this.txt_disc.Name = "txt_disc";
            this.txt_disc.Size = new System.Drawing.Size(184, 22);
            this.txt_disc.TabIndex = 33;
            this.txt_disc.Text = "0";
            this.txt_disc.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_KeyDown);
            this.txt_disc.Leave += new System.EventHandler(this.txt_disc_Leave);
            // 
            // txt_discount_price
            // 
            this.txt_discount_price.Location = new System.Drawing.Point(13, 144);
            this.txt_discount_price.Name = "txt_discount_price";
            this.txt_discount_price.Size = new System.Drawing.Size(184, 22);
            this.txt_discount_price.TabIndex = 34;
            this.txt_discount_price.Text = "0";
            this.txt_discount_price.TextChanged += new System.EventHandler(this.txt_discount_price_TextChanged);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkCyan;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(15, 415);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(185, 38);
            this.button7.TabIndex = 39;
            this.button7.Text = "Check and Save Products";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // panlel_grid_3
            // 
            this.panlel_grid_3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panlel_grid_3.Location = new System.Drawing.Point(0, 788);
            this.panlel_grid_3.Name = "panlel_grid_3";
            this.panlel_grid_3.Size = new System.Drawing.Size(1424, 53);
            this.panlel_grid_3.TabIndex = 33;
            this.panlel_grid_3.Visible = false;
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lbl_time.Location = new System.Drawing.Point(180, 9);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(69, 29);
            this.lbl_time.TabIndex = 10;
            this.lbl_time.Text = "Time";
            this.lbl_time.Click += new System.EventHandler(this.label34_Click);
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.Location = new System.Drawing.Point(13, 10);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(63, 29);
            this.lbl_date.TabIndex = 9;
            this.lbl_date.Text = "Date";
            this.lbl_date.Click += new System.EventHandler(this.label33_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(695, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Quotation";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.user_logged);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lbl_date);
            this.panel1.Controls.Add(this.lbl_time);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1584, 50);
            this.panel1.TabIndex = 17;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // user_logged
            // 
            this.user_logged.AutoSize = true;
            this.user_logged.Font = new System.Drawing.Font("Arial", 15.75F);
            this.user_logged.Location = new System.Drawing.Point(1250, 13);
            this.user_logged.Name = "user_logged";
            this.user_logged.Size = new System.Drawing.Size(152, 24);
            this.user_logged.TabIndex = 21;
            this.user_logged.Text = "user_logged_in";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 15.75F);
            this.label12.Location = new System.Drawing.Point(1193, 14);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 24);
            this.label12.TabIndex = 20;
            this.label12.Text = "User:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // New_Quote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1424, 841);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panlel_grid_3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ForeColor = System.Drawing.Color.White;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "New_Quote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Quotation";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.New_Quote_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.New_Quote_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.New_Quote_KeyPress);
            this.Resize += new System.EventHandler(this.New_Quote_Resize);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Products_Table)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.product_table_pdf)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_T_Condition;
        private System.Windows.Forms.Label lbl_T_Condititon;
        private System.Windows.Forms.TextBox txt_Pay_Term;
        private System.Windows.Forms.Label lbl_Pay_Term;
        private System.Windows.Forms.Label lbl_Val_upto;
        private System.Windows.Forms.TextBox txt_Lead_Time;
        private System.Windows.Forms.Label lbl_Lead_Time;
        private System.Windows.Forms.TextBox txt_Subject;
        private System.Windows.Forms.Label lbl_Subject;
        private System.Windows.Forms.TextBox txt_Year;
        private System.Windows.Forms.Label lbl_Year;
        private System.Windows.Forms.TextBox txt_Update_Status;
        private System.Windows.Forms.Label lbl_Update_Status;
        private System.Windows.Forms.TextBox txt_Rev_Sta;
        private System.Windows.Forms.Label lbl_Rev_Sta;
        private System.Windows.Forms.TextBox txt_Quot_Num;
        private System.Windows.Forms.Label lbl_Quot_Num;
        private System.Windows.Forms.TextBox txt_Ref;
        private System.Windows.Forms.Label lbl_Ref;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.TextBox txt_Fax;
        private System.Windows.Forms.Label lbl_Fax;
        private System.Windows.Forms.TextBox txt_Tele;
        private System.Windows.Forms.Label lbl_Tele;
        private System.Windows.Forms.TextBox txt_Desig;
        private System.Windows.Forms.Label lbl_Desig;
        private System.Windows.Forms.TextBox txt_Cell;
        private System.Windows.Forms.Label lbl_Cell;
        private System.Windows.Forms.TextBox txt_Cont_Per;
        private System.Windows.Forms.Label lbl_Cont_Per;
        private System.Windows.Forms.TextBox txt_Comp_N;
        private System.Windows.Forms.Label lbl_Comp_N;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbl_Unit;
        private System.Windows.Forms.Label lbl_Make_O;
        private System.Windows.Forms.Label lbl_Size;
        private System.Windows.Forms.Label lbl_Desc;
        private System.Windows.Forms.Label lbl_Pro_Type;
        private System.Windows.Forms.Label lbl_PID;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox txtTotalPriceGST;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtGST;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_Quantity;
        private System.Windows.Forms.Label lbl_Unit_Price;
        private System.Windows.Forms.TextBox txtGSTAmount;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_Model;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DateTimePicker txt_validity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker txt_issued;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_c_id;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panlel_grid_3;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button txt_from_excel;
        public System.Windows.Forms.DataGridView Products_Table;
        public System.Windows.Forms.TextBox txt_total_price;
        public System.Windows.Forms.TextBox txtUnit;
        public System.Windows.Forms.TextBox txtPsize;
        public System.Windows.Forms.TextBox txtQuantity;
        public System.Windows.Forms.TextBox txtUnitPrice;
        public System.Windows.Forms.TextBox txt_p_id;
        public System.Windows.Forms.ComboBox txt_desc;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label lbl_discount_price;
        private System.Windows.Forms.Label lbl_discount;
        private System.Windows.Forms.TextBox txt_Discount;
        private System.Windows.Forms.TextBox txt_disc_price;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_disc;
        private System.Windows.Forms.TextBox txt_discount_price;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label label23;
        public System.Windows.Forms.DataGridView product_table_pdf;
        private System.Windows.Forms.TextBox txt_discnum;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox txt_previous;
        public System.Windows.Forms.Label user_logged;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox unit_txt;
    }
}