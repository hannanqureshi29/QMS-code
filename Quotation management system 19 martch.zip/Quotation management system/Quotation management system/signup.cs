﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.Security.Cryptography;

namespace Quotation_management_system
{
    public partial class signup : Form
    {
        private MySqlConnection con;
        public signup()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
           //con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void label2_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_signup_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(txtUserName.Text) || string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtConfirmPassword.Text))
            {
                MessageBox.Show("Please input Username and Password", "Error");
            }
            else if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Password Does Not Match", "Error");
            }
            else
            {
                try
                {
                    //string query = "SELECT * FROM userinfo WHERE u_name = '" + txtUserName.Text + "'";
                    MySqlParameter[] prm = new MySqlParameter[1];

                    prm[0] = new MySqlParameter("uname", MySqlDbType.VarChar);
                    prm[0].Value = txtUserName.Text;

                    MySqlCommand cmnd = new MySqlCommand();
                    cmnd.Connection = con;
                    cmnd.CommandType = CommandType.StoredProcedure;
                    cmnd.CommandText = "signup_click";
                    cmnd.Parameters.AddRange(prm);

                    // MySqlCommand cmd = new MySqlCommand(query, con);
                    con.Open();
                    
                    using (MySqlDataReader dr = cmnd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            MessageBox.Show("Username not available!");
                         
                            dr.Close();
                        }

                        else
                        {
                            dr.Close();
                            dr.Dispose();
                            try
                            {
                                // insert_in_signup  string iquery = "INSERT INTO userinfo (u_name, u_password, date_created,last_login) VALUES ('" + txtUserName.Text + "', '" + Encrypt(txtPassword.Text) + "', Now(), Now())";
                                //   MySqlCommand mySqlCommand = new MySqlCommand(iquery, con);
                                MySqlParameter[] pms = new MySqlParameter[2];
                                pms[0] = new MySqlParameter("uname", MySqlDbType.VarChar);
                                pms[0].Value = txtUserName.Text;
                                pms[1] = new MySqlParameter("upassword", MySqlDbType.VarChar);
                                pms[1].Value = Encrypt(txtPassword.Text);

                                MySqlCommand cmd = new MySqlCommand();
                                cmd.Connection = con;
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.CommandText = "insert_in_signup";
                                cmd.Parameters.AddRange(pms);


                                //con.Open();
                                cmd.ExecuteNonQuery();
                                cmd.Dispose();
                                

                               // MySqlCommand commandDatabase = mySqlCommand;

                               // MySqlDataReader myReader = commandDatabase.ExecuteReader();
                                MessageBox.Show("Account Successfully Created!");
                            }
                            catch (Exception ex)
                            {
                                con.Close();
                                MessageBox.Show(ex.Message);
                            }

                            
                        }

                       
                    }
                   
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                }

            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtConfirmPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
                txtConfirmPassword.PasswordChar = '*';
            }
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void signup_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        static string Encrypt(string value)
        {
            //Using MD5 to encrypt a string
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                //Hash data
                byte[] data = md5.ComputeHash(utf8.GetBytes(value));
                return Convert.ToBase64String(data);
            }
        }
    }
}
