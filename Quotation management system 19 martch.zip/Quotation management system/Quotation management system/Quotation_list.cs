﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Quotation_management_system
{
    public partial class Quotation_list : Form
    {
        AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
        List<string> listOnit = new List<string>();
        List<string> listNew = new List<string>();
        private MySqlConnection con;
        public Quotation_list()
        {
            InitializeComponent();
           con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
           //con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void lblproductlist_Click(object sender, EventArgs e)
        {

        }

        private void Quotation_list_Load(object sender, EventArgs e)
        {
            search_DESC();
           // view_quotation_list();
            Get_quotation();
            search_from_quotaion();
            label12.Text = Login.u_name;
        }
        private void view_quotation_list()
        {

            //DataTable dt = new DataTable();

            //MySqlCommand cmd = new MySqlCommand("CALL `quotation_list`()", con);




            //con.Open();
            //MySqlDataReader sdr = cmd.ExecuteReader();
            //dt.Load(sdr);

            //con.Close();


            //Quotation_list_table.DataSource = dt;
            //Quotation_list_table.Columns[0].HeaderText = "Quotation #";
            //Quotation_list_table.Columns[1].HeaderText = "Reference #";
            //Quotation_list_table.Columns[2].HeaderText = "Update Status";
            //Quotation_list_table.Columns[3].HeaderText = "Revision Status";
            //Quotation_list_table.Columns[4].HeaderText = "Subject";
            //Quotation_list_table.Columns[5].HeaderText = "Quotaion Issued At";
            //Quotation_list_table.Columns[6].HeaderText = "Order Recieved At";
            //Quotation_list_table.Columns[7].HeaderText = "Company";
            //Quotation_list_table.Columns[8].HeaderText = "Customer";
            //Quotation_list_table.Columns[9].HeaderText = "Grand Total";



            //Quotation_list_table.Columns[0].Width = 100;
            //Quotation_list_table.Columns[1].Width = 100;
            //Quotation_list_table.Columns[2].Width = 100;
            //Quotation_list_table.Columns[3].Width = 100;
            //Quotation_list_table.Columns[4].Width = 200;
            //Quotation_list_table.Columns[5].Width = 100;
            //Quotation_list_table.Columns[6].Width = 100;
            //Quotation_list_table.Columns[7].Width = 200;
            //Quotation_list_table.Columns[8].Width = 200;
            //Quotation_list_table.Columns[9].Width = 200;



        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_date.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void btnaddproduct_Click(object sender, EventArgs e)
        {
            var dash = new New_Quote();
            dash.Show();
        }

        private void txt_search_quote_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    DataTable dt = new DataTable();

            //    //MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id WHERE quotations.q_num = '" + txt_search_quot.Text + "' OR quotations.q_ref = '" + txt_search_quot.Text + "' OR customer.company_name = '" + txt_search_quot.Text + "' OR customer.contact_person = '" + txt_search_quot.Text + "' GROUP BY quotations.q_num", con);
            //    // MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id WHERE quotations.q_num = '" + txt_search_quote.Text + "' OR quotations.q_ref = '" + txt_search_quote.Text + "' OR customer.company_name = '" + txt_search_quote.Text + "' OR customer.contact_person = '" + txt_search_quote.Text + "' GROUP BY quotations.q_num", con);

            //    MySqlParameter[] prm = new MySqlParameter[4];

            //    prm[0] = new MySqlParameter("qnum", MySqlDbType.VarChar);
            //    prm[0].Value = txt_search_quot.Text;
            //    prm[1] = new MySqlParameter("qref", MySqlDbType.VarChar);
            //    prm[1].Value = txt_search_quot.Text;
            //    prm[2] = new MySqlParameter("companyname", MySqlDbType.VarChar);
            //    prm[2].Value = txt_search_quot.Text;
            //    prm[3] = new MySqlParameter("contactperson", MySqlDbType.VarChar);
            //    prm[3].Value = txt_search_quot.Text;

            //    MySqlCommand cmnd = new MySqlCommand();
            //    cmnd.Connection = con;
            //    cmnd.CommandType = CommandType.StoredProcedure;
            //    cmnd.CommandText = "search_quotation_bar";
            //    cmnd.Parameters.AddRange(prm);

            //    con.Open();
            //    MySqlDataReader sdr = cmnd.ExecuteReader();
            //    dt.Load(sdr);
            //    con.Close();


            //    Quotation_list_table.DataSource = dt;
            //    Quotation_list_table.Columns[0].HeaderText = "Quotation #";
            //    Quotation_list_table.Columns[1].HeaderText = "Reference #";
            //    Quotation_list_table.Columns[2].HeaderText = "Update Status";
            //    Quotation_list_table.Columns[3].HeaderText = "Revision Status";
            //    Quotation_list_table.Columns[4].HeaderText = "Subject";
            //    Quotation_list_table.Columns[5].HeaderText = "Issued At";
            //    Quotation_list_table.Columns[6].HeaderText = "Valid Till";
            //    Quotation_list_table.Columns[7].HeaderText = "Company";
            //    Quotation_list_table.Columns[8].HeaderText = "Customer";
            //    Quotation_list_table.Columns[9].HeaderText = "Grand Total";

            //    Quotation_list_table.Columns[0].Width = 100;
            //    Quotation_list_table.Columns[1].Width = 100;
            //    Quotation_list_table.Columns[2].Width = 100;
            //    Quotation_list_table.Columns[3].Width = 100;
            //    Quotation_list_table.Columns[4].Width = 200;
            //    Quotation_list_table.Columns[5].Width = 100;
            //    Quotation_list_table.Columns[6].Width = 100;
            //    Quotation_list_table.Columns[7].Width = 200;
            //    Quotation_list_table.Columns[8].Width = 200;
            //    Quotation_list_table.Columns[9].Width = 200;

            //}
        }

        private void txt_search_quote_Leave(object sender, EventArgs e)
        {
            //if (txt_search_quot.Text == "")
            //{
            //    txt_search_quot.Text = "Search Quotation";
            //    Get_quotation();
            //}
        }

        private void txt_search_quote_TextChanged(object sender, EventArgs e)
        {
        //    if (txt_search_quot.Text == "")
        //    {
        //        Get_quotation();
        //    }
        }
        private void Get_quotation()
        {
            DataTable dt = new DataTable();

            MySqlCommand cmd = new MySqlCommand("CALL `get_quotation`()", con);
          //  SELECT DISTINCT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();



            Quotation_list_table.DataSource = dt;
            Quotation_list_table.Columns[0].HeaderText = "Quotation #";
            Quotation_list_table.Columns[1].HeaderText = "Reference #";
            Quotation_list_table.Columns[2].HeaderText = "Upd Stat";
            Quotation_list_table.Columns[3].HeaderText = "Rev Stat";
            Quotation_list_table.Columns[4].HeaderText = "Subject";
            Quotation_list_table.Columns[5].HeaderText = "Issued At";
            Quotation_list_table.Columns[6].HeaderText = "Valid Till";
            Quotation_list_table.Columns[7].HeaderText = "Company";
            Quotation_list_table.Columns[8].HeaderText = "Customer";
            Quotation_list_table.Columns[9].HeaderText = "Size";
            Quotation_list_table.Columns[10].HeaderText = "Description";
            Quotation_list_table.Columns[11].HeaderText = "Unit Price";
            Quotation_list_table.Columns[12].HeaderText = "Grand Total";

            Quotation_list_table.Columns[0].Width = 50;
            Quotation_list_table.Columns[1].Width = 80;
            Quotation_list_table.Columns[2].Width = 30;
            Quotation_list_table.Columns[3].Width = 30;
            Quotation_list_table.Columns[4].Width = 100;
            Quotation_list_table.Columns[5].Width = 80;
            Quotation_list_table.Columns[6].Width = 80;
            Quotation_list_table.Columns[7].Width = 100;
            Quotation_list_table.Columns[8].Width = 100;
            Quotation_list_table.Columns[9].Width = 50;
            Quotation_list_table.Columns[10].Width = 200;
            Quotation_list_table.Columns[11].Width = 70;
            Quotation_list_table.Columns[12].Width = 150;

        }

        private void txt_search_quot_Enter(object sender, EventArgs e)
        {
            //if (txt_search_quot.Text == "Search Quotation")
            //{
            //    txt_search_quot.Text = "";
            //}
        }
        private void search_from_quotaion()
        {
           
           // MySqlCommand cmd = new MySqlCommand("CALL `search_from_quotations`() ", con);
           //// SELECT quotations.q_num,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
           // con.Open();
           // MySqlDataReader reader = cmd.ExecuteReader();
           // AutoCompleteStringCollection collection = new AutoCompleteStringCollection();

           // while (reader.Read())
           // {
           //     collection.Add(reader.GetString(0));
           //     collection.Add(reader.GetString(1));
           //     collection.Add(reader.GetString(2));
           // }
           // txt_search_quot.AutoCompleteCustomSource = collection;
           // con.Close();


        }

        private void combo_search_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DataTable dt = new DataTable();

                MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_size,quotations.p_descrption,quotations.p_unit_price,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id WHERE quotations.q_num = '" + combo_quot_list.Text + "' OR quotations.q_ref = '" + combo_quot_list.Text + "'OR quotations.p_descrption = '" + combo_quot_list.Text + "' OR customer.company_name = '" + combo_quot_list.Text + "' OR customer.contact_person = '" + combo_quot_list.Text + "' LIMIT 50", con);


                con.Open();
                MySqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                con.Close();


                Quotation_list_table.DataSource = dt;
                Quotation_list_table.Columns[0].HeaderText = "Quotation #";
                Quotation_list_table.Columns[1].HeaderText = "Reference #";
                Quotation_list_table.Columns[2].HeaderText = "Upd Stat";
                Quotation_list_table.Columns[3].HeaderText = "Rev Stat";
                Quotation_list_table.Columns[4].HeaderText = "Subject";
                Quotation_list_table.Columns[5].HeaderText = "Issued At";
                Quotation_list_table.Columns[6].HeaderText = "Valid Till";
                Quotation_list_table.Columns[7].HeaderText = "Company";
                Quotation_list_table.Columns[8].HeaderText = "Customer";
                Quotation_list_table.Columns[9].HeaderText = "Size";
                Quotation_list_table.Columns[10].HeaderText = "Description";
                Quotation_list_table.Columns[11].HeaderText = "Unit Price";
                Quotation_list_table.Columns[12].HeaderText = "Grand Total";

                Quotation_list_table.Columns[0].Width = 50;
                Quotation_list_table.Columns[1].Width = 80;
                Quotation_list_table.Columns[2].Width = 30;
                Quotation_list_table.Columns[3].Width = 30;
                Quotation_list_table.Columns[4].Width = 100;
                Quotation_list_table.Columns[5].Width = 80;
                Quotation_list_table.Columns[6].Width = 80;
                Quotation_list_table.Columns[7].Width = 100;
                Quotation_list_table.Columns[8].Width = 100;
                Quotation_list_table.Columns[9].Width = 50;
                Quotation_list_table.Columns[10].Width = 200;
                Quotation_list_table.Columns[11].Width = 70;
                Quotation_list_table.Columns[12].Width = 150;
            }
    }

        private void combo_search_Leave(object sender, EventArgs e)
        {
            if (combo_quot_list.Text == "")
            {
                combo_quot_list.Text = "";
                Get_quotation();
            }
        }

        private void combo_quot_list_TextUpdate(object sender, EventArgs e)
        {
            this.combo_quot_list.Items.Clear();
            listNew.Clear();
            foreach (var item in listOnit)
            {
                if (item.Contains(combo_quot_list.Text))
                {
                    listNew.Add(item);
                }
            }
            this.combo_quot_list.Items.AddRange(listNew.ToArray());
            this.combo_quot_list.SelectionStart = this.combo_quot_list.Text.Length;
            Cursor = Cursors.Default;
            this.combo_quot_list.DroppedDown = true;
        }
        private void search_DESC()
        {
            string query = " SELECT quotations.q_num,customer.company_name,customer.contact_person,quotations.p_descrption FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id";
            MySqlCommand cmd = new MySqlCommand(query, con);

            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                collection.Add(reader.GetString(0));
                collection.Add(reader.GetString(1));
                collection.Add(reader.GetString(2));
                collection.Add(reader.GetString(3));

                listOnit.Add(reader.GetString(0));
                listOnit.Add(reader.GetString(1));
                listOnit.Add(reader.GetString(2));
                listOnit.Add(reader.GetString(3));
            }
            reader.Close();
            combo_quot_list.AutoCompleteCustomSource = collection;
            combo_quot_list.Items.AddRange(listOnit.ToArray());
            con.Close();

        }
    }
}

