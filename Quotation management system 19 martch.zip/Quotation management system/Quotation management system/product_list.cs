﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Quotation_management_system
{
    public partial class product_list : Form
    {
        private MySqlConnection con;
        public product_list()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            //con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void Quotation_Table_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void product_list_Load(object sender, EventArgs e)
        {
            view_products_list();
            search_from_product();
            label12.Text = Login.u_name;
        }
        private void view_products_list()
        {
         
                DataTable dt = new DataTable();

                MySqlCommand cmd = new MySqlCommand("CALL `product_list`() ", con);




                con.Open();
                MySqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);

                con.Close();


                Product_List_Table.DataSource = dt;
              
                Product_List_Table.Columns[0].HeaderText = "Code";               
                Product_List_Table.Columns[1].HeaderText = "Size";             
                Product_List_Table.Columns[2].HeaderText = "Description";               
                Product_List_Table.Columns[3].HeaderText = "Unit";
                Product_List_Table.Columns[4].HeaderText = "Unit Price";
                

            
                Product_List_Table.Columns[0].Width = 50;           
                Product_List_Table.Columns[1].Width = 100;             
                Product_List_Table.Columns[2].Width = 250;              
                Product_List_Table.Columns[3].Width = 100;
                Product_List_Table.Columns[4].Width = 150;
               

            
        }

        private void btnaddproduct_Click(object sender, EventArgs e)
        {
            var dash = new AddProduct();
            dash.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_date.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
        private void search_from_product()
        {       
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM products ", con);
            //  SELECT quotations.q_num,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection collection = new AutoCompleteStringCollection();

            while (reader.Read())
            {
                collection.Add(reader.GetString(0));
                collection.Add(reader.GetString(1));
                collection.Add(reader.GetString(2));
            }
            txt_search_product.AutoCompleteCustomSource = collection;
            con.Close();
        }

        private void txt_search_product_Enter(object sender, EventArgs e)
        {
            if (txt_search_product.Text == "Search Product")
            {
                txt_search_product.Text = "";
            }
        }

        private void txt_search_product_KeyDown(object sender, KeyEventArgs e)
        {
        if (e.KeyCode == Keys.Enter)
        {
            DataTable dt = new DataTable();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM products WHERE p_code = '" + txt_search_product.Text + "' OR p_description =  '" + txt_search_product.Text + "' OR p_size ='" + txt_search_product.Text + "'", con);
            // MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id WHERE quotations.q_num = '" + txt_search_quote.Text + "' OR quotations.q_ref = '" + txt_search_quote.Text + "' OR customer.company_name = '" + txt_search_quote.Text + "' OR customer.contact_person = '" + txt_search_quote.Text + "' GROUP BY quotations.q_num", con);

            //MySqlParameter[] prm = new MySqlParameter[2];

            //prm[0] = new MySqlParameter("qnum", MySqlDbType.VarChar);
            //prm[0].Value = txt_search_quot.Text;
            //prm[1] = new MySqlParameter("qref", MySqlDbType.VarChar);
            //prm[1].Value = txt_search_quot.Text;
            //prm[2] = new MySqlParameter("companyname", MySqlDbType.VarChar);
            //prm[2].Value = txt_search_quot.Text;
            //prm[3] = new MySqlParameter("contactperson", MySqlDbType.VarChar);
            //prm[3].Value = txt_search_quot.Text;

            //MySqlCommand cmnd = new MySqlCommand();
            //cmnd.Connection = con;
            //cmnd.CommandType = CommandType.StoredProcedure;
            //cmnd.CommandText = "search_quotation_bar";
            //cmnd.Parameters.AddRange(prm);

            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();


            Product_List_Table.DataSource = dt;
              
                Product_List_Table.Columns[0].HeaderText = "P-code";              
                Product_List_Table.Columns[1].HeaderText = "P-size";
                Product_List_Table.Columns[2].HeaderText = "P-description";              
                Product_List_Table.Columns[3].HeaderText = "P-unit";
                Product_List_Table.Columns[4].HeaderText = "P-unit_price";


                
                Product_List_Table.Columns[0].Width = 50;
                Product_List_Table.Columns[1].Width = 100;               
                Product_List_Table.Columns[2].Width = 250;             
                Product_List_Table.Columns[3].Width = 100;
                Product_List_Table.Columns[4].Width = 150;


            }
        }

        private void txt_search_product_Leave(object sender, EventArgs e)
        {
        if (txt_search_product.Text == "")
        {
            txt_search_product.Text = "Search products";
            view_products_list();
        }
        }

        private void txt_search_product_TextChanged(object sender, EventArgs e)
        {
        if (txt_search_product.Text == "")
        {
            view_products_list();
        }     
        }
    }
}
