﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;

namespace Quotation_management_system
{
    public partial class Order_vs_Quotation : Form
    {
        private MySqlConnection con;
        SaveFileDialog savefiledialog1 = new SaveFileDialog();
        public string filename;
        public Order_vs_Quotation()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");

            // con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_date.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void Order_vs_Quotation_Load(object sender, EventArgs e)
        {
            style();
            label5.Text = Login.u_name;
            savefiledialog1.FileName = "";
            savefiledialog1.Filter = "PDF (*.pdf)|*.pdf";
            get_OrdervsQuot();
            graph_load();
            
        }
        public void style()
        {
            order_vs_quotation_table.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(64, 64, 64); ;
            order_vs_quotation_table.EnableHeadersVisualStyles = false;
        }
        public void get_OrdervsQuot()
        {
            DataTable dt = new DataTable();

            MySqlCommand cmd = new MySqlCommand("CALL `order_vs_quotation`()", con);
            // SELECT DISTINCT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id"
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();


            order_vs_quotation_table.DataSource = dt;
            order_vs_quotation_table.Columns[0].HeaderText = "Customer";
            order_vs_quotation_table.Columns[1].HeaderText = "No of Quotation";
            order_vs_quotation_table.Columns[2].HeaderText = "No of Order";


            order_vs_quotation_table.Columns[0].Width = 528;
            order_vs_quotation_table.Columns[1].Width = 528;
            order_vs_quotation_table.Columns[2].Width = 528;

        }
        public void graph_load()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                Title title = chart1.Titles.Add("Chart Title");
                //For 1st Value
                chart1.Series.Add("Quotations");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
                chart1.Series[0].Color = Color.DarkOrange;
                //chart1.Series[0].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
                //chart1.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd HH:mm:ss";
                //chart1.ChartAreas[0].AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Hours;
                // chart1.ChartAreas[0].AxisY.Maximum = 100;
                //chart1.ChartAreas[0].AxisY.Interval = 5;
                //chart1.ChartAreas[0].AxisY.Minimum = 0;
                chart1.Series[0].BorderWidth = 2;
                //For 2nd Value
                chart1.Series.Add("Orders");
                chart1.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
                chart1.Series[1].Color = Color.Blue;
                chart1.Series[1].BorderWidth = 2;
                //Query for Fetching Data
                MySqlCommand cmd = new MySqlCommand("SELECT COUNT(DISTINCT quotations.q_num) AS q_number, COUNT(DISTINCT orders.q_num) AS O_Number, customer.company_name FROM quotations LEFT JOIN customer ON quotations.c_id = customer.c_id LEFT JOIN orders ON quotations.c_id = orders.c_id GROUP BY quotations.c_id ORDER BY COUNT(DISTINCT quotations.c_ID) DESC; ", con);
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    chart1.Series[0].Points.AddXY(dr.GetString("company_name"), dr.GetDouble("q_number"));

                    chart1.Series[1].Points.AddXY(dr.GetString("company_name"), dr.GetDouble("O_Number"));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            //chart1.ChartAreas[0].AxisX.ScaleView.Zoomable = true;
            //chart1.ChartAreas[0].AxisY.ScaleView.Zoomable = true;
            //chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            //MySqlDataAdapter sda = new MySqlDataAdapter("SELECT COUNT(DISTINCT quotations.q_num),COUNT(DISTINCT orders.q_num),customer.company_name FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id INNER JOIN orders ON quotations.c_id = orders.c_id WHERE (orders.q_issued_at BETWEEN '" + dateTimePicker1.Text + "' AND '" + dateTimePicker2.Text + "') ", con);
            MySqlDataAdapter sda = new MySqlDataAdapter("SELECT customer.company_name,COUNT(DISTINCT quotations.q_num),COUNT(DISTINCT orders.q_num) FROM quotations INNER JOIN orders ON quotations.c_id = orders.c_id INNER JOIN customer ON quotations.c_id = customer.c_id WHERE (quotations.q_issued_at BETWEEN '" + dateTimePicker1.Text + "' AND '" + dateTimePicker2.Text + "') GROUP BY quotations.c_id ORDER BY COUNT(DISTINCT quotations.c_ID) DESC ", con);
            //DataSet ds = new DataSet();
            DataTable ds = new DataTable();
            // sda.Fill(ds, "quotations");
            sda.Fill(ds);
            order_vs_quotation_table.DataSource = ds;
            order_vs_quotation_table.Columns[0].HeaderText = "Customer";
            order_vs_quotation_table.Columns[1].HeaderText = "No of Quotation";
            order_vs_quotation_table.Columns[2].HeaderText = "No of Order";


            order_vs_quotation_table.Columns[0].Width = 528;
            order_vs_quotation_table.Columns[1].Width = 528;
            order_vs_quotation_table.Columns[2].Width = 528;

            con.Close();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Byte[] bytes;
            if (savefiledialog1.ShowDialog() == DialogResult.OK)
            {
                using (var ms = new MemoryStream())
                {
                    // Declaring File Name via Textbox
                    filename = savefiledialog1.FileName;
                    // Code Start for Font Styles
                    iTextSharp.text.Font ptitle = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 20, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pstitle = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 16, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pdata = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    iTextSharp.text.Font p_s_data = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    iTextSharp.text.Font pbold = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pb = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pb_u = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.UNDERLINE, BaseColor.BLACK);
                    iTextSharp.text.Font pfoot = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLDITALIC, BaseColor.BLACK);
                    iTextSharp.text.Font punder = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.UNDERLINE, BaseColor.BLACK);
                    iTextSharp.text.Font pdata1 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    // Code Ends for Font Styling

                    //Code Starts for Method of Saving File As PDF
                    Paragraph paragraph = new Paragraph();
                    Document pdffile = new Document(PageSize.A4, 8f, 8f, 80f, 150f);
                    //new FileStream(textBox1.Text, FileMode.Create)
                    PdfWriter write = PdfWriter.GetInstance(pdffile, ms);
                    pdffile.Open();
                    //For Adding Logo on Top
                    //System.Drawing.Bitmap kitz = Quotation_management_system.Properties.Resources.kitz;
                    //iTextSharp.text.Image image1 = iTextSharp.text.Image.GetInstance(kitz, System.Drawing.Imaging.ImageFormat.Png);
                    //System.Drawing.Bitmap star_corp = Quotation_management_system.Properties.Resources.star_corp;
                    //iTextSharp.text.Image image2 = iTextSharp.text.Image.GetInstance(star_corp, System.Drawing.Imaging.ImageFormat.Png);
                    //image2.ScaleToFit(140.0F, 100.0F);
                    //image2.SetAbsolutePosition(pdffile.Left, pdffile.Top - 40);
                    //pdffile.Add(image2);
                    //image1.ScaleToFit(150.0F, 150.0F);
                    //image1.SetAbsolutePosition(pdffile.Right - 150, pdffile.Top - 46);
                    //pdffile.Add(image1);
                    ////Adding Header Text
                    //pdffile.Add(new Paragraph("    "));
                    //pdffile.Add(new Paragraph("    "));
                    //pdffile.Add(new Paragraph("102-McLeod Rd,Australia Chowk,Lahore", pdata1));
                    //pdffile.Add(new Paragraph("Tel: +92-42-37659317,7667735    ", pdata1));
                    //pdffile.Add(new Paragraph("Fax: +92-42-37631666", pdata1));
                    //pdffile.Add(new Paragraph("Email: starlhr@starcorporation.org", pdata1));
                    //pdffile.Add(new Paragraph("----------------------------------------------------------------------------------------------------------------------------------------------"));
                    //// pdffile.Add(new Paragraph("                                                                                                                                             Issue Date: " + txt_issued.Text, pdata));
                    // pdffile.Add(new Paragraph("                                                                                                                                             REF No: " + txt_Quot_Num.Text + "- REV:" + txt_Rev_Sta.Text, pdata));
                    //pdffile.Add(new Paragraph(txt_Comp_N.Text, pbold));
                    //pdffile.Add(new Paragraph(txt_address.Text, pb));
                    //pdffile.Add(new Paragraph("PH #: " + txt_Tele.Text, pb));
                    //pdffile.Add(new Paragraph("Cell #: " + txt_Cell.Text, pb));
                    //pdffile.Add(new Paragraph("Email: " + txt_Email.Text, pb_u));
                    //pdffile.Add(new Paragraph("Attn: " + txt_Cont_Per.Text, pbold));
                    // pdffile.Add(new Paragraph("                                                                Subject: " + txt_Subject.Text, pbold));
                    //pdffile.Add(new Paragraph("Dear Sir, ", pdata));
                    //pdffile.Add(new Paragraph("Thank you very much for your good response & Cooperation to sent us your valuable enquiry Ref #." + txt_Ref.Text, pdata));
                    //pdffile.Add(new Paragraph("We are sending you quotation for the same, ", pdata));
                    pdffile.Add(new Paragraph("  "));
                    //Code Ends for Header and Upper Textboxes

                    //Code For Data Grid View Data (pdf export)
                    pdffile.Add(paragraph);
                    PdfPTable pdftable = new PdfPTable(order_vs_quotation_table.Columns.Count);
                    //pdftable.WidthPercentage = 97f;
                    pdftable.TotalWidth = 580f;
                    pdftable.LockedWidth = true;
                    int[] intTblWidth = new[] {194,193,193};


                    pdftable.SetWidths(intTblWidth);

                    for (int i = 0; i <= order_vs_quotation_table.Columns.Count - 1; i++)
                    {
                        //pdftable.SetWidths(intTblWidth);
                        pdftable.HorizontalAlignment = 0;
                        pdftable.SpacingBefore = 5.0F;
                    }
                    PdfPCell pdfcell = new PdfPCell();

                    for (int i = 0; i <= order_vs_quotation_table.Columns.Count - 1; i++)
                    {
                        pdfcell = new PdfPCell(new Phrase(new Chunk(order_vs_quotation_table.Columns[i].HeaderText, pb)));
                        pdfcell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                        pdfcell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
                        pdfcell.FixedHeight = (20f);
                        pdfcell.BackgroundColor = new iTextSharp.text.BaseColor(Color.Gray);
                        pdftable.AddCell(pdfcell);
                    }

                    // pdfcell.BackgroundColor = new iTextSharp.text.BaseColor(128, 128, 128);

                    for (int i = 0; i <= order_vs_quotation_table.Rows.Count - 2; i++)
                    {
                        for (int j = 0; j <= order_vs_quotation_table.Columns.Count - 1; j++)
                        {
                            pdfcell = new PdfPCell(new Phrase(order_vs_quotation_table[j, i].Value.ToString(), pdata));
                            pdftable.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.FixedHeight = (15f);
                            pdftable.AddCell(pdfcell);
                        }
                    }
                    //string dateTime = String.Format("{0:MM/dd/yyyy}", q.Rows[i]["PAYDATE"]);

                    //PdfPCell cellT1 = new PdfPCell(new Phrase(dateTime, f));
                    //cellT1.HorizontalAlignment = Element.ALIGN_CENTER;
                    //cellT1.VerticalAlignment = Element.ALIGN_CENTER;
                    //table.AddCell(cellT1);
                    pdffile.Add(pdftable);
                    //pdffile.Add(new Paragraph("    "));
                   // pdffile.Add(new Paragraph("Total Quotation=  " + lbl_quotation_count.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Discount %:  " + txt_disc.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Discount Price:  " + txt_discount_price.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Sales Tax @ 17%:  " + txtGSTAmount.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Price Incl. GST:  " + txtTotalPriceGST.Text, pb));

                    //pdffile.Add(new Paragraph("Terms and Conditions:", punder));
                    //pdffile.Add(new Paragraph(txt_T_Condition.Text, pdata));
                    //pdffile.Add(new Paragraph("Lead Time: " + txt_Lead_Time.Text, pdata));
                    //pdffile.Add(new Paragraph("Payment Terms: " + txt_Pay_Term.Text, pdata));
                    //pdffile.Add(new Paragraph("Valid Till: " + txt_validity.Text, pdata));
                    //pdffile.Add(new Paragraph("Price: Ex-Godown Lahore", pdata));
                    pdffile.Add(new Paragraph("    "));
                    //  pdffile.Add(new Paragraph("We hope above offer is acceptable to you and look forward to your esteem order.", p_s_data));

                    //pdffile.Add(new Paragraph("Prepared By:  " + user_logged.Text + "                                                                                                       Approved By: ________________ ", pb));     
                    //  pdffile.Add(new Paragraph());
                    pdffile.Close();
                    bytes = ms.ToArray();
                }

                //Read our PDF and apply page numbers
                using (var reader = new PdfReader(bytes))
                {
                    using (var ms = new MemoryStream())
                    {
                        using (var stamper = new PdfStamper(reader, ms))
                        {
                            int PageCount = reader.NumberOfPages;
                            iTextSharp.text.Font pdata = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 9, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                            iTextSharp.text.Font pdata1 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                            iTextSharp.text.Font pb = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                            // For Adding Logo on Top
                            System.Drawing.Bitmap kitz = Quotation_management_system.Properties.Resources.kitz;
                            iTextSharp.text.Image image1 = iTextSharp.text.Image.GetInstance(kitz, System.Drawing.Imaging.ImageFormat.Png);

                            System.Drawing.Bitmap star_corp = Quotation_management_system.Properties.Resources.star_corp;
                            iTextSharp.text.Image image2 = iTextSharp.text.Image.GetInstance(star_corp, System.Drawing.Imaging.ImageFormat.Png);

                            for (int i = 1; i <= PageCount; i++)
                            {
                                PdfContentByte content = stamper.GetUnderContent(i);
                                image2.ScaleToFit(180.0F, 150.0F);
                                image2.SetAbsolutePosition(10, 780);

                                content.AddImage(image2);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("   Importor & Stockist: Valves,Pipes & Fittings.", i, PageCount), pb), 5, 771, 0);



                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("                                                                                                                                                        Authorized Agent & Distributor:", i, PageCount), pb), 5, 825, 0);
                                PdfContentByte content1 = stamper.GetUnderContent(i);
                                image1.ScaleToFit(155.0F, 150.0F);
                                image1.SetAbsolutePosition(426, 770);

                                content1.AddImage(image1);

                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Lahore Office:                                                                                                                                Faisalabad Office:", i, PageCount), pdata), 5, 55, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("102-McLeod Rd,Australia Chowk,                                                                                                 Shop # 135,Ground Floor Railway Road,", i, PageCount), pdata), 5, 45, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Lahore-Pakistan. Tel: +92-42-37659317,37667735,                                                                     Faisalabad-Pakistan.Tel: +92-41-2629532-2642259", i, PageCount), pdata), 5, 35, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Fax: +92-42-37631666                                                                                                                  Fax: 92-41-2629531", i, PageCount), pdata), 5, 25, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Email: starlhr@starcorporation.org                     http://www.starcorporation.org                           Email: starcorp@starcorporation.org", i, PageCount), pdata), 5, 15, 0);



                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_CENTER, new Phrase(String.Format("                                                                                                                                                                                                                                                                                                                                                                                                                                    Page {0} of {1}", i, PageCount), pdata1), 100, 3, 0);
                                //ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_CENTER, new Phrase(String.Format("                                                                                                                       Page {0} of {1}", i, PageCount)), 100, 10, 0);
                                // ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Prepared By: " + user_logged.Text + "                                                  Approved By: ________________ ", i, PageCount)), 100, 10, 0);
                            }
                        }
                        bytes = ms.ToArray();
                    }
                }
                var outputFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), filename);
                System.IO.File.WriteAllBytes(outputFile, bytes);
                MessageBox.Show("Data Exported to PDF Successfuly");
            }
        }
    }
   
}
