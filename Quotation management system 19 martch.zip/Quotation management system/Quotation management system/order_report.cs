﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;

namespace Quotation_management_system
{
    public partial class order_report : Form
    {
        private MySqlConnection con;
        SaveFileDialog savefiledialog1 = new SaveFileDialog();
        public string filename;
        AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
        List<string> listOnit = new List<string>();
        List<string> listNew = new List<string>();
        public order_report()
        {
            InitializeComponent();
           con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            
            //con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void order_report_Load(object sender, EventArgs e)
        {
            style();
            label5.Text = Login.u_name;
            // graph_load();
            order_count();
            savefiledialog1.FileName = "";
            savefiledialog1.Filter = "PDF (*.pdf)|*.pdf";
            search_DESC();
            auto_quotation();
            get_quotation();
            //combo_search.AutoCompleteMode = AutoCompleteMode.Suggest;
            //combo_search.AutoCompleteSource = AutoCompleteSource.ListItems;
        }
        public void style()
        {
            Quotation_Table.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(64, 64, 64); ;
            Quotation_Table.EnableHeadersVisualStyles = false;
            // No_of_Quotation_table.ColumnHeadersHeight = 80;

        }
        public void auto_quotation()
        {
            combo_search.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            // combo_search.AutoCompleteSource = AutoCompleteSource.None;
        }
        public void get_quotation()
        {
            DataTable dt = new DataTable();

            MySqlCommand cmd = new MySqlCommand("CALL `get_order_report`()", con);
            // SELECT DISTINCT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id"
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();


            Quotation_Table.DataSource = dt;
            Quotation_Table.Columns[0].HeaderText = "Quot No";
            Quotation_Table.Columns[1].HeaderText = "Ref #";
            Quotation_Table.Columns[2].HeaderText = "P-O No";
            Quotation_Table.Columns[3].HeaderText = "Company";
            Quotation_Table.Columns[4].HeaderText = "Description";
            Quotation_Table.Columns[5].HeaderText = "Size";
            Quotation_Table.Columns[6].HeaderText = "QTY";
            Quotation_Table.Columns[7].HeaderText = "Unit";
            Quotation_Table.Columns[8].HeaderText = "UnitPrice";
            Quotation_Table.Columns[9].HeaderText = "Total";
            Quotation_Table.Columns[10].HeaderText = "Grand Total";

            Quotation_Table.Columns[0].Width = 30;
            Quotation_Table.Columns[1].Width = 50;
            Quotation_Table.Columns[2].Width = 50;
            Quotation_Table.Columns[3].Width = 50;
            Quotation_Table.Columns[4].Width = 200;
            Quotation_Table.Columns[5].Width = 50;
            Quotation_Table.Columns[6].Width = 50;
            Quotation_Table.Columns[7].Width = 50;
            Quotation_Table.Columns[8].Width = 50;
            Quotation_Table.Columns[9].Width = 100;
            Quotation_Table.Columns[10].Width = 200;


        }

        private void combo_search_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DataTable dt = new DataTable();

                MySqlCommand cmd = new MySqlCommand("SELECT orders.q_num,orders.q_ref,orders.product_order_no,customer.company_name,orders.p_descrption,orders.p_size,orders.p_quantity,orders.p_unit,orders.p_unit_price,orders.p_total,orders.p_total_price_inc_gst FROM orders INNER JOIN customer ON orders.c_id = customer.c_id WHERE orders.q_num = '" + combo_search.Text + "' OR orders.q_ref = '" + combo_search.Text + "' OR product_order_no = '" + combo_search.Text + "' OR customer.company_name = '" + combo_search.Text + "' OR orders.p_descrption = '"+ combo_search.Text + "' ", con);


                con.Open();
                MySqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                con.Close();

                Quotation_Table.DataSource = dt;
                Quotation_Table.Columns[0].HeaderText = "Quot No";
                Quotation_Table.Columns[1].HeaderText = "Ref #";
                Quotation_Table.Columns[2].HeaderText = "P-O No";
                Quotation_Table.Columns[3].HeaderText = "Company";
                Quotation_Table.Columns[4].HeaderText = "Description";
                Quotation_Table.Columns[5].HeaderText = "Size";
                Quotation_Table.Columns[6].HeaderText = "QTY";
                Quotation_Table.Columns[7].HeaderText = "Unit";
                Quotation_Table.Columns[8].HeaderText = "UnitPrice";
                Quotation_Table.Columns[9].HeaderText = "Total";
                Quotation_Table.Columns[10].HeaderText = "Grand Total";

                Quotation_Table.Columns[0].Width = 30;
                Quotation_Table.Columns[1].Width = 50;
                Quotation_Table.Columns[2].Width = 50;
                Quotation_Table.Columns[3].Width = 50;
                Quotation_Table.Columns[4].Width = 200;
                Quotation_Table.Columns[5].Width = 50;
                Quotation_Table.Columns[6].Width = 50;
                Quotation_Table.Columns[7].Width = 50;
                Quotation_Table.Columns[8].Width = 50;
                Quotation_Table.Columns[9].Width = 100;
                Quotation_Table.Columns[10].Width = 200;
            }


        }
        private void search_DESC()
        {
            string query = " SELECT DISTINCT orders.q_num,orders.q_ref,orders.product_order_no,customer.company_name,orders.p_descrption FROM orders INNER JOIN customer ON orders.c_id = customer.c_id GROUP BY orders.q_num,customer.company_name";
            MySqlCommand cmd = new MySqlCommand(query, con);

            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                collection.Add(reader.GetString(0));
                listOnit.Add(reader.GetString(0));

                collection.Add(reader.GetString(1));
                listOnit.Add(reader.GetString(1));

                collection.Add(reader.GetString(2));
                listOnit.Add(reader.GetString(2));

                collection.Add(reader.GetString(3));
                listOnit.Add(reader.GetString(3));

                collection.Add(reader.GetString(4));
                listOnit.Add(reader.GetString(4));


            }
            reader.Close();
            combo_search.AutoCompleteCustomSource = collection;
            combo_search.Items.AddRange(listOnit.ToArray());
            con.Close();

        }

        private void combo_search_TextUpdate(object sender, EventArgs e)
        {
            //this.combo_search.Items.Clear();
            //listNew.Clear();
            //foreach (var item in listOnit)
            //{
            //    if (item.Contains(combo_search.Text))
            //    {
            //        listNew.Add(item);
            //    }
            //}
            //this.combo_search.Items.AddRange(listNew.ToArray());
            //this.combo_search.SelectionStart = this.combo_search.Text.Length;
            //Cursor = Cursors.Default;
            //this.combo_search.DroppedDown = true;
        }

        private void combo_search_Leave(object sender, EventArgs e)
        {

            if (combo_search.Text == "")
            {
                combo_search.Text = "Search Order Reports";
                get_quotation();
            }
        }

        private void combo_search_Enter(object sender, EventArgs e)
        {
            this.combo_search.DroppedDown = true;
            search_DESC();
        }
        private void order_count()
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("CALL ` order_count`() ", con);
                //  Select COUNT(DISTINCT q_num) FROM orders
                cmd.CommandType = CommandType.Text;
                con.Open();
                lbl_order_count.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_printReports_Click(object sender, EventArgs e)
        {
            Byte[] bytes;
            if (savefiledialog1.ShowDialog() == DialogResult.OK)
            {
                using (var ms = new MemoryStream())
                {
                    // Declaring File Name via Textbox
                    filename = savefiledialog1.FileName;
                    // Code Start for Font Styles
                    iTextSharp.text.Font ptitle = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 20, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pstitle = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 16, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pdata = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    iTextSharp.text.Font p_s_data = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    iTextSharp.text.Font pbold = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pb = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pb_u = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.UNDERLINE, BaseColor.BLACK);
                    iTextSharp.text.Font pfoot = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLDITALIC, BaseColor.BLACK);
                    iTextSharp.text.Font punder = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.UNDERLINE, BaseColor.BLACK);
                    iTextSharp.text.Font pdata1 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    // Code Ends for Font Styling

                    //Code Starts for Method of Saving File As PDF
                    Paragraph paragraph = new Paragraph();
                    Document pdffile = new Document(PageSize.A4, 8f, 8f, 80f, 150f);
                    //new FileStream(textBox1.Text, FileMode.Create)
                    PdfWriter write = PdfWriter.GetInstance(pdffile, ms);
                    pdffile.Open();
                    //For Adding Logo on Top
                    //System.Drawing.Bitmap kitz = Quotation_management_system.Properties.Resources.kitz;
                    //iTextSharp.text.Image image1 = iTextSharp.text.Image.GetInstance(kitz, System.Drawing.Imaging.ImageFormat.Png);
                    //System.Drawing.Bitmap star_corp = Quotation_management_system.Properties.Resources.star_corp;
                    //iTextSharp.text.Image image2 = iTextSharp.text.Image.GetInstance(star_corp, System.Drawing.Imaging.ImageFormat.Png);
                    //image2.ScaleToFit(140.0F, 100.0F);
                    //image2.SetAbsolutePosition(pdffile.Left, pdffile.Top - 40);
                    //pdffile.Add(image2);
                    //image1.ScaleToFit(150.0F, 150.0F);
                    //image1.SetAbsolutePosition(pdffile.Right - 150, pdffile.Top - 46);
                    //pdffile.Add(image1);
                    ////Adding Header Text
                    //pdffile.Add(new Paragraph("    "));
                    //pdffile.Add(new Paragraph("    "));
                    //pdffile.Add(new Paragraph("102-McLeod Rd,Australia Chowk,Lahore", pdata1));
                    //pdffile.Add(new Paragraph("Tel: +92-42-37659317,7667735    ", pdata1));
                    //pdffile.Add(new Paragraph("Fax: +92-42-37631666", pdata1));
                    //pdffile.Add(new Paragraph("Email: starlhr@starcorporation.org", pdata1));
                    //pdffile.Add(new Paragraph("----------------------------------------------------------------------------------------------------------------------------------------------"));
                    // pdffile.Add(new Paragraph("                                                                                                                                             Issue Date: " + txt_issued.Text, pdata));
                    // pdffile.Add(new Paragraph("                                                                                                                                             REF No: " + txt_Quot_Num.Text + "- REV:" + txt_Rev_Sta.Text, pdata));
                    //pdffile.Add(new Paragraph(txt_Comp_N.Text, pbold));
                    //pdffile.Add(new Paragraph(txt_address.Text, pb));
                    //pdffile.Add(new Paragraph("PH #: " + txt_Tele.Text, pb));
                    //pdffile.Add(new Paragraph("Cell #: " + txt_Cell.Text, pb));
                    //pdffile.Add(new Paragraph("Email: " + txt_Email.Text, pb_u));
                    //pdffile.Add(new Paragraph("Attn: " + txt_Cont_Per.Text, pbold));
                    // pdffile.Add(new Paragraph("                                                                Subject: " + txt_Subject.Text, pbold));
                    //pdffile.Add(new Paragraph("Dear Sir, ", pdata));
                    //pdffile.Add(new Paragraph("Thank you very much for your good response & Cooperation to sent us your valuable enquiry Ref #." + txt_Ref.Text, pdata));
                    //pdffile.Add(new Paragraph("We are sending you quotation for the same, ", pdata));
                    pdffile.Add(new Paragraph("  "));
                    //Code Ends for Header and Upper Textboxes

                    //Code For Data Grid View Data (pdf export)
                    pdffile.Add(paragraph);
                    PdfPTable pdftable = new PdfPTable(Quotation_Table.Columns.Count);
                    //pdftable.WidthPercentage = 97f;
                    pdftable.TotalWidth = 580f;
                    pdftable.LockedWidth = true;
                    int[] intTblWidth = new[] { 30, 25, 40, 60, 160, 30, 30, 35, 50, 60, 65 };

                    pdftable.SetWidths(intTblWidth);

                    for (int i = 0; i <= Quotation_Table.Columns.Count - 1; i++)
                    {
                        //pdftable.SetWidths(intTblWidth);
                        pdftable.HorizontalAlignment = 0;
                        pdftable.SpacingBefore = 5.0F;
                    }
                    PdfPCell pdfcell = new PdfPCell();

                    for (int i = 0; i <= Quotation_Table.Columns.Count - 1; i++)
                    {
                        pdfcell = new PdfPCell(new Phrase(new Chunk(Quotation_Table.Columns[i].HeaderText, pb)));
                        pdfcell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                        pdfcell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
                        pdfcell.FixedHeight = (30f);
                        pdfcell.BackgroundColor = new iTextSharp.text.BaseColor(Color.Gray);
                        pdftable.AddCell(pdfcell);
                    }
                    // pdfcell.BackgroundColor = new iTextSharp.text.BaseColor(128, 128, 128);

                    for (int i = 0; i <= Quotation_Table.Rows.Count - 2; i++)
                    {
                        for (int j = 0; j <= Quotation_Table.Columns.Count - 1; j++)
                        {
                            pdfcell = new PdfPCell(new Phrase(Quotation_Table[j, i].Value.ToString(), pdata));
                            pdftable.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.FixedHeight = (30f);
                            pdftable.AddCell(pdfcell);
                        }
                    }
                    pdffile.Add(pdftable);
                    //pdffile.Add(new Paragraph("    "));
                    pdffile.Add(new Paragraph("Total Quotation=  " + lbl_order_count.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Discount %:  " + txt_disc.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Discount Price:  " + txt_discount_price.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Sales Tax @ 17%:  " + txtGSTAmount.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Price Incl. GST:  " + txtTotalPriceGST.Text, pb));

                    //pdffile.Add(new Paragraph("Terms and Conditions:", punder));
                    //pdffile.Add(new Paragraph(txt_T_Condition.Text, pdata));
                    //pdffile.Add(new Paragraph("Lead Time: " + txt_Lead_Time.Text, pdata));
                    //pdffile.Add(new Paragraph("Payment Terms: " + txt_Pay_Term.Text, pdata));
                    //pdffile.Add(new Paragraph("Valid Till: " + txt_validity.Text, pdata));
                    //pdffile.Add(new Paragraph("Price: Ex-Godown Lahore", pdata));
                    pdffile.Add(new Paragraph("    "));
                    //  pdffile.Add(new Paragraph("We hope above offer is acceptable to you and look forward to your esteem order.", p_s_data));

                    //pdffile.Add(new Paragraph("Prepared By:  " + user_logged.Text + "                                                                                                       Approved By: ________________ ", pb));     
                    //  pdffile.Add(new Paragraph());
                    pdffile.Close();
                    bytes = ms.ToArray();
                }

                //Read our PDF and apply page numbers
                using (var reader = new PdfReader(bytes))
                {
                    using (var ms = new MemoryStream())
                    {
                        using (var stamper = new PdfStamper(reader, ms))
                        {
                            int PageCount = reader.NumberOfPages;
                            iTextSharp.text.Font pdata = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 9, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                            iTextSharp.text.Font pdata1 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                            iTextSharp.text.Font pb = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                            // For Adding Logo on Top
                            System.Drawing.Bitmap kitz = Quotation_management_system.Properties.Resources.kitz;
                            iTextSharp.text.Image image1 = iTextSharp.text.Image.GetInstance(kitz, System.Drawing.Imaging.ImageFormat.Png);

                            System.Drawing.Bitmap star_corp = Quotation_management_system.Properties.Resources.star_corp;
                            iTextSharp.text.Image image2 = iTextSharp.text.Image.GetInstance(star_corp, System.Drawing.Imaging.ImageFormat.Png);
                            for (int i = 1; i <= PageCount; i++)
                            {
                                // ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_CENTER, new Phrase(String.Format("                                                                                                                       Page {0} of {1}", i, PageCount)), 100, 10, 0);
                                // ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Prepared By: " + user_logged.Text + "                                                  Approved By: ________________ ", i, PageCount)), 100, 10, 0);

                                PdfContentByte content = stamper.GetUnderContent(i);
                                image2.ScaleToFit(180.0F, 150.0F);
                                image2.SetAbsolutePosition(10, 780);

                                content.AddImage(image2);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("   Importor & Stockist: Valves,Pipes & Fittings.", i, PageCount), pb), 5, 771, 0);



                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("                                                                                                                                                        Authorized Agent & Distributor:", i, PageCount), pb), 5, 825, 0);
                                PdfContentByte content1 = stamper.GetUnderContent(i);
                                image1.ScaleToFit(155.0F, 150.0F);
                                image1.SetAbsolutePosition(426, 770);

                                content1.AddImage(image1);

                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Lahore Office:                                                                                                                                Faisalabad Office:", i, PageCount), pdata), 5, 55, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("102-McLeod Rd,Australia Chowk,                                                                                                 Shop # 135,Ground Floor Railway Road,", i, PageCount), pdata), 5, 45, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Lahore-Pakistan. Tel: +92-42-37659317, 37667735,                                                                     Faisalabad-Pakistan.Tel: +92-41-2629532, 2642259", i, PageCount), pdata), 5, 35, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Fax: +92-42-37631666                                                                                                                  Fax: +92-41-2629531", i, PageCount), pdata), 5, 25, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Email: starlhr@starcorporation.org                     http://www.starcorporation.org                           Email: starcorp@starcorporation.org", i, PageCount), pdata), 5, 15, 0);



                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_CENTER, new Phrase(String.Format("                                                                                                                                                                                                                                                                                                                                                                                                                                    Page {0} of {1}", i, PageCount), pdata1), 100, 3, 0);
                            }
                        }
                        bytes = ms.ToArray();
                    }
                }
                var outputFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), filename);
                System.IO.File.WriteAllBytes(outputFile, bytes);
                MessageBox.Show("Data Exported to PDF Successfuly");
            }
        }
        public void graph_load()
        {
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_date.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void combo_search_TextChanged(object sender, EventArgs e)
        {
            this.combo_search.DroppedDown = true;
            search_DESC();
        }
    }
}
