﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace Quotation_management_system
{
    public partial class Dashboard_Main : Form
    {
        //  private int borderSize = 2;
        //field
        // private int boardersize = 2;
        private MySqlConnection con;
        // AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
        AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
      //  AutoCompleteStringCollection o_collection = new AutoCompleteStringCollection();

       // List<string> listOnit = new List<string>();
        List<string> q_listOnit = new List<string>();
        List<string> o_listOnit = new List<string>();
        //List<string> listNew = new List<string>();
        //constructor

        public Dashboard_Main()
        {
            
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");  
           // con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }
      
        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void DashBoard_MouseDown(object sender, MouseEventArgs e)
        {
          //  ReleaseCapture();
            //SendMessage(this.Handle, 0x112, 0xf012, 0);
        }



        private void Form1_Resize(object sender, EventArgs e)
        {
        //    Adjustform();
        }
        private void Adjustform()
        {
           
        }




        private void btnMenu_Click(object sender, EventArgs e)
        {
           
        }

        private void collapseMenu()
        {

            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var dash = new Quotation_list();
            dash.Show();
        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            var dash = new New_Quote();
            dash.Show();
            // this.Close();
        }

        private void Dashboard_Main_Load(object sender, EventArgs e)
        {
            //grapgh();
            deleting_duplicate_entery();
             search_DESC();
            search_order();
            customer_count();
            products_count();
            employee_count();
            order_count();
            quotation_count();
            user_logged_in.Text = Login.u_name;         
            get_quotation();
            get_orders();
            //search_from_quotaion();
            //search_from_orders();
            auto_quotation();
            style();
            //auto_order();
            //auto_order();


        }
        public void style()
        {
            Quotation_Table.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(64, 64, 64); ;
            Quotation_Table.EnableHeadersVisualStyles = false;
            orders_table.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(64, 64, 64); ;
            orders_table.EnableHeadersVisualStyles = false;
        }
        public void auto_order()
        {
            //this.combo_search.AutoCompleteCustomSource = new AutoCompleteStringCollection();
           // combo_order.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            //combo_order.AutoCompleteSource = AutoCompleteSource.None;
        }
        public void auto_quotation()
        {
            combo_search.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
           // combo_search.AutoCompleteSource = AutoCompleteSource.None;
        }
        public void get_quotation()
        {
            DataTable dt = new DataTable();

            MySqlCommand cmd = new MySqlCommand("CALL `get_quotation`()", con);
           // SELECT DISTINCT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id"
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();


            Quotation_Table.DataSource = dt;
            Quotation_Table.Columns[0].HeaderText = "Quot #";
            Quotation_Table.Columns[1].HeaderText = "Ref #";
            Quotation_Table.Columns[2].HeaderText = "Upd Stat";
            Quotation_Table.Columns[3].HeaderText = "Rev Stat";
            Quotation_Table.Columns[4].HeaderText = "Subject";
            Quotation_Table.Columns[5].HeaderText = "Issued At";
            Quotation_Table.Columns[6].HeaderText = "Valid Till";
            Quotation_Table.Columns[7].HeaderText = "Company";
            Quotation_Table.Columns[8].HeaderText = "Customer";
            Quotation_Table.Columns[9].HeaderText = "Size";
            Quotation_Table.Columns[10].HeaderText = "Description";
            Quotation_Table.Columns[11].HeaderText = "Unit Price";
            Quotation_Table.Columns[12].HeaderText = "Grand Total";

            Quotation_Table.Columns[0].Width = 70;
            Quotation_Table.Columns[1].Width = 60;
            Quotation_Table.Columns[2].Width = 40;
            Quotation_Table.Columns[3].Width = 40;
            Quotation_Table.Columns[4].Width = 80;
            Quotation_Table.Columns[5].Width = 80;
            Quotation_Table.Columns[6].Width = 80;
            Quotation_Table.Columns[7].Width = 100;
            Quotation_Table.Columns[8].Width = 100;
            Quotation_Table.Columns[9].Width = 50;
            Quotation_Table.Columns[10].Width = 200;
            Quotation_Table.Columns[11].Width = 70;
            Quotation_Table.Columns[12].Width = 120;

        }
        public void get_orders()
        {
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand("CALL `get_orders`()", con);
           // SELECT DISTINCT orders.q_num,orders.q_ref,orders.q_upd_sta,orders.q_rev_sta,orders.q_sub,orders.q_issued_at,orders.order_date,customer.company_name,customer.contact_person,orders.p_total_price_inc_gst FROM orders INNER JOIN customer ON orders.c_id = customer.c_id
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();


            orders_table.DataSource = dt;
            orders_table.Columns[0].HeaderText = "Quot #";
            orders_table.Columns[1].HeaderText = "Ref #";
            orders_table.Columns[2].HeaderText = "Upd Stat";
            orders_table.Columns[3].HeaderText = "Rev Stat";
            orders_table.Columns[4].HeaderText = "Subject";
            orders_table.Columns[5].HeaderText = "Issued At";
            orders_table.Columns[6].HeaderText = "Valid Till";
            orders_table.Columns[7].HeaderText = "Company";
            orders_table.Columns[8].HeaderText = "Customer";
            orders_table.Columns[9].HeaderText = "Size";
            orders_table.Columns[10].HeaderText = "Description";
            orders_table.Columns[11].HeaderText = "Unit Price";
            orders_table.Columns[12].HeaderText = "Grand Total";

            orders_table.Columns[0].Width = 70;
            orders_table.Columns[1].Width = 60;
            orders_table.Columns[2].Width = 40;
            orders_table.Columns[3].Width = 40;
            orders_table.Columns[4].Width = 80;
            orders_table.Columns[5].Width = 80;
            orders_table.Columns[6].Width = 80;
            orders_table.Columns[7].Width = 100;
            orders_table.Columns[8].Width = 100;
            orders_table.Columns[9].Width = 50;
            orders_table.Columns[10].Width = 200;
            orders_table.Columns[11].Width = 70;
            orders_table.Columns[12].Width = 150;

        }

        private void Quotation_Table_KeyDown(object sender, KeyEventArgs e)
        {

        }

       

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login frm1 = new Login();
            frm1.ShowDialog();
        }

        private void txtCreateAccount_Click(object sender, EventArgs e)
        {
           //this.Hide();
            var dash = new signup();
            dash.ShowDialog();
        }

        private void Dashboard_Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            var dash = new AddProduct();
            dash.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var dash = new product_list();
            dash.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var dash = new customer_list();
            dash.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var dash = new AddCustomers();
            dash.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (txt_search_quote.Text=="")
            {
                get_quotation();
            }
        }

        private void txt_search_KeyDown(object sender, KeyEventArgs e)
        {
           
        }
        private void txt_search_order_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

       

        

        private void button4_Click(object sender, EventArgs e)
        {
            var dash = new New_Quote();
            dash.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            
        }

        private void button8_Click_1(object sender, EventArgs e)
        {

        }

        private void orders_table_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void orders_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Preview_Orders edt = new Preview_Orders();
            int row = orders_table.CurrentRow.Index;
            edt.txt_Quot_Num.Text = Convert.ToString(orders_table[0, row].Value);
            edt.txt_Ref.Text = Convert.ToString(orders_table[1, row].Value);
            edt.txt_Update_Status.Text = Convert.ToString(orders_table[2, row].Value);
            edt.txt_Rev_Sta.Text = Convert.ToString(orders_table[3, row].Value);
            edt.Show();
        }

        private void txt_search_Enter(object sender, EventArgs e)
        {
            
            
        }

        private void txt_search_Leave(object sender, EventArgs e)
        {
          
        }
        private void search_from_quotaion()
        {
          
           
            
        }

       

        private void txt_search_order_Enter(object sender, EventArgs e)
        {

            //if (txt_search_order.Text == "Search Orders")
            //{
            //    txt_search_order.Text = "";
            //}
        }

        private void txt_search_order_Leave(object sender, EventArgs e)
        {
            //if (txt_search_order.Text == "")
            //{
            //    txt_search_order.Text = "Search Orders";
            //    get_orders();
            //}
        }
        private void search_from_orders()
        {
           

        }

        private void txt_search_order_TextChanged(object sender, EventArgs e)
        {
            //if (txt_search_order.Text == "")
            //{
            //    get_orders();
            //}
        }
        public void customer_count()
        {
            try
            {
               
                MySqlCommand cmd = new MySqlCommand("CALL `customer_count`()", con);
                //Select COUNT(*) FROM customer
                cmd.CommandType = CommandType.Text;
                con.Open();
                lbl_customer_count.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }
        public void products_count()
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("CALL `products_count`() ", con);
               // Select COUNT(*) FROM products
                cmd.CommandType = CommandType.Text;
                con.Open();
                lbl_products_count.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }
        public void employee_count()
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("CALL ` employee_count`() ", con);
               // Select COUNT(*) FROM userinfo
                cmd.CommandType = CommandType.Text;
                con.Open();
                lbl_employee_count.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }
        public void order_count()
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("CALL ` order_count`() ", con);
              //  Select COUNT(DISTINCT q_num) FROM orders
                cmd.CommandType = CommandType.Text;
                con.Open();
                lbl_order_count.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }          
        }
        public void quotation_count()
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("CALL `quotation_count`() ", con);
               // Select COUNT(DISTINCT q_num) FROM quotations
                cmd.CommandType = CommandType.Text;
                con.Open();
                lbl_quotation_count.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_date.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        public void comboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DataTable dt = new DataTable();

                MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_size,quotations.p_descrption,quotations.p_unit_price,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id WHERE quotations.q_ref = '" + combo_search.Text + "' OR quotations.q_num = '" + combo_search.Text + "'OR quotations.p_descrption = '" + combo_search.Text + "' OR customer.company_name = '" + combo_search.Text + "' OR customer.contact_person = '" + combo_search.Text + "'", con);


                con.Open();
                MySqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                con.Close();


                Quotation_Table.DataSource = dt;
                Quotation_Table.Columns[0].HeaderText = "Quotation #";
                Quotation_Table.Columns[1].HeaderText = "Reference #";
                Quotation_Table.Columns[2].HeaderText = "Upd Stat";
                Quotation_Table.Columns[3].HeaderText = "Rev Stat";
                Quotation_Table.Columns[4].HeaderText = "Subject";
                Quotation_Table.Columns[5].HeaderText = "Issued At";
                Quotation_Table.Columns[6].HeaderText = "Valid Till";
                Quotation_Table.Columns[7].HeaderText = "Company";
                Quotation_Table.Columns[8].HeaderText = "Customer";
                Quotation_Table.Columns[9].HeaderText = "Size";
                Quotation_Table.Columns[10].HeaderText = "Description";
                Quotation_Table.Columns[11].HeaderText = "Unit Price";
                Quotation_Table.Columns[12].HeaderText = "Grand Total";

                Quotation_Table.Columns[0].Width = 50;
                Quotation_Table.Columns[1].Width = 80;
                Quotation_Table.Columns[2].Width = 30;
                Quotation_Table.Columns[3].Width = 30;
                Quotation_Table.Columns[4].Width = 100;
                Quotation_Table.Columns[5].Width = 80;
                Quotation_Table.Columns[6].Width = 80;
                Quotation_Table.Columns[7].Width = 100;
                Quotation_Table.Columns[8].Width = 100;
                Quotation_Table.Columns[9].Width = 50;
                Quotation_Table.Columns[10].Width = 200;
                Quotation_Table.Columns[11].Width = 70;
                Quotation_Table.Columns[12].Width = 150;
            }
        }
        private void comboBox1_TextUpdate(object sender, EventArgs e)
        {
            //this.combo_search.Items.Clear();
            //listNew.Clear();
            //foreach (var ite in listOnit)
            //{
            //    if (ite.Contains(combo_search.Text))
            //    {
            //        listNew.Add(ite);
            //    }
            //}
            //this.combo_search.Items.AddRange(listNew.ToArray());
            //this.combo_search.SelectionStart = this.combo_search.Text.Length;
            //Cursor = Cursors.Default;
            //this.combo_search.DroppedDown = true;
        }

        private void combo_search_Enter(object sender, EventArgs e)
        {
            this.combo_search.DroppedDown = true;
            search_DESC();


        }

        private void txt_search_quote_FontChanged(object sender, EventArgs e)
        {

        }

        private void combo_search_Leave(object sender, EventArgs e)
        {
            if (combo_search.Text == "")
            {
                combo_search.Text = "Search Quotation";
                get_quotation();
            }

        }
        public void search_DESC()
        {
            string query = "SELECT DISTINCT quotations.q_num,quotations.q_ref,quotations.p_descrption,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id GROUP BY quotations.q_num,customer.company_name ";
            MySqlCommand cmd = new MySqlCommand(query, con); 
           
            con.Open();
            MySqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                collection.Add(rdr.GetString(0));
                q_listOnit.Add(rdr.GetString(0));

                collection.Add(rdr.GetString(1));
                q_listOnit.Add(rdr.GetString(1));

                collection.Add(rdr.GetString(2));
                q_listOnit.Add(rdr.GetString(2));

                collection.Add(rdr.GetString(3));
                q_listOnit.Add(rdr.GetString(3));

                collection.Add(rdr.GetString(4));
                q_listOnit.Add(rdr.GetString(4));
            }
           
            rdr.Close();
            con.Close();
            combo_search.AutoCompleteCustomSource = collection;
            combo_search.Items.AddRange(q_listOnit.ToArray());
           

        }

        public void combo_order_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DataTable dt = new DataTable();

                MySqlCommand cmd = new MySqlCommand("SELECT orders.q_num,orders.q_ref,orders.q_upd_sta,orders.q_rev_sta,orders.q_sub,orders.q_issued_at,orders.q_valid_upto,customer.company_name,customer.contact_person,orders.p_size,orders.p_descrption,orders.p_unit_price,orders.p_total_price_inc_gst FROM orders INNER JOIN customer ON orders.c_id = customer.c_id WHERE orders.q_num = '" + combo_order.Text + "' OR orders.q_ref = '" + combo_order.Text + "' OR customer.company_name = '" + combo_order.Text + "' OR customer.contact_person = '" + combo_order.Text + "' OR orders.p_descrption = '" + combo_order.Text + "'", con);


                con.Open();
                MySqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                con.Close();


                orders_table.DataSource = dt;
                orders_table.Columns[0].HeaderText = "Quotation #";
                orders_table.Columns[1].HeaderText = "Reference #";
                orders_table.Columns[2].HeaderText = "Upd Stat";
                orders_table.Columns[3].HeaderText = "Rev Stat";
                orders_table.Columns[4].HeaderText = "Subject";
                orders_table.Columns[5].HeaderText = "Issued At";
                orders_table.Columns[6].HeaderText = "Valid Till";
                orders_table.Columns[7].HeaderText = "Company";
                orders_table.Columns[8].HeaderText = "Customer";
                orders_table.Columns[9].HeaderText = "Size";
                orders_table.Columns[10].HeaderText = "Description";
                orders_table.Columns[11].HeaderText = "Unit Price";
                orders_table.Columns[12].HeaderText = "Grand Total";

                orders_table.Columns[0].Width = 50;
                orders_table.Columns[1].Width = 80;
                orders_table.Columns[2].Width = 30;
                orders_table.Columns[3].Width = 30;
                orders_table.Columns[4].Width = 100;
                orders_table.Columns[5].Width = 80;
                orders_table.Columns[6].Width = 80;
                orders_table.Columns[7].Width = 100;
                orders_table.Columns[8].Width = 100;
                orders_table.Columns[9].Width = 50;
                orders_table.Columns[10].Width = 200;
                orders_table.Columns[11].Width = 70;
                orders_table.Columns[12].Width = 150;

            }
        }

        private void combo_order_Enter(object sender, EventArgs e)
        {
            this.combo_order.DroppedDown = true;
            //search_order();
        }

        private void combo_order_TextUpdate(object sender, EventArgs e)
        {
            //this.combo_order.Items.Clear();
            //listNew.Clear();
            //foreach (var item in listOnit)
            //{
            //    if (item.Contains(combo_order.Text))
            //    {
            //        listNew.Add(item);
            //    }
            //}
            //this.combo_order.Items.AddRange(listNew.ToArray());
            //this.combo_order.SelectionStart = this.combo_order.Text.Length;
            //Cursor = Cursors.Default;
           // this.combo_order.DroppedDown = true;
            //search_order();
        }
        public void search_order()
        {
            string query = "SELECT DISTINCT orders.q_num,orders.q_ref,customer.company_name,customer.contact_person,orders.p_descrption FROM orders INNER JOIN customer ON orders.c_id = customer.c_id GROUP BY orders.q_num,customer.company_name";
            MySqlCommand cmnd = new MySqlCommand(query, con); //"SELECT p_description FROM products";
            //  SELECT quotations.q_num,customer.company_name,customer.contact_person,quotations.p_description FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
            con.Open();
            MySqlDataReader reader = cmnd.ExecuteReader();
            //while (reader.Read())
            //{
            //o_listOnit.Add(reader.GetString(0));
            //o_listOnit.Add(reader.GetString(1));
            //o_listOnit.Add(reader.GetString(2));
            //o_listOnit.Add(reader.GetString(3));
            //o_listOnit.Add(reader.GetString(4));
            //}
            while (reader.Read())
            {
                collection.Add(reader.GetString(0));
                o_listOnit.Add(reader.GetString(0));

                collection.Add(reader.GetString(1));
                o_listOnit.Add(reader.GetString(1));

                collection.Add(reader.GetString(2));
                o_listOnit.Add(reader.GetString(2));

                collection.Add(reader.GetString(3));
                o_listOnit.Add(reader.GetString(3));

                collection.Add(reader.GetString(4));
                o_listOnit.Add(reader.GetString(4));
            }

            reader.Close();
            con.Close();
            combo_order.AutoCompleteCustomSource = collection;
            combo_order.Items.AddRange(o_listOnit.ToArray());

        }

        private void combo_order_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void combo_order_Leave(object sender, EventArgs e)
        {
            if (combo_order.Text == "")
            {
                combo_order.Text = "Search Orders";
                get_orders();
            }
        }

        public void btn_refresh_Click(object sender, EventArgs e)
        {
         
            deleting_duplicate_entery();
            search_order();
            search_DESC();
            customer_count();
            products_count();
            employee_count();
            order_count();
            quotation_count();
            user_logged_in.Text = Login.u_name;
            get_quotation();
            get_orders();
            style();
            //auto_compltete_list();
            auto_quotation();
            auto_order();
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }
        public void deleting_duplicate_entery()
        {
            con.Open();
            string query = "DELETE FROM products WHERE p_id NOT IN(SELECT* FROM (SELECT MAX(n.p_id) FROM products n GROUP BY n.p_size, n.p_description) x)";
            MySqlCommand cmd = new MySqlCommand(query, con);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txt_UserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel18_Paint(object sender, PaintEventArgs e)
        {

        }

        private void combo_search_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void DashBoard_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            var dash = new Reports();
            dash.Show();
            
        }

        private void lbl_quotation_count_Click(object sender, EventArgs e)
        {

        }
        private void grapgh()
        {

            

        }

        

        private void button11_Click(object sender, EventArgs e)
        {
            var dash = new order_report();
            dash.Show();
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            var dash = new No_of_Quotation();
            dash.Show();
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            var dash = new Order_vs_Quotation();
            dash.Show();
        }

        private void combo_search_TextChanged(object sender, EventArgs e)
        {
            this.combo_search.DroppedDown = true;
            search_DESC();
        }

        private void combo_order_TextChanged(object sender, EventArgs e)
        {
            this.combo_order.DroppedDown = true;
            search_order();
        }

        private void combo_order_DropDown(object sender, EventArgs e)
        {

        }

        private void Quotation_Table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Preview_Quote edt = new Preview_Quote();
            int row = Quotation_Table.CurrentRow.Index;
            edt.txt_Quot_Num.Text = Convert.ToString(Quotation_Table[0, row].Value);
            edt.txt_Ref.Text = Convert.ToString(Quotation_Table[1, row].Value);
            edt.txt_Update_Status.Text = Convert.ToString(Quotation_Table[2, row].Value);
            edt.txt_Rev_Sta.Text = Convert.ToString(Quotation_Table[3, row].Value);

            edt.txt_Subject.Text = Convert.ToString(Quotation_Table[4, row].Value);
            edt.txt_issued.Text = Convert.ToString(Quotation_Table[5, row].Value);
            edt.txt_validity.Text = Convert.ToString(Quotation_Table[6, row].Value);
            edt.txt_Comp_N.Text = Convert.ToString(Quotation_Table[7, row].Value);
            edt.txt_Cont_Per.Text = Convert.ToString(Quotation_Table[8, row].Value);
            edt.Show();
        }
    }
}
