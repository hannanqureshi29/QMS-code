﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;


namespace Quotation_management_system
{
    public partial class Preview_Quote : Form
    {
        private MySqlConnection con;
        SaveFileDialog savefiledialog1 = new SaveFileDialog();
        public string filename;
        AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
        List<string> listOnit = new List<string>();
        List<string> listNew = new List<string>();
        DataTable dt = new DataTable();
        //private double cell1;
        //private string cell2;
        //private string cell3;
        //private string cell4;
        //private string table1;
        public Preview_Quote()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            //con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void Preview_Quote_Load(object sender, EventArgs e)
        {
            Load_data_from_New_Quote();
            savefiledialog1.FileName = "";
            savefiledialog1.Filter = "PDF (*.pdf)|*.pdf";
            label12.Text = Login.u_name;
           
            clone_product_table();
            combo_approved.Text = Login.u_name;
            hide_order_recieved();
            datain_combobox();
            search_DESC();


        }
        private void Load_data_from_New_Quote()
        {

            try
            {
                //MySqlCommand cmd = new MySqlCommand("SELECT * FROM quotations  WHERE q_num ='" + txt_Quot_Num.Text.Trim() + "' LIMIT 1 ", con);

                //MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_id AS qid,quotations.q_year AS qyear,quotations.q_sub AS qsub,quotations.q_lead_t AS qleadt,quotations.q_pay_t AS qpayt,quotations.q_issued_at AS qissuedat,quotations.q_valid_upto AS qvalidupto,quotations.q_terms_c AS qtermsc,quotations.c_id AS cid,quotations.p_price_exc_gst AS priceexcgst,quotations.p_gst_perc AS pgstper,quotations.p_gst_amount AS pgstamount,quotations.p_total_price_inc_gst AS ptotalpriceincgst,quotations.created_by AS createdby,quotations.approvrd_by AS approvedby,customer.company_name AS companyname,customer.contact_person AS contactperson,customer.designation AS desig,customer.cell_num AS cellnum,customer.tel_num AS telnum,customer.fax_num AS faxnum,customer.email AS email FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id  WHERE quotations.q_ref =  '" + txt_Ref.Text + "' AND quotations.q_num ='" + txt_Quot_Num.Text + "' AND quotations.q_upd_sta =  '" + txt_Update_Status.Text + "' AND quotations.q_rev_sta =  '" + txt_Rev_Sta.Text + "'", con);
                MySqlParameter[] pms = new MySqlParameter[4];
                pms[0] = new MySqlParameter("qref", MySqlDbType.VarChar);
                pms[0].Value = txt_Ref.Text;
                pms[1] = new MySqlParameter("qnum", MySqlDbType.VarChar);
                pms[1].Value = txt_Quot_Num.Text;
                pms[2] = new MySqlParameter("qupdsta", MySqlDbType.VarChar);
                pms[2].Value = txt_Update_Status.Text;
                pms[3] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
                pms[3].Value = txt_Rev_Sta.Text;


                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "load_for_new_quotation";
                cmd.Parameters.AddRange(pms);


                con.Open();
                using (MySqlDataReader read = cmd.ExecuteReader())

                {
                    if (read.Read())
                    {
                        txt_Year.Text = (read["qyear"]).ToString();
                       // txt_Subject.Text = (read["qsub"]).ToString();
                        txt_Lead_Time.Text = (read["qleadt"]).ToString();
                        txt_Pay_Term.Text = (read["qpayt"]).ToString();
                       // txt_issued.Value = Convert.ToDateTime(read["qissuedat"]);
                       // txt_validity.Text = (read["qvalidupto"]).ToString();
                        txt_T_Condition.Text = (read["qtermsc"]).ToString();
                        txt_c_id.Text = (read["cid"]).ToString();
                        //txt_Comp_N.Text = (read["companyname"]).ToString();
                       // txt_Cont_Per.Text = (read["contactperson"]).ToString();
                        txt_Desig.Text = (read["desig"]).ToString();
                        txt_Cell.Text = (read["cellnum"]).ToString();
                        txt_Tele.Text = (read["telnum"]).ToString();
                        txt_Fax.Text = (read["faxnum"]).ToString();
                        txt_Email.Text = (read["email"]).ToString();
                        txt_address.Text = (read["address"]).ToString();
                        txt_total_price.Text = (read["priceexcgst"]).ToString();

                        txt_disc.Text = (read["ptotalper"]).ToString();
                        txt_discount_price.Text = (read["ptotalperprice"]).ToString();

                        txtGST.Text = (read["pgstper"]).ToString();
                        txtGSTAmount.Text = (read["pgstamount"]).ToString();
                        txtTotalPriceGST.Text = (read["ptotalpriceincgst"]).ToString();
                        lbl_created.Text = (read["createdby"]).ToString();
                        combo_approved.Text = (read["approvedby"]).ToString();

                        txt_product_no.Text = (read["productorderno"]).ToString();
                        txt_note1.Text = (read["note1"]).ToString();
                        txt_note2.Text = (read["note2"]).ToString();




                    }
                }
                cmd.Dispose();




                // MySqlCommand cmnd = new MySqlCommand("SELECT p_type,p_size,p_model,p_descrption,p_make_o,p_unit,p_quantity,p_unit_price,p_total FROM quotations WHERE q_num ='" + txt_Quot_Num.Text + "' AND q_upd_sta ='" + txt_Update_Status.Text + "' AND q_rev_sta ='" + txt_Rev_Sta.Text + "' ", con);

                MySqlParameter[] prm = new MySqlParameter[3];

                prm[0] = new MySqlParameter("qnum", MySqlDbType.VarChar);
                prm[0].Value = txt_Quot_Num.Text;
                prm[1] = new MySqlParameter("qupdsta", MySqlDbType.VarChar);
                prm[1].Value = txt_Update_Status.Text;
                prm[2] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
                prm[2].Value = txt_Rev_Sta.Text;

                MySqlCommand cmnd = new MySqlCommand();
                cmnd.Connection = con;
                cmnd.CommandType = CommandType.StoredProcedure;
                cmnd.CommandText = "new_quote_product_table";
                cmnd.Parameters.AddRange(prm);



                //New Code
                using (MySqlDataReader sdrr = cmnd.ExecuteReader()) 
                {
                    //Add columns to DataTable.
                    dt.Columns.AddRange(new DataColumn[9] {
                        new DataColumn("SerialNo"),
                        new DataColumn("Size"),
                        new DataColumn("Description"),
                        new DataColumn("Unit"),
                         new DataColumn("QTY"),
                          new DataColumn("UnitPrice"),
                           new DataColumn("Discount"),
                            new DataColumn("Price"),
                              new DataColumn("Total")
                });

                    //Set AutoIncrement True for the First Column.
                    dt.Columns["SerialNo"].AutoIncrement = true;

                    //Set the Starting or Seed value.
                    dt.Columns["SerialNo"].AutoIncrementSeed = 1;

                    //Set the Increment value.
                    dt.Columns["SerialNo"].AutoIncrementStep = 1;
                    while (sdrr.Read())
                    {
                       // dt.Rows.Add(null, sdrr["Size"], sdrr["Description"], sdrr["Unit"], sdrr["QTY"], sdrr["UnitPrice"], sdrr["Discount"], sdrr["Price"], sdrr["Total"]);
                        dt.Rows.Add(null, sdrr["p_size"], sdrr["p_descrption"], sdrr["p_unit"], sdrr["p_quantity"], sdrr["p_unit_price"], sdrr["p_discount"], sdrr["p_discounted_price"], sdrr["p_total"]);
                    }
                }



               // MySqlDataReader sdr = cmnd.ExecuteReader();

              
               // dt.Load(sdr);
                Products_Table.DataSource = dt;

               // dt.Columns[0].DataType = System.Type.GetType("System.Int32");
                //dt.Columns[0].AutoIncrement = true;


                //Set the Starting or Seed value.
               // dt.Columns[0].AutoIncrementSeed = 1;

                //Set the Increment value.
               // dt.Columns[0].AutoIncrementStep = 1;

                //dt.Columns[0].DataType = GetType(Int32);
                dt.Dispose();
                //sdr.Dispose();
                cmnd.Dispose();


                //Products_Table.Columns[0].
                //Products_Table.Columns[0].ValueType = typeof(Int32);

                Products_Table.Columns[0].HeaderText = "Sr";
                Products_Table.Columns[1].HeaderText = "Size";
                Products_Table.Columns[2].HeaderText = "Description";
                Products_Table.Columns[3].HeaderText = "Unit";
                Products_Table.Columns[4].HeaderText = "QTY";
                Products_Table.Columns[5].HeaderText = "UnitPrice";
                Products_Table.Columns[6].HeaderText = "Discount%";
                Products_Table.Columns[7].HeaderText = "Unit Price";
                Products_Table.Columns[8].HeaderText = "Total";


                Products_Table.Columns[0].Width = 50;
                Products_Table.Columns[1].Width = 50;
                Products_Table.Columns[2].Width = 300;
                Products_Table.Columns[3].Width = 100;
                Products_Table.Columns[4].Width = 100;
                Products_Table.Columns[5].Width = 100;
                Products_Table.Columns[6].Width = 100;
                Products_Table.Columns[7].Width = 100;
                Products_Table.Columns[8].Width = 200;

            }
            catch (Exception exc)
            {
                con.Close();
                MessageBox.Show(exc.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void Products_Table_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void btnAdjust_Click(object sender, EventArgs e)
        {

        }

        private void lbl_date_Click(object sender, EventArgs e)
        {

        }

        private void panlel_grid_3_Paint(object sender, PaintEventArgs e)
        {
            //if (con.State != ConnectionState.Open)
            //{
            //    con.Open();
            //    cmd.ExecuteNonQuery();
            //    cmd.Dispose();
            //}
            //else
            //{
            //    cmd.ExecuteNonQuery();
            //    cmd.Dispose();
            //}
        }

        private void button5_Click(object sender, EventArgs e)
        {

      //     string query = ("UPDATE quotations set approvrd_by ='" + combo_approved.Text + "' WHERE q_num ='" + txt_Quot_Num.Text + "' AND q_upd_sta='"+txt_Update_Status.Text+ "' AND q_rev_sta = '"+txt_Rev_Sta.Text+"' ;");

            MySqlParameter[] pms = new MySqlParameter[4];
            pms[0] = new MySqlParameter("approvrdby", MySqlDbType.VarChar);
            pms[0].Value = combo_approved.Text;
            pms[1] = new MySqlParameter("qnum", MySqlDbType.VarChar);
            pms[1].Value = txt_Quot_Num.Text;
            pms[2] = new MySqlParameter("qupdsta", MySqlDbType.VarChar);
            pms[2].Value = txt_Update_Status.Text;
            pms[3] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
            pms[3].Value = txt_Rev_Sta.Text;

            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "update_approve_quotation";
            cmd.Parameters.AddRange(pms);

           // MySqlCommand cmnd = new MySqlCommand(query, con);
            MySqlDataReader read;
            con.Open();
            read = cmd.ExecuteReader();
            con.Close();
            MessageBox.Show("Updated Successfully !", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btn_order_rec_Click(object sender, EventArgs e)
        {
            // Preview_Orders edt = new Preview_Orders();
            //// int row = Products_Table.CurrentRow.Index;
            // //edt.txt_Quot_Num.Text = Convert.ToString(txt_Quot_Num[0, row]);
            // //edt.txt_Ref.Text = Convert.ToString(txt_Ref[1, row].Value);
            // //edt.txt_Update_Status.Text = Convert.ToString(txt_Update_Status[2, row].Value);
            // //edt.txt_Rev_Sta.Text = Convert.ToString(txt_Rev_Sta[3, row].Value);\

            // edt.txt_Quot_Num.Text = Convert.ToString(txt_Quot_Num.Text);
            // edt.txt_Ref.Text = Convert.ToString(txt_Ref.Text);
            // edt.txt_Update_Status.Text = Convert.ToString(txt_Update_Status.Text);
            // edt.txt_Rev_Sta.Text = Convert.ToString(txt_Rev_Sta.Text);
            // edt.Show();
            try
            {
                for (int i = 0; i < Products_Table.Rows.Count - 1; i++)
                {
                    string query = "INSERT INTO orders (q_ref,q_num,q_upd_sta,q_rev_sta,q_year,q_sub,q_lead_t,q_pay_t,q_issued_at,q_valid_upto,q_terms_c,c_id,p_size,p_descrption,p_unit_price,p_unit,p_quantity,p_total,p_discount,p_discounted_price,p_price_exc_gst,p_total_per,p_total_per_price,p_gst_perc,p_gst_amount,p_total_price_inc_gst,created_by,order_date,product_order_no,note_1,note_2) VALUES (@qref,@qnum,@qupdsta,@qrevsta,@qyear,@qsub,@qleadt,@qpayt,@date_issue,@date_valid,@qtermsc,@cid,@psize,@pdescrption,@punitprice,@punit,@pquantity,@ptotal,@pdiscount,@pdiscountedprice,@ppriceexcgst,@ptotalper,@ptotalperprice,@pgstperc,@pgstamount,@ptotalpriceincgst,@createdby,NOW(),@productorderno,@note1,@note2)";
                    // "INSERT INTO orders (q_ref,q_num,q_upd_sta,q_rev_sta,q_year,q_sub,q_lead_t,q_pay_t,q_issued_at,q_valid_upto,q_terms_c,c_id,p_type,p_size,p_model,p_descrption,p_make_o,p_unit,p_quantity,p_unit_price,p_total,p_price_exc_gst,p_gst_perc,p_gst_amount,p_total_price_inc_gst,created_by,order_date) VALUES (@qref,@qnum,@qupdsta,@qrevsta,@qyear,@qsub,@qleadt,@qpayt,@date_issue,@date_valid,@qtermsc,@cid,@ptype,@psize,@pmodel,@pdescrption,@pmakeo,@punit,@pquantity,@punitprice,@ptotal,@ppriceexcgst,@pgstperc,@pgstamount,@ptotalpriceincgst,@createdby,NOW())"



                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@qref", txt_Ref.Text);
                    cmd.Parameters.AddWithValue("@qnum", txt_Quot_Num.Text);
                    cmd.Parameters.AddWithValue("@qupdsta", txt_Update_Status.Text);
                    cmd.Parameters.AddWithValue("@qrevsta", txt_Rev_Sta.Text);
                    cmd.Parameters.AddWithValue("@qyear", txt_Year.Text);
                    cmd.Parameters.AddWithValue("@qsub", txt_Subject.Text);
                    cmd.Parameters.AddWithValue("@qleadt", txt_Lead_Time.Text);
                    cmd.Parameters.AddWithValue("@qpayt", txt_Pay_Term.Text);
                    cmd.Parameters.AddWithValue("@date_issue", txt_issued.Value);
                    cmd.Parameters.AddWithValue("@date_valid", txt_validity.Value);
                    cmd.Parameters.AddWithValue("@qtermsc", txt_T_Condition.Text);
                    cmd.Parameters.AddWithValue("@cid", txt_c_id.Text);
                    //@pdiscount,@pdiscountedprice,@ppriceexcgst,@ptotalper,@ptotalperprice
                    cmd.Parameters.AddWithValue("@psize", Products_Table.Rows[i].Cells[1].Value.ToString());
                    cmd.Parameters.AddWithValue("@pdescrption", Products_Table.Rows[i].Cells[2].Value.ToString());

                    cmd.Parameters.AddWithValue("@punit", Products_Table.Rows[i].Cells[3].Value.ToString());


                    cmd.Parameters.AddWithValue("@pquantity", Products_Table.Rows[i].Cells[4].Value.ToString());
                    cmd.Parameters.AddWithValue("@punitprice", Products_Table.Rows[i].Cells[5].Value.ToString());
                    cmd.Parameters.AddWithValue("@pdiscount", Products_Table.Rows[i].Cells[6].Value.ToString());
                    cmd.Parameters.AddWithValue("@pdiscountedprice", Products_Table.Rows[i].Cells[7].Value.ToString());
                    cmd.Parameters.AddWithValue("@ptotal", Products_Table.Rows[i].Cells[8].Value.ToString());
                    cmd.Parameters.AddWithValue("@ppriceexcgst", txt_total_price.Text);

                    cmd.Parameters.AddWithValue("@ptotalper", txt_disc.Text);
                    cmd.Parameters.AddWithValue("@ptotalperprice", txt_discount_price.Text);

                    cmd.Parameters.AddWithValue("@pgstperc", txtGST.Text);
                    cmd.Parameters.AddWithValue("@pgstamount", txtGSTAmount.Text);
                    cmd.Parameters.AddWithValue("@ptotalpriceincgst", txtTotalPriceGST.Text);
                    cmd.Parameters.AddWithValue("@createdby", label12.Text);
                    cmd.Parameters.AddWithValue("@productorderno", txt_product_no.Text);

                    cmd.Parameters.AddWithValue("@note1", txt_note1.Text);
                    cmd.Parameters.AddWithValue("@note2", txt_note2.Text);
                    if (con.State != ConnectionState.Open)
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();
                    }
                    else
                    {
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();
                    }

                }

                MessageBox.Show("Order Recieved Successfully !", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Dashboard_Main master = (Dashboard_Main)Application.OpenForms["Dashboard_Main"];
                master.btn_refresh.PerformClick();
            }

            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button5_TabIndexChanged(object sender, EventArgs e)
        {
     
        }
        private void hide_order_recieved()
        {
            try
            { 
               
                //string query = "SELECT * FROM orders WHERE q_num = '" + txt_Quot_Num.Text + "' AND q_upd_sta = '" + txt_Update_Status.Text + "' AND q_rev_sta = '" + txt_Rev_Sta.Text + "' ";
                // MySqlCommand cmd = new MySqlCommand(query, con);
                MySqlParameter[] pms = new MySqlParameter[3];
                pms[0] = new MySqlParameter("qnum", MySqlDbType.VarChar);
                pms[0].Value = txt_Quot_Num.Text;
                pms[1] = new MySqlParameter("qupdsta", MySqlDbType.VarChar);
                pms[1].Value = txt_Update_Status.Text;
                pms[2] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
                pms[2].Value = txt_Rev_Sta.Text;



                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hide_order";
                cmd.Parameters.AddRange(pms);

                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                //if (reader.HasRows)
                //{
                //    btn_order_rec.Visible = false;
                //    btn_order_rec.Enabled = false;
                //}
                //else
                //{
                //    btn_order_rec.Enabled = true;
                //    btn_order_rec.Visible = true;
                //}
             }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btn_print_Click(object sender, EventArgs e)
        {

            Byte[] bytes;
            if (savefiledialog1.ShowDialog() == DialogResult.OK)
            {
                using (var ms = new MemoryStream())
                {
                    // Declaring File Name via Textbox
                    filename = savefiledialog1.FileName;
                    // Code Start for Font Styles
                    iTextSharp.text.Font ptitle = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 20, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pstitle = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 16, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pdata = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    iTextSharp.text.Font p_s_data = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    iTextSharp.text.Font pbold = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pb = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    iTextSharp.text.Font pb_u = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.UNDERLINE, BaseColor.BLACK);
                    iTextSharp.text.Font pfoot = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLDITALIC, BaseColor.BLACK);
                    iTextSharp.text.Font punder = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.UNDERLINE, BaseColor.BLACK);
                    iTextSharp.text.Font pdata1 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    iTextSharp.text.Font pbold1 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD, BaseColor.BLUE);
                    iTextSharp.text.Font pbold2 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD, BaseColor.RED);
                    iTextSharp.text.Font pdata2 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLUE);
                    iTextSharp.text.Font pb1 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.RED);
                    iTextSharp.text.Font pb2 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 14, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                    // Code Ends for Font Styling

                    //Code Starts for Method of Saving File As PDF
                    Paragraph paragraph = new Paragraph();
                    Document pdffile = new Document(PageSize.A4, 8f, 8f, 80f, 150f);
                    //new FileStream(textBox1.Text, FileMode.Create)
                    PdfWriter write = PdfWriter.GetInstance(pdffile, ms);
                    pdffile.Open();
                    //For Adding Logo on Top
                    //System.Drawing.Bitmap kitz = Quotation_management_system.Properties.Resources.kitz;
                    //iTextSharp.text.Image image1 = iTextSharp.text.Image.GetInstance(kitz, System.Drawing.Imaging.ImageFormat.Png);
                    //System.Drawing.Bitmap star_corp = Quotation_management_system.Properties.Resources.star_corp;
                    //iTextSharp.text.Image image2 = iTextSharp.text.Image.GetInstance(star_corp, System.Drawing.Imaging.ImageFormat.Png);
                    //image2.ScaleToFit(140.0F, 100.0F);
                    //image2.SetAbsolutePosition(pdffile.Left, pdffile.Top - 40);
                    //pdffile.Add(image2);
                    //image1.ScaleToFit(150.0F, 150.0F);
                    //image1.SetAbsolutePosition(pdffile.Right - 150, pdffile.Top - 46);
                    //pdffile.Add(image1);
                    //Adding Header Text

                    //pdffile.Add(new Paragraph("102-McLeod Rd,Australia Chowk,Lahore", pdata1));
                    //pdffile.Add(new Paragraph("Tel: +92-42-37659317,7667735    ", pdata1));
                    //pdffile.Add(new Paragraph("Fax: +92-42-37631666", pdata1));
                    //pdffile.Add(new Paragraph("Email: starlhr@starcorporation.org", pdata1));
                    //  pdffile.Add(new Paragraph("----------------------------------------------------------------------------------------------------------------------------------------------"));
                    // pdffile.Add(new Paragraph("  "));

                    PdfPTable table11 = new PdfPTable(4);
                    table11.WidthPercentage = 100;

                    //set column widths
                    int[] firstTablellwi9 = { 480, 40, 109, 116 };
                    table11.SetWidths(firstTablellwi9);


                    PdfPCell h1e27 = new PdfPCell(new Phrase(txt_Comp_N.Text, pb2));
                    h1e27.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1e27.VerticalAlignment = Element.ALIGN_LEFT;
                    h1e27.FixedHeight = 20f;
                    h1e27.BorderWidthBottom = 0f;
                    h1e27.BorderWidthLeft = 0f;
                    h1e27.BorderWidthTop = 0f;
                    h1e27.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table11.AddCell(h1e27);


                    PdfPCell h1e28 = new PdfPCell(new Phrase("", pb2));
                    h1e28.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1e28.VerticalAlignment = Element.ALIGN_LEFT;
                    h1e28.FixedHeight = 15f;
                    h1e28.BorderWidthBottom = 0f;
                    h1e28.BorderWidthLeft = 0f;
                    h1e28.BorderWidthTop = 0f;
                    h1e28.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table11.AddCell(h1e28);



                    PdfPCell h1e29 = new PdfPCell(new Phrase("Date: ", pb));
                    h1e29.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e29.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e29.FixedHeight = 15f;
                    h1e29.BorderWidthBottom = 0f;
                    h1e29.BorderWidthLeft = 0f;
                    h1e29.BorderWidthTop = 0f;
                    h1e29.BorderWidthRight = 0f;

                    table11.AddCell(h1e29);


                    PdfPCell h1e30 = new PdfPCell(new Phrase(txt_issued.Text, pb));
                    h1e30.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e30.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e30.FixedHeight = 15f;
                    h1e30.BorderWidthBottom = 0f;
                    h1e30.BorderWidthLeft = 0f;
                    h1e30.BorderWidthTop = 0f;
                    h1e30.BorderWidthRight = 0f;

                    table11.AddCell(h1e30);

                    pdffile.Add(table11);

                    //next table

                    PdfPTable table12 = new PdfPTable(4);
                    table12.WidthPercentage = 100;

                    //set column widths
                    int[] firstTablellwi10 = { 40, 480, 109, 116 };
                    table12.SetWidths(firstTablellwi10);


                    PdfPCell h1e31 = new PdfPCell(new Phrase("Cell", pb));
                    h1e31.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1e31.VerticalAlignment = Element.ALIGN_LEFT;
                    h1e31.FixedHeight = 15f;
                    h1e31.BorderWidthBottom = 0f;
                    h1e31.BorderWidthLeft = 0f;
                    h1e31.BorderWidthTop = 0f;
                    h1e31.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table12.AddCell(h1e31);


                    PdfPCell h1e32 = new PdfPCell(new Phrase(txt_Cell.Text, pb));
                    h1e32.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1e32.VerticalAlignment = Element.ALIGN_LEFT;
                    h1e32.FixedHeight = 15f;
                    h1e32.BorderWidthBottom = 0f;
                    h1e32.BorderWidthLeft = 0f;
                    h1e32.BorderWidthTop = 0f;
                    h1e32.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table12.AddCell(h1e32);


                    PdfPCell h1e33 = new PdfPCell(new Phrase("REF: ", pb));
                    h1e33.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e33.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e33.FixedHeight = 15f;
                    h1e33.BorderWidthBottom = 0f;
                    h1e33.BorderWidthLeft = 0f;
                    h1e33.BorderWidthTop = 0f;
                    h1e33.BorderWidthRight = 0f;

                    table12.AddCell(h1e33);


                    PdfPCell h1e34 = new PdfPCell(new Phrase(txt_Quot_Num.Text, pb));
                    h1e34.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e34.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e34.FixedHeight = 15f;
                    h1e34.BorderWidthBottom = 0f;
                    h1e34.BorderWidthLeft = 0f;
                    h1e34.BorderWidthTop = 0f;
                    h1e34.BorderWidthRight = 0f;

                    table12.AddCell(h1e34);

                    pdffile.Add(table12);

                    pdffile.Add(new Paragraph("Email: " + txt_Email.Text, pdata2));
                    pdffile.Add(new Paragraph("Attn: " + txt_Cont_Per.Text, pbold));
                    pdffile.Add(new Paragraph("                                                                Subject: " + txt_Subject.Text, pbold1));
                    pdffile.Add(new Paragraph("Dear Sir, ", pdata));
                    pdffile.Add(new Paragraph("Thank you very much for your good response & cooperation to send us your valuable enquiry Ref #." + txt_Ref.Text, pdata));
                    pdffile.Add(new Paragraph("We are sending you quotation for the same, ", pdata));
                    pdffile.Add(new Paragraph("  "));

                    
                    pdffile.Add(paragraph);
                    PdfPTable pdftable = new PdfPTable(product_table_pdf.Columns.Count);
                    //pdftable.WidthPercentage = 97f;
                    pdftable.TotalWidth = 580f;
                    pdftable.LockedWidth = true;
                    int[] intTblWidth = new[] { 25, 50, 265, 30, 35, 85, 90 };

                    pdftable.SetWidths(intTblWidth);

                    for (int i = 0; i <= product_table_pdf.Columns.Count - 1; i++)
                    {
                        //pdftable.SetWidths(intTblWidth);
                        pdftable.HorizontalAlignment = 0;
                        pdftable.SpacingBefore = 5.0F;
                    }
                    PdfPCell pdfcell = new PdfPCell();

                    for (int i = 0; i <= product_table_pdf.Columns.Count - 1; i++)
                    {
                        pdfcell = new PdfPCell(new Phrase(new Chunk(product_table_pdf.Columns[i].HeaderText, pb)));
                        pdfcell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                        pdfcell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
                        pdfcell.FixedHeight = (20f);
                        pdfcell.BackgroundColor = new iTextSharp.text.BaseColor(Color.Gray);
                        pdftable.AddCell(pdfcell);
                    }
                    // pdfcell.BackgroundColor = new iTextSharp.text.BaseColor(128, 128, 128);
                   

                    for (int i = 0; i <= product_table_pdf.Rows.Count - 2; i++)
                    {
                        for (int j = 0; j <= product_table_pdf.Columns.Count - 1; j++)
                        {
                            pdfcell = new PdfPCell(new Phrase(product_table_pdf[j, i].Value.ToString(), pdata));
                            pdftable.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                            pdfcell.FixedHeight = (15f);
                            pdftable.AddCell(pdfcell);
                          
                            
                        }
                     
                    }
                  //  pdffile.BottomMargin = 60;
                    pdffile.Add(pdftable);


                   
                    // Table5

                    PdfPTable table5 = new PdfPTable(4);
                    table5.WidthPercentage = 100;

                    //set column widths
                    int[] firstTablellwi = { 40, 480, 109, 116 };
                    table5.SetWidths(firstTablellwi);

                   
                    PdfPCell h1e3 = new PdfPCell(new Phrase("Note:", pb1));
                    h1e3.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1e3.VerticalAlignment = Element.ALIGN_LEFT;
                    h1e3.FixedHeight = 15f;
                    h1e3.BorderWidthBottom = 0f;
                    h1e3.BorderWidthLeft = 0f;
                    h1e3.BorderWidthTop = 0f;
                    h1e3.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table5.AddCell(h1e3);


                    PdfPCell h1e4 = new PdfPCell(new Phrase(txt_note1.Text, pb1));
                    h1e4.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1e4.VerticalAlignment = Element.ALIGN_LEFT;
                    h1e4.FixedHeight = 15f;
                    h1e4.BorderWidthBottom = 0f;
                    h1e4.BorderWidthLeft = 0f;
                    h1e4.BorderWidthTop = 0f;
                    h1e4.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table5.AddCell(h1e4);


                    PdfPCell h1e5 = new PdfPCell(new Phrase("Total ", pb));
                    h1e5.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e5.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e5.FixedHeight = 15f;
                    
                    table5.AddCell(h1e5);


                    PdfPCell h1e6 = new PdfPCell(new Phrase(txt_total_price.Text, pb));
                    h1e6.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e6.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e6.FixedHeight = 15f;
                   
                    table5.AddCell(h1e6);

                    pdffile.Add(table5);


                    // TABLE8

                    PdfPTable table8 = new PdfPTable(4);
                    table8.WidthPercentage = 100;

                    //set column widths
                    int[] firstTablellwi3 = { 40, 480, 109, 116 };
                    table8.SetWidths(firstTablellwi3);


                    PdfPCell h1e15 = new PdfPCell(new Phrase("Note:", pb1));
                    h1e15.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1e15.VerticalAlignment = Element.ALIGN_LEFT;
                    h1e15.FixedHeight = 15f;
                    h1e15.BorderWidthBottom = 0f;
                    h1e15.BorderWidthLeft = 0f;
                    h1e15.BorderWidthTop = 0f;
                    h1e15.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table8.AddCell(h1e15);


                    PdfPCell h1e16 = new PdfPCell(new Phrase(txt_note2.Text, pb1));
                    h1e16.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1e16.VerticalAlignment = Element.ALIGN_LEFT;
                    h1e16.FixedHeight = 15f;
                    h1e16.BorderWidthBottom = 0f;
                    h1e16.BorderWidthLeft = 0f;
                    h1e16.BorderWidthTop = 0f;
                    h1e16.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table8.AddCell(h1e16);


                    PdfPCell h1e17 = new PdfPCell(new Phrase("Discount %", pb));
                    h1e17.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e17.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e17.FixedHeight = 15f;

                    table8.AddCell(h1e17);


                    PdfPCell h1e18 = new PdfPCell(new Phrase(txt_disc.Text, pb));
                    h1e18.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e18.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e18.FixedHeight = 15f;

                    table8.AddCell(h1e18);

                    pdffile.Add(table8);


                    // TABLE9
                    PdfPTable table9 = new PdfPTable(4);
                    table9.WidthPercentage = 100;

                    //set column widths
                    int[] firstTablellwi4 = { 250, 270, 109, 116 };
                    table9.SetWidths(firstTablellwi4);


                    PdfPCell h1e19 = new PdfPCell(new Phrase("", pb));
                    h1e19.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e19.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e19.FixedHeight = 15f;
                    h1e19.BorderWidthBottom = 0f;
                    h1e19.BorderWidthLeft = 0f;
                    h1e19.BorderWidthTop = 0f;
                    h1e19.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table9.AddCell(h1e19);


                    PdfPCell h1e20 = new PdfPCell(new Phrase("", pb));
                    h1e20.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e20.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e20.FixedHeight = 15f;
                    h1e20.BorderWidthBottom = 0f;
                    h1e20.BorderWidthLeft = 0f;
                    h1e20.BorderWidthTop = 0f;
                    h1e20.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table9.AddCell(h1e20);


                    PdfPCell h1e21 = new PdfPCell(new Phrase("After Discount", pb));
                    h1e21.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e21.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e21.FixedHeight = 15f;

                    table9.AddCell(h1e21);


                    PdfPCell h1e122 = new PdfPCell(new Phrase(txt_discount_price.Text, pb));
                    h1e122.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e122.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e122.FixedHeight = 15f;

                    table9.AddCell(h1e122);

                    pdffile.Add(table9);


                    // TABLE 6

                    PdfPTable table6 = new PdfPTable(4);
                    table6.WidthPercentage = 100;

                    //set column widths
                    int[] firstTablellwi1 = { 250, 270, 109, 116 };
                    table6.SetWidths(firstTablellwi4);


                    PdfPCell h1e7 = new PdfPCell(new Phrase("", pb));
                    h1e7.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e7.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e7.FixedHeight = 15f;
                    h1e7.BorderWidthBottom = 0f;
                    h1e7.BorderWidthLeft = 0f;
                    h1e7.BorderWidthTop = 0f;
                    h1e7.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table6.AddCell(h1e7);


                    PdfPCell h1e8 = new PdfPCell(new Phrase("", pb));
                    h1e8.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e8.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e8.FixedHeight = 15f;
                    h1e8.BorderWidthBottom = 0f;
                    h1e8.BorderWidthLeft = 0f;
                    h1e8.BorderWidthTop = 0f;
                    h1e8.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table6.AddCell(h1e8);


                    PdfPCell h1e9 = new PdfPCell(new Phrase("17% GST ", pb));
                    h1e9.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e9.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e9.FixedHeight = 15f;

                    table6.AddCell(h1e9);


                    PdfPCell h1e10 = new PdfPCell(new Phrase(txtGSTAmount.Text, pb));
                    h1e10.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e10.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e10.FixedHeight = 15f;

                    table6.AddCell(h1e10);

                    pdffile.Add(table6);


                    // TABLE 7

                    PdfPTable table7 = new PdfPTable(4);
                    table7.WidthPercentage = 100;

                    //set column widths
                    int[] firstTablellwi2 = { 250, 270, 109, 116 };
                    table7.SetWidths(firstTablellwi2);


                    PdfPCell h1e11 = new PdfPCell(new Phrase("", pb));
                    h1e11.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e11.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e11.FixedHeight = 15f;
                    h1e11.BorderWidthBottom = 0f;
                    h1e11.BorderWidthLeft = 0f;
                    h1e11.BorderWidthTop = 0f;
                    h1e11.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table7.AddCell(h1e11);


                    PdfPCell h1e12 = new PdfPCell(new Phrase("", pb));
                    h1e12.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e12.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e12.FixedHeight = 15f;
                    h1e12.BorderWidthBottom = 0f;
                    h1e12.BorderWidthLeft = 0f;
                    h1e12.BorderWidthTop = 0f;
                    h1e12.BorderWidthRight = 0f;
                    // h1.Colspan = 
                    table7.AddCell(h1e12);


                    PdfPCell h1e13 = new PdfPCell(new Phrase("G.Total", pb));
                    h1e13.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e13.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e13.FixedHeight = 15f;

                    table7.AddCell(h1e13);


                    PdfPCell h1e14 = new PdfPCell(new Phrase(txtTotalPriceGST.Text, pb));
                    h1e14.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1e14.VerticalAlignment = Element.ALIGN_CENTER;
                    h1e14.FixedHeight = 15f;

                    table7.AddCell(h1e14);

                    pdffile.Add(table7);




                 
                    pdffile.Add(new Paragraph("    "));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Price Excl. GST:  " + txt_total_price.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Discount %:  " + txt_disc.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Discount Price:  " + txt_discount_price.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Sales Tax @ 17%:  " + txtGSTAmount.Text, pdata));
                    //pdffile.Add(new Paragraph("                                                                                                                                          Total Price Incl. GST:  " + txtTotalPriceGST.Text, pb));

                    pdffile.Add(new Paragraph("Terms and Conditions:", punder));
                    pdffile.Add(new Paragraph(txt_T_Condition.Text, pdata));
                    pdffile.Add(new Paragraph("Lead Time: " + txt_Lead_Time.Text, pdata));
                    pdffile.Add(new Paragraph("Payment Terms: " + txt_Pay_Term.Text, pdata));
                    pdffile.Add(new Paragraph("Valid Till: " + txt_validity.Text, pdata));
                    pdffile.Add(new Paragraph("Price: Ex-Godown Lahore", pdata));
                    pdffile.Add(new Paragraph("    "));
                    pdffile.Add(new Paragraph("We hope above offer is acceptable to you and look forward to your esteem order.", p_s_data));
                  
                    
                    pdffile.Close();
                    bytes = ms.ToArray();
                   // pdffile.NewPage();
                }

              
                //Read our PDF and apply page numbers
                using (var reader = new PdfReader(bytes))
                {
                    using (var ms = new MemoryStream())
                    {
                        using (var stamper = new PdfStamper(reader, ms))
                        {
                            int PageCount = reader.NumberOfPages;
                            iTextSharp.text.Font pdata = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 9, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                            iTextSharp.text.Font pdata1 = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                            iTextSharp.text.Font pb = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                            // For Adding Logo on Top
                            System.Drawing.Bitmap kitz = Quotation_management_system.Properties.Resources.kitz;
                            iTextSharp.text.Image image1 = iTextSharp.text.Image.GetInstance(kitz, System.Drawing.Imaging.ImageFormat.Png);

                            System.Drawing.Bitmap star_corp = Quotation_management_system.Properties.Resources.star_corp;
                            iTextSharp.text.Image image2 = iTextSharp.text.Image.GetInstance(star_corp, System.Drawing.Imaging.ImageFormat.Png);
                           
                            for (int i = 1; i <= PageCount; i++)
                            {
                               
       
                                PdfContentByte content = stamper.GetUnderContent(i);
                                image2.ScaleToFit(180.0F, 150.0F);
                                image2.SetAbsolutePosition(10, 780);

                                content.AddImage(image2);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("   Importor & Stockist: Valves,Pipes & Fittings.", i, PageCount), pb), 5, 771, 0);



                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("                                                                                                                                                        Authorized Agent & Distributor:", i, PageCount), pb), 5, 825, 0);
                                PdfContentByte content1 = stamper.GetUnderContent(i);
                                image1.ScaleToFit(155.0F, 150.0F);
                                image1.SetAbsolutePosition(426, 770);

                                content1.AddImage(image1);

                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Lahore Office:                                                                                                                                Faisalabad Office:", i, PageCount), pdata), 5, 55, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("102-McLeod Rd,Australia Chowk,                                                                                                 Shop # 135,Ground Floor Railway Road,", i, PageCount), pdata), 5, 45, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Lahore-Pakistan. Tel: +92-42-37659317, 37667735,                                                                     Faisalabad-Pakistan.Tel: +92-41-2629532, 2642259", i, PageCount), pdata), 5, 35, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Fax: +92-42-37631666                                                                                                                  Fax: +92-41-2629531", i, PageCount), pdata), 5, 25, 0);
                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Email: starlhr@starcorporation.org                     http://www.starcorporation.org                           Email: starcorp@starcorporation.org", i, PageCount), pdata), 5, 15, 0);



                                ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_CENTER, new Phrase(String.Format("                                                                                                                                                                                                                                                                                                                                                                                                                                    Page {0} of {1}", i, PageCount), pdata1), 100, 3, 0);
                               // ColumnText.ShowTextAligned(stamper.GetOverContent(i), Element.ALIGN_LEFT, new Phrase(String.Format("Prepared By: " + label12.Text + "                                                  Approved By: ________________ ", i, PageCount)), 100, 10, 0);
                            }
                        }
                        bytes = ms.ToArray();
                    }
                }
                var outputFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), filename);
                System.IO.File.WriteAllBytes(outputFile, bytes);
                MessageBox.Show("Data Exported to PDF Successfuly");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_date.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void txt_Update_Status_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Rev_Sta_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Year_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void datain_combobox()
        {
            try
            {
                string query = "CALL `datain_combo`()";
                MySqlCommand cmd = new MySqlCommand(query, con);
           
                con.Open();
                MySqlDataReader sdr = cmd.ExecuteReader();
            
                while (sdr.Read())
                {            
                        combo_approved.Items.Add(sdr[0]);              
                }
                sdr.Close();
            }
            catch (Exception )
            {
                // write exception info to log or anything else
                MessageBox.Show("Error occured!");
                con.Close();
            }
            finally
            { 
                con.Close();
            }
        }

        internal void btn_refresh_Click()
        {
            throw new NotImplementedException();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i < Products_Table.Rows.Count - 1; i++)
            //{
            //    string query = ("UPDATE quotations SET q_ref=  '" + txt_Ref.Text + "',q_num=  '" + txt_Quot_Num.Text + "',q_upd_sta=  '" + txt_Update_Status.Text + "',q_rev_sta=  '" + txt_Rev_Sta.Text + "',q_year=  '" + txt_Year.Text + "',q_sub=  '" + txt_Subject.Text + "',q_lead_t=  '" + txt_Lead_Time.Text + "',q_pay_t=  '" + txt_Pay_Term.Text + "',q_issued_at=  '" + txt_issued.MinDate + "',q_valid_upto=  '" + txt_validity.MinDate + "',q_terms_c=  '" + txt_T_Condition.Text + "',c_id=  '" + txt_c_id.Text + "',p_size=  '" + Products_Table.Rows[i].Cells[1].Value.ToString() + "',p_descrption=  '" + Products_Table.Rows[i].Cells[2].Value.ToString() + "',p_unit=  '" + Products_Table.Rows[3].Cells[1].Value.ToString() + "',p_quantity=  '" + Products_Table.Rows[i].Cells[4].Value.ToString() + "',p_unit_price=  '" + Products_Table.Rows[i].Cells[5].Value.ToString() + "',p_total=  '" + Products_Table.Rows[i].Cells[6].Value.ToString() + "',p_price_exc_gst=  '" + txt_total_price.Text + "',p_gst_perc=  '" + txtGST.Text + "',p_gst_amount=  '" + txtGSTAmount.Text + "',p_total_price_inc_gst=  '" + txtTotalPriceGST.Text + "',created_by=  '" + lbl_created.Text + "',approvrd_by=  '" + combo_approved.Text + "' WHERE q_num = '"+txt_Quot_Num.Text+"'");

            //    MySqlCommand cmnd = new MySqlCommand(query, con);
            //MySqlDataReader read;
            //con.Open();
            //read = cmnd.ExecuteReader();
            //    con.Close();
            //}

            try
            {
                for (int i = 0; i < Products_Table.Rows.Count - 1; i++)
                {
                    MySqlParameter[] pms = new MySqlParameter[30];
                    pms[0] = new MySqlParameter("qref", MySqlDbType.VarChar);
                    pms[0].Value = txt_Ref.Text;
                    pms[1] = new MySqlParameter("qnum", MySqlDbType.VarChar);
                    pms[1].Value = txt_Quot_Num.Text;
                    pms[2] = new MySqlParameter("qupdsta", MySqlDbType.VarChar);
                    pms[2].Value = txt_Update_Status.Text;
                    pms[3] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
                    pms[3].Value = txt_Rev_Sta.Text;
                    pms[4] = new MySqlParameter("qyear", MySqlDbType.VarChar);
                    pms[4].Value = txt_Year.Text;
                    pms[5] = new MySqlParameter("qsub", MySqlDbType.VarChar);
                    pms[5].Value = txt_Subject.Text;
                    pms[6] = new MySqlParameter("qleadt", MySqlDbType.VarChar);
                    pms[6].Value = txt_Lead_Time.Text;
                    pms[7] = new MySqlParameter("qpayt", MySqlDbType.VarChar);
                    pms[7].Value = txt_Pay_Term.Text;
                    pms[8] = new MySqlParameter("dateissue", MySqlDbType.Date);
                    pms[8].Value = txt_issued.Value;
                    pms[9] = new MySqlParameter("datevalid", MySqlDbType.Date);
                    pms[9].Value = txt_validity.Value;
                    pms[10] = new MySqlParameter("qtermsc", MySqlDbType.VarChar);
                    pms[10].Value = txt_T_Condition.Text;
                    pms[11] = new MySqlParameter("cid", MySqlDbType.Int32);
                    pms[11].Value = txt_c_id.Text;

                    pms[12] = new MySqlParameter("psize", MySqlDbType.VarChar);
                    pms[12].Value = Products_Table.Rows[i].Cells[1].Value.ToString();
                    pms[13] = new MySqlParameter("pdescrption", MySqlDbType.VarChar);
                    pms[13].Value = Products_Table.Rows[i].Cells[2].Value.ToString();
                    pms[14] = new MySqlParameter("punit", MySqlDbType.VarChar);
                    pms[14].Value = Products_Table.Rows[i].Cells[3].Value.ToString();
                    pms[15] = new MySqlParameter("pquantity", MySqlDbType.VarChar);
                    pms[15].Value = Products_Table.Rows[i].Cells[4].Value.ToString();
                    pms[16] = new MySqlParameter("punitprice", MySqlDbType.VarChar);
                    pms[16].Value = Products_Table.Rows[i].Cells[5].Value.ToString();


                    pms[17] = new MySqlParameter("pdiscount", MySqlDbType.VarChar);
                    pms[17].Value = Products_Table.Rows[i].Cells[6].Value.ToString();
                    pms[18] = new MySqlParameter("pdiscountedprice", MySqlDbType.VarChar);
                    pms[18].Value = Products_Table.Rows[i].Cells[7].Value.ToString();

                    pms[19] = new MySqlParameter("ptotal", MySqlDbType.VarChar);
                    pms[19].Value = Products_Table.Rows[i].Cells[8].Value.ToString();

                    

                   

                    pms[20] = new MySqlParameter("ptotalper", MySqlDbType.VarChar);
                    pms[20].Value = txt_disc.Text;
                    pms[21] = new MySqlParameter("ptotalperprice", MySqlDbType.VarChar);
                    pms[21].Value = txt_discount_price.Text;

                    pms[22] = new MySqlParameter("ppriceexcgst", MySqlDbType.VarChar);
                    pms[22].Value = txt_total_price.Text;
                    pms[23] = new MySqlParameter("pgstperc", MySqlDbType.VarChar);
                    pms[23].Value = txtGST.Text;
                    pms[24] = new MySqlParameter("pgstamount", MySqlDbType.VarChar);
                    pms[24].Value = txtGSTAmount.Text;
                    pms[25] = new MySqlParameter("ptotalpriceincgst", MySqlDbType.VarChar);
                    pms[25].Value = txtTotalPriceGST.Text;
                    pms[26] = new MySqlParameter("createdby", MySqlDbType.VarChar);
                    pms[26].Value = label12.Text;

                    pms[27] = new MySqlParameter("productorderno", MySqlDbType.VarChar);
                    pms[27].Value = txt_product_no.Text;
                    pms[28] = new MySqlParameter("note1", MySqlDbType.VarChar);
                    pms[28].Value = txt_note1.Text;
                    pms[29] = new MySqlParameter("note2", MySqlDbType.VarChar);
                    pms[29].Value = txt_note2.Text;


                    MySqlCommand cmd = new MySqlCommand();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "update_new_quotation";
                    cmd.Parameters.AddRange(pms);


                    con.Open();
                    cmd.ExecuteNonQuery();
                  
                    // cmd.Dispose();
                    con.Close();

                }
                MessageBox.Show("Quotation update Successfully !", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Dashboard_Main master = (Dashboard_Main)Application.OpenForms["Dashboard_Main"];
                master.btn_refresh.PerformClick();
            }

            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.ToString());
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            int val;

            if (int.TryParse(this.txt_Update_Status.Text, out val))

            {
                    this.txt_Update_Status.Text = (val + 1).ToString();           
            }

            else
            {
                
            }
            button7.Enabled = false;
            btn_save.Enabled = true;
          // indexing_correction();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            int val;

            if (int.TryParse(this.txt_Rev_Sta.Text, out val))

            {
                this.txt_Rev_Sta.Text = (val + 1).ToString();
            }

            else
            {

            }
            button8.Enabled = false;
            btn_save.Enabled = true;
            //indexing_correction();
        }

        private void Products_Table_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            calculate();
           

        }
        private void calculate()
        {
            try
            {
                foreach (DataGridViewRow row in Products_Table.Rows)
                {
               
                    double totalintextbox = 0;

                    for (int x = 0; x < Products_Table.Rows.Count - 1; x++)
                    {
                        if (Products_Table.Rows[x].Cells[6].Value == null)
                        {
                            Products_Table.Rows[x].Cells[6].Value = 0;
                        }
                        totalintextbox += Convert.ToDouble(Products_Table.Rows[x].Cells[8].Value);
                    }
                    double a;
                    double b;
                    a = Convert.ToDouble(row.Cells[Products_Table.Columns[5].Index].Value) - (Convert.ToDouble(row.Cells[Products_Table.Columns[5].Index].Value) * Convert.ToDouble(row.Cells[Products_Table.Columns[6].Index].Value) / 100);
                    row.Cells[Products_Table.Columns[7].Index].Value = a.ToString("N2");


                    b = Convert.ToDouble(row.Cells[Products_Table.Columns[4].Index].Value) * Convert.ToDouble(row.Cells[Products_Table.Columns[7].Index].Value);
                    row.Cells[Products_Table.Columns[8].Index].Value = b.ToString("N2");

                    txt_total_price.Text = totalintextbox.ToString("N2");
                    txt_discount_price.Text = totalintextbox.ToString("N2");
                }

              
            }
            catch (Exception exc)
            {
                // con.Close();
                MessageBox.Show(exc.ToString());
            }
        }
       
        private void Total_in_textpox()
        {
          
        }

        private void txtGST_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (Convert.ToInt32(txtGST.Text) > 0)
                {
                    Double A = Convert.ToDouble(txtGST.Text) / 100;
                    Double B = Convert.ToDouble(txt_total_price.Text);

                    

                    Double C = (A * B);
                    txtGSTAmount.Text = C.ToString("N2");
                    txtTotalPriceGST.Text = (B + C).ToString("N2");
                }
                else
                {
                    txtTotalPriceGST.Text = txt_total_price.Text;
                    txtGSTAmount.Text = "";

                }
            }
        }

        private void txt_desc_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DataTable dt = new DataTable();
                //OR p_type =  '" + txt_search_product.Text + "' OR p_size ='" + txt_search_product.Text + "'  OR p_type = '"+txt_search_products.Text+"'
                MySqlCommand cmd = new MySqlCommand("SELECT p_code,p_size,p_unit,p_unit_price FROM products WHERE p_description = '" + txt_desc.Text + "' ", con);
                // MySqlCommand cmd = new MySqlCommand("SELECT quotations.q_num,quotations.q_ref,quotations.q_upd_sta,quotations.q_rev_sta,quotations.q_sub,quotations.q_issued_at,quotations.q_valid_upto,customer.company_name,customer.contact_person,quotations.p_total_price_inc_gst FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id WHERE quotations.q_num = '" + txt_search_quote.Text + "' OR quotations.q_ref = '" + txt_search_quote.Text + "' OR customer.company_name = '" + txt_search_quote.Text + "' OR customer.contact_person = '" + txt_search_quote.Text + "' GROUP BY quotations.q_num", con);


                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_p_id.Text = dr.GetValue(0).ToString();
                    txtPsize.Text = dr.GetValue(1).ToString();
                    txtUnit.Text = dr.GetValue(2).ToString();
                    txtUnitPrice.Text = dr.GetValue(3).ToString();

                }
                dr.Close();
                con.Close();
            }
        }

        private void txt_desc_TextUpdate(object sender, EventArgs e)
        {
            this.txt_desc.Items.Clear();
            listNew.Clear();
            foreach (var item in listOnit)
            {
                if (item.Contains(txt_desc.Text))
                {
                    listNew.Add(item);
                }
            }
            this.txt_desc.Items.AddRange(listNew.ToArray());
            this.txt_desc.SelectionStart = this.txt_desc.Text.Length;
            Cursor = Cursors.Default;
            this.txt_desc.DroppedDown = true;
        }
        private void search_DESC()
        {
            string query = "SELECT p_description FROM products";
            MySqlCommand cmd = new MySqlCommand(query, con);
            //  SELECT quotations.q_num,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                collection.Add(reader.GetString(0));
                listOnit.Add(reader.GetString(0));
            }
            reader.Close();
            txt_desc.AutoCompleteCustomSource = collection;
            txt_desc.Items.AddRange(listOnit.ToArray());
            con.Close();
        }

        private void txtQuantity_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtQuantity.Text))
            {
                MessageBox.Show("Please insert Quantity ", "Error");
                this.ActiveControl = txtQuantity;
            }
        }

        private void txt_disc_price_Leave(object sender, EventArgs e)
        {
            int input1 = Convert.ToInt32(txtQuantity.Text);
            decimal input2 = Convert.ToDecimal(txt_disc_price.Text);


            decimal result = input1 * input2;

            txtTotal.Text = result.ToString("N2");
        }

        private void txtUnitPrice_Leave(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txtUnitPrice.Text))
            {
                MessageBox.Show("Please insert UnitPrice", "Error");
                this.ActiveControl = txtUnitPrice;
            }
        }

        private void txt_Discount_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_Discount.Text))
            {
                MessageBox.Show("Please discount% ", "Error");
                this.ActiveControl = txt_Discount;
            }
            else
            {
                Double A = Convert.ToDouble(txtUnitPrice.Text);
                Double B = Convert.ToDouble(txt_Discount.Text);



                Double C = A - (A * B / 100);
                txt_disc_price.Text = C.ToString("");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtQuantity.Text) || string.IsNullOrEmpty(txtTotal.Text))
            {
                MessageBox.Show("Please insert Quantity and Total ", "Error");
            }
            else
            {
                // DataTable dt = new DataTable();
                //var dataSource = Products_Table.DataSource as BindingSource;
                //var dataTable = dataSource.DataSource as DataTable;

                // dataTable.Rows.Add("", txtPsize.Text, txt_desc.Text, txtUnit.Text, txtQuantity.Text, txtUnitPrice.Text, txt_Discount.Text, txt_disc_price.Text, txtTotal.Text);
                Products_Table.DataSource = null;
                string[] row = { 0.ToString(), txtPsize.Text, txt_desc.Text, txtUnit.Text, txtQuantity.Text, txtUnitPrice.Text, txt_Discount.Text, txt_disc_price.Text, txtTotal.Text };
                
                dt.Rows.Add(row);

                Products_Table.DataSource = dt;


                Products_Table.Columns[0].HeaderText = "Sr";
                Products_Table.Columns[1].HeaderText = "Size";
                Products_Table.Columns[2].HeaderText = "Description";
                Products_Table.Columns[3].HeaderText = "Unit";
                Products_Table.Columns[4].HeaderText = "QTY";
                Products_Table.Columns[5].HeaderText = "UnitPrice";
                Products_Table.Columns[6].HeaderText = "Discount%";
                Products_Table.Columns[7].HeaderText = "Unit Price";
                Products_Table.Columns[8].HeaderText = "Total";


                Products_Table.Columns[0].Width = 50;
                Products_Table.Columns[1].Width = 50;
                Products_Table.Columns[2].Width = 300;
                Products_Table.Columns[3].Width = 100;
                Products_Table.Columns[4].Width = 100;
                Products_Table.Columns[5].Width = 100;
                Products_Table.Columns[6].Width = 100;
                Products_Table.Columns[7].Width = 100;
                Products_Table.Columns[8].Width = 200;

                for (int x = 0; x < Products_Table.Rows.Count - 1; x++)
                {
                    Products_Table.Rows[x].Cells[0].Value = (x + 1);
                    // x++;
                }
                // Products_Table.Rows.Add(row);
                Double sum = 0;
                for (int i = 0; i < Products_Table.Rows.Count; ++i)
                {
                    sum += Convert.ToDouble(Products_Table.Rows[i].Cells[8].Value);
                }
                txt_total_price.Text = sum.ToString("N2");
            }
            txt_p_id.Clear();
            txtPsize.Clear();
            txt_desc.DisplayMember = "";
            txtUnit.Clear();
            txtQuantity.Clear();
            txtUnitPrice.Clear();
            txtTotal.Clear();
            txt_Discount.Text = "0";
            txt_disc_price.Text = "0";
            //txt_unit_price.Clear();
            //bind_New_Quote_product();
            this.ActiveControl = txtPsize;


            Double a = Convert.ToDouble(txt_total_price.Text);
            Double b = Convert.ToDouble(txt_disc.Text);



            Double c = a - (a * b / 100);
            txt_discount_price.Text = c.ToString("N2");


            if (Convert.ToInt32(txtGST.Text) > 0)
            {
                Double A = Convert.ToDouble(txtGST.Text) / 100;
                Double B = Convert.ToDouble(txt_discount_price.Text);



                Double C = (A * B);
                txtGSTAmount.Text = C.ToString("N2");
                txtTotalPriceGST.Text = (B + C).ToString("N2");
            }
            else
            {
                txtTotalPriceGST.Text = txt_discount_price.Text;
                txtGSTAmount.Text = "";

            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var dash = new AddCustomers();
            dash.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var dash = new customer_list();
            dash.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            var dash = new AddProduct();
            dash.Show();
        }

        private void txt_disc_Leave(object sender, EventArgs e)
        {
            Double A = Convert.ToDouble(txt_total_price.Text);
            Double B = Convert.ToDouble(txt_disc.Text);



            Double C = A - (A * B / 100);
            txt_discount_price.Text = C.ToString("N2");

        }
        private void AddARow(DataTable Products_Table)
        {
            // Use the NewRow method to create a DataRow with 
            // the table's schema.
            DataRow newRow = Products_Table.NewRow();

            // Add the row to the rows collection.
            Products_Table.Rows.Add(newRow);
        }

        private void txt_discount_price_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(txtGST.Text) > 0)
            {
                Double A = Convert.ToDouble(txtGST.Text) / 100;
                Double B = Convert.ToDouble(txt_discount_price.Text);



                Double C = (A * B);
                txtGSTAmount.Text = C.ToString("N2");
                txtTotalPriceGST.Text = (B + C).ToString("N2");
            }
            else
            {
                txtTotalPriceGST.Text = txt_discount_price.Text;
                txtGSTAmount.Text = "";

            }
        }

        private void Products_Table_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            clone_product_table();
         
        }
        private void clone_product_table()
        {
            product_table_pdf.DataSource = null;
            product_table_pdf.Rows.Clear();
            product_table_pdf.Columns.Clear();
            product_table_pdf.Refresh();

            for (int i = 0; i <= Products_Table.Columns.Count - 1; i++)
            {
                if (Products_Table.Columns[i].Index == 0 || Products_Table.Columns[i].Index == 1 || Products_Table.Columns[i].Index == 2 || Products_Table.Columns[i].Index == 3 || Products_Table.Columns[i].Index == 4 || Products_Table.Columns[i].Index == 7 || Products_Table.Columns[i].Index == 8)
                {
                    product_table_pdf.Columns.Add(this.Products_Table.Columns[i].Clone() as DataGridViewColumn);
                }
            }
            product_table_pdf.RowCount = Products_Table.RowCount;

            foreach (DataGridViewRow row in Products_Table.Rows)
            {
                foreach (DataGridViewColumn col in Products_Table.Columns)
                {
                    if (col.Index == 0 || col.Index == 1 || col.Index == 2 || col.Index == 3 || col.Index == 4 || col.Index == 7 || col.Index == 8)
                    {
                        product_table_pdf.Rows[row.Index].Cells[col.Name].Value = row.Cells[col.Name].Value;
                    }
                }
            }
        }


        private void Products_Table_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            clone_product_table();
           indexing_correction();
        }
        private void indexing_correction()
        {
            int sno = 1;
            foreach (DataGridViewRow row in Products_Table.Rows)
            {
                row.Cells[0].Value = sno++;
            }

        }

        private void product_table_pdf_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txt_Comp_N_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Products_Table_CellEndEdit_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                app.Visible = true;
                Excel.Worksheet sh = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets["Sheet1"];
                //  worksheet = workbook.Sheets["Sheet1"];
                worksheet = (Excel._Worksheet)workbook.ActiveSheet;
                worksheet.Name = "Records";
                try
                {
                    for (int i = 0; i < Products_Table.Columns.Count; i++)
                    {
                        worksheet.Cells[1, i + 1] = Products_Table.Columns[i].HeaderText;
                    }
                    for (int i = 0; i < Products_Table.Rows.Count; i++)
                    {
                        for (int j = 0; j < Products_Table.Columns.Count; j++)
                        {
                            if (Products_Table.Rows[i].Cells[j].Value != null)
                            {
                                worksheet.Cells[i + 2, j + 1] = Products_Table.Rows[i].Cells[j].Value.ToString();
                            }
                            else
                            {
                                worksheet.Cells[i + 2, j + 1] = "";
                            }
                        }
                    }
                    worksheet.Columns.AutoFit();
                    worksheet.Rows.AutoFit();
                    //worksheet.Columns. Font.Bold = true;
                    worksheet.Columns.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    worksheet.Columns.VerticalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    worksheet.Cells.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    worksheet.Cells.VerticalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    //Getting the location and file name of the excel to save from user.
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                    saveDialog.FilterIndex = 1;
                    if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        workbook.SaveAs(saveDialog.FileName);
                        MessageBox.Show("Export Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    app.Quit();
                    workbook = null;
                    worksheet = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Products_Table_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            calculate();
        }
       

        private void Products_Table_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            //indexing_correction();
            //for (int i = 0; i < (Products_Table.Rows.Count - 1); i++)
            //{
            //    for (int j = 0; j < (Products_Table.Columns.Count); j++)
            //    {
            //        if (Products_Table.Rows[i].Cells[j].Value == System.DBNull.Value)
            //        {
            //            Products_Table.Rows[i].Cells[j].Value = "0";
            //        }
            //    }
            //}
        }

        private void Products_Table_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void Products_Table_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            

            for (int i = 0; i < (Products_Table.Rows.Count - 1); i++)
            {
                for (int j = 0; j < (Products_Table.Columns.Count); j++)
                {
                    if (Products_Table.Rows[i].Cells[j].Value == System.DBNull.Value)
                    {
                        Products_Table.Rows[i].Cells[j].Value = "0";
                    }
                }
            }

        }

        private void Products_Table_TabIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Products_Table_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
           // indexing_correction();
        }

        private void Products_Table_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            Double A = Convert.ToDouble(txt_total_price.Text);
            Double B = Convert.ToDouble(txt_recived.Text);



            Double C =A-B ;
            txt_remain.Text = C.ToString("N2");
        }

        private void txt_remain_Leave(object sender, EventArgs e)
        {
            Double A = Convert.ToDouble(txt_total_price.Text);
            Double B = Convert.ToDouble(txt_recived.Text);



            Double C = (B / A)*100;
            Double D = 100 - C;
            txt_percentage.Text = D.ToString("N2");
        }

        private void unit_txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                for (int x = 0; x < Products_Table.Rows.Count - 1; x++)
                {
                    Products_Table.Rows[x].Cells[3].Value = unit_txt.Text;
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
           
        }

        private void Products_Table_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            indexing_correction();
        }
    }

}
