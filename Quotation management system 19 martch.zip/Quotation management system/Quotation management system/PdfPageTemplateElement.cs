﻿namespace Quotation_management_system
{
    internal class PdfPageTemplateElement
    {
    }
}