﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
namespace Quotation_management_system
{
    public partial class AddProduct : Form
    {
        private MySqlConnection con;
        public AddProduct()
        {
            InitializeComponent();
           con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
          // con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void AddProduct_Load(object sender, EventArgs e)
        {
            bind_New_Quote_product();
        }
        private void bind_New_Quote_product()
        {
            using (MySqlCommand cmd = new MySqlCommand("CALL `max_product_code`() ", con))
            {
                cmd.CommandType = CommandType.Text;
                con.Open();
                txt_pro_code.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //'" + txt_pro_code.Text + "','" + txt_pro_type.Text + "','" + txt_size.Text + "','" + txt_model.Text + "','" + txt_desc.Text + "','" + txt_make_origin.Text + "','" + txt_unit.Text + "','" + txt_unit_price.Text + "'
            try
            {
                //INSERT INTO products (p_code,p_type,p_size,p_model,p_desc,p_make_origin,p_unit,p_unit_price) VALUES (pcode,ptype,psize,pmodel,pdesc,pmakeorigin,punit,punitprice)
                //  string query = "INSERT INTO products (p_code,p_type,p_size,p_model,p_desc,p_make_origin,p_unit,p_unit_price) VALUES ()";

                MySqlParameter[] pms = new MySqlParameter[4];
                pms[0] = new MySqlParameter("pcode", MySqlDbType.VarChar);
                pms[0].Value = txt_pro_code.Text;
              
                pms[1] = new MySqlParameter("psize", MySqlDbType.VarChar);
                pms[1].Value = txt_size.Text;
              
                pms[2] = new MySqlParameter("pdesc", MySqlDbType.VarChar);
                pms[2].Value = txt_desc.Text;
              
                pms[3] = new MySqlParameter("punit", MySqlDbType.VarChar); 
                pms[3].Value = txt_unit.Text;
              

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "add_product";
                cmd.Parameters.AddRange(pms);


                
                con.Open();
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();



                MessageBox.Show("New product is successfully saved in database", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txt_pro_code.Clear();
             //   txt_pro_type.Clear();
                txt_size.Clear();
              //  txt_model.Clear();
                txt_desc.Clear();
               // txt_make_origin.Clear();
                txt_unit.Clear();
                //txt_unit_price.Clear();
                bind_New_Quote_product();

                //New_Quote master = (New_Quote)Application.OpenForms["New_Quote"];
                //master.product_name_search();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_pro_code_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
