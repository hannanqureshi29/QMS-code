﻿
namespace Quotation_management_system
{
    partial class Quotation_list
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Quotation_list_table = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_time = new System.Windows.Forms.Label();
            this.lbl_quotation_list = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnaddproduct = new System.Windows.Forms.Button();
            this.txt_search_quot = new System.Windows.Forms.TextBox();
            this.combo_quot_list = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.Quotation_list_table)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Quotation_list_table
            // 
            this.Quotation_list_table.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Quotation_list_table.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Quotation_list_table.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Quotation_list_table.ColumnHeadersHeight = 55;
            this.Quotation_list_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Quotation_list_table.DefaultCellStyle = dataGridViewCellStyle2;
            this.Quotation_list_table.Location = new System.Drawing.Point(0, 201);
            this.Quotation_list_table.Name = "Quotation_list_table";
            this.Quotation_list_table.Size = new System.Drawing.Size(1421, 639);
            this.Quotation_list_table.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.lbl_date);
            this.panel1.Controls.Add(this.lbl_time);
            this.panel1.Controls.Add(this.lbl_quotation_list);
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1584, 50);
            this.panel1.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 15.75F);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(1259, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(152, 24);
            this.label12.TabIndex = 42;
            this.label12.Text = "user_logged_in";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 15.75F);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(1202, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 24);
            this.label13.TabIndex = 41;
            this.label13.Text = "User:";
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.ForeColor = System.Drawing.Color.White;
            this.lbl_date.Location = new System.Drawing.Point(12, 11);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(63, 29);
            this.lbl_date.TabIndex = 24;
            this.lbl_date.Text = "Date";
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lbl_time.ForeColor = System.Drawing.Color.White;
            this.lbl_time.Location = new System.Drawing.Point(179, 11);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(69, 29);
            this.lbl_time.TabIndex = 25;
            this.lbl_time.Text = "Time";
            // 
            // lbl_quotation_list
            // 
            this.lbl_quotation_list.AutoSize = true;
            this.lbl_quotation_list.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lbl_quotation_list.ForeColor = System.Drawing.Color.White;
            this.lbl_quotation_list.Location = new System.Drawing.Point(719, 11);
            this.lbl_quotation_list.Name = "lbl_quotation_list";
            this.lbl_quotation_list.Size = new System.Drawing.Size(146, 26);
            this.lbl_quotation_list.TabIndex = 23;
            this.lbl_quotation_list.Text = "Quotation List";
            this.lbl_quotation_list.Click += new System.EventHandler(this.lblproductlist_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnaddproduct
            // 
            this.btnaddproduct.BackColor = System.Drawing.Color.DarkCyan;
            this.btnaddproduct.FlatAppearance.BorderSize = 0;
            this.btnaddproduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnaddproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.btnaddproduct.ForeColor = System.Drawing.Color.White;
            this.btnaddproduct.Location = new System.Drawing.Point(1076, 103);
            this.btnaddproduct.Name = "btnaddproduct";
            this.btnaddproduct.Size = new System.Drawing.Size(336, 67);
            this.btnaddproduct.TabIndex = 19;
            this.btnaddproduct.Text = "Add New Quotation";
            this.btnaddproduct.UseVisualStyleBackColor = false;
            this.btnaddproduct.Click += new System.EventHandler(this.btnaddproduct_Click);
            // 
            // txt_search_quot
            // 
            this.txt_search_quot.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_search_quot.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_search_quot.BackColor = System.Drawing.Color.White;
            this.txt_search_quot.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search_quot.ForeColor = System.Drawing.Color.Black;
            this.txt_search_quot.Location = new System.Drawing.Point(16, 125);
            this.txt_search_quot.MaxLength = 15;
            this.txt_search_quot.Name = "txt_search_quot";
            this.txt_search_quot.Size = new System.Drawing.Size(447, 26);
            this.txt_search_quot.TabIndex = 20;
            this.txt_search_quot.Text = "Search Quotation";
            this.txt_search_quot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_search_quot.Visible = false;
            this.txt_search_quot.TextChanged += new System.EventHandler(this.txt_search_quote_TextChanged);
            this.txt_search_quot.Enter += new System.EventHandler(this.txt_search_quot_Enter);
            this.txt_search_quot.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_search_quote_KeyDown);
            this.txt_search_quot.Leave += new System.EventHandler(this.txt_search_quote_Leave);
            // 
            // combo_quot_list
            // 
            this.combo_quot_list.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_quot_list.FormattingEnabled = true;
            this.combo_quot_list.Location = new System.Drawing.Point(937, 176);
            this.combo_quot_list.Name = "combo_quot_list";
            this.combo_quot_list.Size = new System.Drawing.Size(474, 21);
            this.combo_quot_list.TabIndex = 59;
            this.combo_quot_list.Text = "Search Quotation";
            this.combo_quot_list.TextUpdate += new System.EventHandler(this.combo_quot_list_TextUpdate);
            this.combo_quot_list.KeyDown += new System.Windows.Forms.KeyEventHandler(this.combo_search_KeyDown);
            this.combo_quot_list.Leave += new System.EventHandler(this.combo_search_Leave);
            // 
            // Quotation_list
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1424, 841);
            this.Controls.Add(this.combo_quot_list);
            this.Controls.Add(this.txt_search_quot);
            this.Controls.Add(this.btnaddproduct);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Quotation_list_table);
            this.Name = "Quotation_list";
            this.Text = "Quotation_list";
            this.Load += new System.EventHandler(this.Quotation_list_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Quotation_list_table)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Quotation_list_table;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.Label lbl_quotation_list;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnaddproduct;
        private System.Windows.Forms.TextBox txt_search_quot;
        public System.Windows.Forms.ComboBox combo_quot_list;
        public System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}