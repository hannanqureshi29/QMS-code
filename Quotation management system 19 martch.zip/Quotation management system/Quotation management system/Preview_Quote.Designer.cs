﻿
namespace Quotation_management_system
{
    partial class Preview_Quote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_time = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.txtGSTAmount = new System.Windows.Forms.TextBox();
            this.txt_p_id = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_discount_price = new System.Windows.Forms.Label();
            this.lbl_discount = new System.Windows.Forms.Label();
            this.txt_Discount = new System.Windows.Forms.TextBox();
            this.txt_disc_price = new System.Windows.Forms.TextBox();
            this.txt_desc = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lbl_Quantity = new System.Windows.Forms.Label();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.lbl_Unit_Price = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtUnit = new System.Windows.Forms.TextBox();
            this.lbl_Unit = new System.Windows.Forms.Label();
            this.txtPsize = new System.Windows.Forms.TextBox();
            this.lbl_Size = new System.Windows.Forms.Label();
            this.lbl_Desc = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtTotalPriceGST = new System.Windows.Forms.TextBox();
            this.txtGST = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.txt_Comp_N = new System.Windows.Forms.TextBox();
            this.lbl_Comp_N = new System.Windows.Forms.Label();
            this.txt_Cont_Per = new System.Windows.Forms.TextBox();
            this.txt_total_price = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.unit_txt = new System.Windows.Forms.TextBox();
            this.txt_note2 = new System.Windows.Forms.TextBox();
            this.txt_note1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.product_table_pdf = new System.Windows.Forms.DataGridView();
            this.Products_Table = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_percentage = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_remain = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_recived = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_disc = new System.Windows.Forms.TextBox();
            this.txt_discount_price = new System.Windows.Forms.TextBox();
            this.btn_print = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.panlel_grid_3 = new System.Windows.Forms.Panel();
            this.txt_product_no = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_created = new System.Windows.Forms.Label();
            this.combo_approved = new System.Windows.Forms.ComboBox();
            this.lbl_approved_by = new System.Windows.Forms.Label();
            this.lbl_created_by = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.btn_order_rec = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_c_id = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.txt_Fax = new System.Windows.Forms.TextBox();
            this.lbl_Fax = new System.Windows.Forms.Label();
            this.txt_Tele = new System.Windows.Forms.TextBox();
            this.lbl_Tele = new System.Windows.Forms.Label();
            this.txt_Desig = new System.Windows.Forms.TextBox();
            this.lbl_Desig = new System.Windows.Forms.Label();
            this.txt_Cell = new System.Windows.Forms.TextBox();
            this.lbl_Cell = new System.Windows.Forms.Label();
            this.lbl_Cont_Per = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.txt_issued = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_validity = new System.Windows.Forms.DateTimePicker();
            this.txt_T_Condition = new System.Windows.Forms.TextBox();
            this.lbl_T_Condititon = new System.Windows.Forms.Label();
            this.txt_Pay_Term = new System.Windows.Forms.TextBox();
            this.lbl_Pay_Term = new System.Windows.Forms.Label();
            this.lbl_Val_upto = new System.Windows.Forms.Label();
            this.txt_Lead_Time = new System.Windows.Forms.TextBox();
            this.lbl_Lead_Time = new System.Windows.Forms.Label();
            this.txt_Subject = new System.Windows.Forms.TextBox();
            this.lbl_Subject = new System.Windows.Forms.Label();
            this.txt_Year = new System.Windows.Forms.TextBox();
            this.lbl_Year = new System.Windows.Forms.Label();
            this.txt_Update_Status = new System.Windows.Forms.TextBox();
            this.lbl_Update_Status = new System.Windows.Forms.Label();
            this.txt_Rev_Sta = new System.Windows.Forms.TextBox();
            this.lbl_Rev_Sta = new System.Windows.Forms.Label();
            this.txt_Quot_Num = new System.Windows.Forms.TextBox();
            this.lbl_Quot_Num = new System.Windows.Forms.Label();
            this.txt_Ref = new System.Windows.Forms.TextBox();
            this.lbl_Ref = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.product_table_pdf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Products_Table)).BeginInit();
            this.panel4.SuspendLayout();
            this.panlel_grid_3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.ForeColor = System.Drawing.Color.White;
            this.lbl_date.Location = new System.Drawing.Point(12, 13);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(63, 29);
            this.lbl_date.TabIndex = 9;
            this.lbl_date.Text = "Date";
            this.lbl_date.Click += new System.EventHandler(this.lbl_date_Click);
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lbl_time.ForeColor = System.Drawing.Color.White;
            this.lbl_time.Location = new System.Drawing.Point(173, 13);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(69, 29);
            this.lbl_time.TabIndex = 10;
            this.lbl_time.Text = "Time";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(11, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 16);
            this.label2.TabIndex = 32;
            this.label2.Text = "Total Price Exclusive GST";
            // 
            // txtGSTAmount
            // 
            this.txtGSTAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGSTAmount.Location = new System.Drawing.Point(16, 343);
            this.txtGSTAmount.Name = "txtGSTAmount";
            this.txtGSTAmount.Size = new System.Drawing.Size(186, 22);
            this.txtGSTAmount.TabIndex = 36;
            // 
            // txt_p_id
            // 
            this.txt_p_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_p_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_p_id.Location = new System.Drawing.Point(5, 54);
            this.txt_p_id.Name = "txt_p_id";
            this.txt_p_id.Size = new System.Drawing.Size(37, 26);
            this.txt_p_id.TabIndex = 1006;
            // 
            // groupBox3
            // 
            this.groupBox3.AutoSize = true;
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.lbl_discount_price);
            this.groupBox3.Controls.Add(this.lbl_discount);
            this.groupBox3.Controls.Add(this.txt_Discount);
            this.groupBox3.Controls.Add(this.txt_disc_price);
            this.groupBox3.Controls.Add(this.txt_desc);
            this.groupBox3.Controls.Add(this.txt_p_id);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txtTotal);
            this.groupBox3.Controls.Add(this.txtQuantity);
            this.groupBox3.Controls.Add(this.lbl_Quantity);
            this.groupBox3.Controls.Add(this.txtUnitPrice);
            this.groupBox3.Controls.Add(this.lbl_Unit_Price);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.txtUnit);
            this.groupBox3.Controls.Add(this.lbl_Unit);
            this.groupBox3.Controls.Add(this.txtPsize);
            this.groupBox3.Controls.Add(this.lbl_Size);
            this.groupBox3.Controls.Add(this.lbl_Desc);
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Location = new System.Drawing.Point(0, 192);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox3.Size = new System.Drawing.Size(1415, 104);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Add Products";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(887, 57);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 20);
            this.label11.TabIndex = 1019;
            this.label11.Text = "%";
            // 
            // lbl_discount_price
            // 
            this.lbl_discount_price.AutoSize = true;
            this.lbl_discount_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_discount_price.ForeColor = System.Drawing.Color.Black;
            this.lbl_discount_price.Location = new System.Drawing.Point(909, 30);
            this.lbl_discount_price.Name = "lbl_discount_price";
            this.lbl_discount_price.Size = new System.Drawing.Size(110, 16);
            this.lbl_discount_price.TabIndex = 1018;
            this.lbl_discount_price.Text = "Discounted Price";
            // 
            // lbl_discount
            // 
            this.lbl_discount.AutoSize = true;
            this.lbl_discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_discount.ForeColor = System.Drawing.Color.Black;
            this.lbl_discount.Location = new System.Drawing.Point(802, 31);
            this.lbl_discount.Name = "lbl_discount";
            this.lbl_discount.Size = new System.Drawing.Size(60, 16);
            this.lbl_discount.TabIndex = 1017;
            this.lbl_discount.Text = "Discount";
            // 
            // txt_Discount
            // 
            this.txt_Discount.Location = new System.Drawing.Point(805, 54);
            this.txt_Discount.Name = "txt_Discount";
            this.txt_Discount.Size = new System.Drawing.Size(79, 26);
            this.txt_Discount.TabIndex = 27;
            this.txt_Discount.Text = "0";
            this.txt_Discount.Leave += new System.EventHandler(this.txt_Discount_Leave);
            // 
            // txt_disc_price
            // 
            this.txt_disc_price.Location = new System.Drawing.Point(911, 54);
            this.txt_disc_price.Name = "txt_disc_price";
            this.txt_disc_price.Size = new System.Drawing.Size(126, 26);
            this.txt_disc_price.TabIndex = 28;
            this.txt_disc_price.Text = "0";
            this.txt_disc_price.Leave += new System.EventHandler(this.txt_disc_price_Leave);
            // 
            // txt_desc
            // 
            this.txt_desc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_desc.FormattingEnabled = true;
            this.txt_desc.Location = new System.Drawing.Point(97, 55);
            this.txt_desc.MaxDropDownItems = 10;
            this.txt_desc.Name = "txt_desc";
            this.txt_desc.Size = new System.Drawing.Size(416, 24);
            this.txt_desc.TabIndex = 23;
            this.txt_desc.TextUpdate += new System.EventHandler(this.txt_desc_TextUpdate);
            this.txt_desc.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_desc_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(5, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(21, 16);
            this.label7.TabIndex = 1005;
            this.label7.Text = "ID";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(666, 57);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(20, 20);
            this.label16.TabIndex = 1002;
            this.label16.Text = "X";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(1040, 54);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(141, 26);
            this.txtTotal.TabIndex = 1023252;
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(592, 54);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(71, 26);
            this.txtQuantity.TabIndex = 25;
            this.txtQuantity.Leave += new System.EventHandler(this.txtQuantity_Leave);
            // 
            // lbl_Quantity
            // 
            this.lbl_Quantity.AutoSize = true;
            this.lbl_Quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quantity.ForeColor = System.Drawing.Color.Black;
            this.lbl_Quantity.Location = new System.Drawing.Point(589, 31);
            this.lbl_Quantity.Name = "lbl_Quantity";
            this.lbl_Quantity.Size = new System.Drawing.Size(56, 16);
            this.lbl_Quantity.TabIndex = 21;
            this.lbl_Quantity.Text = "Quantity";
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtUnitPrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtUnitPrice.Location = new System.Drawing.Point(687, 54);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(114, 26);
            this.txtUnitPrice.TabIndex = 26;
            this.txtUnitPrice.Leave += new System.EventHandler(this.txtUnitPrice_Leave);
            // 
            // lbl_Unit_Price
            // 
            this.lbl_Unit_Price.AutoSize = true;
            this.lbl_Unit_Price.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Unit_Price.ForeColor = System.Drawing.Color.Black;
            this.lbl_Unit_Price.Location = new System.Drawing.Point(684, 32);
            this.lbl_Unit_Price.Name = "lbl_Unit_Price";
            this.lbl_Unit_Price.Size = new System.Drawing.Size(65, 16);
            this.lbl_Unit_Price.TabIndex = 19;
            this.lbl_Unit_Price.Text = "Unit Price";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(1037, 30);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(88, 16);
            this.label23.TabIndex = 24;
            this.label23.Text = "Product Total";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkCyan;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(1282, 32);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 49);
            this.button2.TabIndex = 30;
            this.button2.Text = "Add New Product";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkCyan;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(1185, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 49);
            this.button1.TabIndex = 29;
            this.button1.Text = "Add Below";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtUnit
            // 
            this.txtUnit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtUnit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtUnit.Location = new System.Drawing.Point(515, 54);
            this.txtUnit.Name = "txtUnit";
            this.txtUnit.Size = new System.Drawing.Size(72, 26);
            this.txtUnit.TabIndex = 24;
            // 
            // lbl_Unit
            // 
            this.lbl_Unit.AutoSize = true;
            this.lbl_Unit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Unit.ForeColor = System.Drawing.Color.Black;
            this.lbl_Unit.Location = new System.Drawing.Point(513, 32);
            this.lbl_Unit.Name = "lbl_Unit";
            this.lbl_Unit.Size = new System.Drawing.Size(31, 16);
            this.lbl_Unit.TabIndex = 17;
            this.lbl_Unit.Text = "Unit";
            // 
            // txtPsize
            // 
            this.txtPsize.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtPsize.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPsize.Location = new System.Drawing.Point(46, 54);
            this.txtPsize.Name = "txtPsize";
            this.txtPsize.Size = new System.Drawing.Size(48, 26);
            this.txtPsize.TabIndex = 22;
            // 
            // lbl_Size
            // 
            this.lbl_Size.AutoSize = true;
            this.lbl_Size.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Size.ForeColor = System.Drawing.Color.Black;
            this.lbl_Size.Location = new System.Drawing.Point(45, 31);
            this.lbl_Size.Name = "lbl_Size";
            this.lbl_Size.Size = new System.Drawing.Size(34, 16);
            this.lbl_Size.TabIndex = 7;
            this.lbl_Size.Text = "Size";
            // 
            // lbl_Desc
            // 
            this.lbl_Desc.AutoSize = true;
            this.lbl_Desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Desc.ForeColor = System.Drawing.Color.Black;
            this.lbl_Desc.Location = new System.Drawing.Point(96, 31);
            this.lbl_Desc.Name = "lbl_Desc";
            this.lbl_Desc.Size = new System.Drawing.Size(76, 16);
            this.lbl_Desc.TabIndex = 5;
            this.lbl_Desc.Text = "Description";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(15, 366);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(127, 16);
            this.label25.TabIndex = 28;
            this.label25.Text = "Total Price Incl GST";
            // 
            // txtTotalPriceGST
            // 
            this.txtTotalPriceGST.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalPriceGST.Location = new System.Drawing.Point(16, 385);
            this.txtTotalPriceGST.Name = "txtTotalPriceGST";
            this.txtTotalPriceGST.Size = new System.Drawing.Size(186, 22);
            this.txtTotalPriceGST.TabIndex = 37;
            // 
            // txtGST
            // 
            this.txtGST.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGST.Location = new System.Drawing.Point(16, 298);
            this.txtGST.Name = "txtGST";
            this.txtGST.Size = new System.Drawing.Size(186, 22);
            this.txtGST.TabIndex = 35;
            this.txtGST.Text = "17";
            this.txtGST.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtGST_KeyDown);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(13, 279);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(51, 16);
            this.label24.TabIndex = 26;
            this.label24.Text = "GST %";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(15, 324);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(84, 16);
            this.label35.TabIndex = 30;
            this.label35.Text = "GST Amount";
            // 
            // txt_Comp_N
            // 
            this.txt_Comp_N.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Comp_N.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Comp_N.Location = new System.Drawing.Point(46, 53);
            this.txt_Comp_N.Name = "txt_Comp_N";
            this.txt_Comp_N.Size = new System.Drawing.Size(126, 22);
            this.txt_Comp_N.TabIndex = 12;
            this.txt_Comp_N.TextChanged += new System.EventHandler(this.txt_Comp_N_TextChanged);
            // 
            // lbl_Comp_N
            // 
            this.lbl_Comp_N.AutoSize = true;
            this.lbl_Comp_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Comp_N.ForeColor = System.Drawing.Color.Black;
            this.lbl_Comp_N.Location = new System.Drawing.Point(42, 30);
            this.lbl_Comp_N.Name = "lbl_Comp_N";
            this.lbl_Comp_N.Size = new System.Drawing.Size(106, 16);
            this.lbl_Comp_N.TabIndex = 0;
            this.lbl_Comp_N.Text = "Company Name";
            // 
            // txt_Cont_Per
            // 
            this.txt_Cont_Per.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Cont_Per.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Cont_Per.Location = new System.Drawing.Point(175, 53);
            this.txt_Cont_Per.Name = "txt_Cont_Per";
            this.txt_Cont_Per.Size = new System.Drawing.Size(141, 22);
            this.txt_Cont_Per.TabIndex = 13;
            // 
            // txt_total_price
            // 
            this.txt_total_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total_price.Location = new System.Drawing.Point(14, 22);
            this.txt_total_price.Name = "txt_total_price";
            this.txt_total_price.Size = new System.Drawing.Size(186, 22);
            this.txt_total_price.TabIndex = 32;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.unit_txt);
            this.panel3.Controls.Add(this.txt_note2);
            this.panel3.Controls.Add(this.txt_note1);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.button9);
            this.panel3.Controls.Add(this.product_table_pdf);
            this.panel3.Controls.Add(this.Products_Table);
            this.panel3.Location = new System.Drawing.Point(0, 329);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1192, 420);
            this.panel3.TabIndex = 35;
            // 
            // unit_txt
            // 
            this.unit_txt.Location = new System.Drawing.Point(462, 5);
            this.unit_txt.Name = "unit_txt";
            this.unit_txt.Size = new System.Drawing.Size(71, 26);
            this.unit_txt.TabIndex = 1023253;
            this.unit_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.unit_txt_KeyDown);
            // 
            // txt_note2
            // 
            this.txt_note2.BackColor = System.Drawing.Color.White;
            this.txt_note2.Location = new System.Drawing.Point(69, 387);
            this.txt_note2.Name = "txt_note2";
            this.txt_note2.Size = new System.Drawing.Size(919, 26);
            this.txt_note2.TabIndex = 50;
            // 
            // txt_note1
            // 
            this.txt_note1.BackColor = System.Drawing.Color.White;
            this.txt_note1.Location = new System.Drawing.Point(69, 353);
            this.txt_note1.Name = "txt_note1";
            this.txt_note1.Size = new System.Drawing.Size(919, 26);
            this.txt_note1.TabIndex = 49;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(5, 390);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 20);
            this.label14.TabIndex = 48;
            this.label14.Text = "Note :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(5, 358);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 20);
            this.label3.TabIndex = 47;
            this.label3.Text = "Note :";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.DarkCyan;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(1059, 375);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(130, 41);
            this.button9.TabIndex = 46;
            this.button9.Text = "Export To Excel";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // product_table_pdf
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.product_table_pdf.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.product_table_pdf.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.product_table_pdf.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.product_table_pdf.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.product_table_pdf.ColumnHeadersHeight = 50;
            this.product_table_pdf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.product_table_pdf.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.product_table_pdf.Location = new System.Drawing.Point(23, 124);
            this.product_table_pdf.Name = "product_table_pdf";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.product_table_pdf.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.product_table_pdf.Size = new System.Drawing.Size(965, 185);
            this.product_table_pdf.TabIndex = 13;
            this.product_table_pdf.Visible = false;
            this.product_table_pdf.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.product_table_pdf_CellContentClick);
            // 
            // Products_Table
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.Products_Table.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.Products_Table.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Products_Table.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Products_Table.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.Products_Table.ColumnHeadersHeight = 50;
            this.Products_Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.Products_Table.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Products_Table.Location = new System.Drawing.Point(0, 34);
            this.Products_Table.Name = "Products_Table";
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.Products_Table.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.Products_Table.Size = new System.Drawing.Size(1192, 309);
            this.Products_Table.TabIndex = 31;
            this.Products_Table.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellClick);
            this.Products_Table.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellContentClick);
            this.Products_Table.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellEndEdit);
            this.Products_Table.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellEnter);
            this.Products_Table.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellLeave);
            this.Products_Table.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Products_Table_CellMouseClick);
            this.Products_Table.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_Table_CellValueChanged);
            this.Products_Table.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.Products_Table_RowsAdded);
            this.Products_Table.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.Products_Table_RowsRemoved);
            this.Products_Table.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.Products_Table_UserAddedRow);
            this.Products_Table.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.Products_Table_UserDeletedRow);
            this.Products_Table.TabIndexChanged += new System.EventHandler(this.Products_Table_TabIndexChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.txt_percentage);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.txt_remain);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.txt_recived);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.txt_disc);
            this.panel4.Controls.Add(this.txt_discount_price);
            this.panel4.Controls.Add(this.btn_print);
            this.panel4.Controls.Add(this.button6);
            this.panel4.Controls.Add(this.btn_save);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.txtGSTAmount);
            this.panel4.Controls.Add(this.txtTotalPriceGST);
            this.panel4.Controls.Add(this.txt_total_price);
            this.panel4.Controls.Add(this.txtGST);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.label35);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(1192, 332);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(229, 508);
            this.panel4.TabIndex = 12;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(15, 135);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 16);
            this.label18.TabIndex = 1024;
            this.label18.Text = "Per%";
            // 
            // txt_percentage
            // 
            this.txt_percentage.Location = new System.Drawing.Point(15, 154);
            this.txt_percentage.Name = "txt_percentage";
            this.txt_percentage.Size = new System.Drawing.Size(184, 22);
            this.txt_percentage.TabIndex = 1023;
            this.txt_percentage.Text = "%";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(11, 91);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 16);
            this.label17.TabIndex = 1022;
            this.label17.Text = "Remain";
            // 
            // txt_remain
            // 
            this.txt_remain.Location = new System.Drawing.Point(15, 110);
            this.txt_remain.Name = "txt_remain";
            this.txt_remain.Size = new System.Drawing.Size(184, 22);
            this.txt_remain.TabIndex = 1021;
            this.txt_remain.Leave += new System.EventHandler(this.txt_remain_Leave);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(11, 47);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 16);
            this.label15.TabIndex = 1020;
            this.label15.Text = " Amount";
            // 
            // txt_recived
            // 
            this.txt_recived.Location = new System.Drawing.Point(14, 66);
            this.txt_recived.Name = "txt_recived";
            this.txt_recived.Size = new System.Drawing.Size(185, 22);
            this.txt_recived.TabIndex = 1019;
            this.txt_recived.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(11, 232);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 16);
            this.label10.TabIndex = 1018;
            this.label10.Text = "Total Discount Price";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(11, 187);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 16);
            this.label9.TabIndex = 1017;
            this.label9.Text = "Total Discount %";
            // 
            // txt_disc
            // 
            this.txt_disc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_disc.Location = new System.Drawing.Point(15, 208);
            this.txt_disc.Name = "txt_disc";
            this.txt_disc.Size = new System.Drawing.Size(184, 22);
            this.txt_disc.TabIndex = 33;
            this.txt_disc.Text = "0";
            this.txt_disc.Leave += new System.EventHandler(this.txt_disc_Leave);
            // 
            // txt_discount_price
            // 
            this.txt_discount_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_discount_price.Location = new System.Drawing.Point(15, 253);
            this.txt_discount_price.Name = "txt_discount_price";
            this.txt_discount_price.Size = new System.Drawing.Size(184, 22);
            this.txt_discount_price.TabIndex = 34;
            this.txt_discount_price.Text = "0";
            this.txt_discount_price.TextChanged += new System.EventHandler(this.txt_discount_price_TextChanged);
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_print.FlatAppearance.BorderSize = 0;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(17, 442);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(186, 28);
            this.btn_print.TabIndex = 39;
            this.btn_print.Text = "PDF";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightCoral;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(17, 473);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(186, 29);
            this.button6.TabIndex = 40;
            this.button6.Text = "Close";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_save.Enabled = false;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(16, 412);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(186, 27);
            this.btn_save.TabIndex = 38;
            this.btn_save.Text = "Update";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // panlel_grid_3
            // 
            this.panlel_grid_3.Controls.Add(this.txt_product_no);
            this.panlel_grid_3.Controls.Add(this.label4);
            this.panlel_grid_3.Controls.Add(this.lbl_created);
            this.panlel_grid_3.Controls.Add(this.combo_approved);
            this.panlel_grid_3.Controls.Add(this.lbl_approved_by);
            this.panlel_grid_3.Controls.Add(this.lbl_created_by);
            this.panlel_grid_3.Controls.Add(this.button5);
            this.panlel_grid_3.Controls.Add(this.btn_order_rec);
            this.panlel_grid_3.Location = new System.Drawing.Point(0, 750);
            this.panlel_grid_3.Name = "panlel_grid_3";
            this.panlel_grid_3.Size = new System.Drawing.Size(1192, 85);
            this.panlel_grid_3.TabIndex = 37;
            this.panlel_grid_3.Paint += new System.Windows.Forms.PaintEventHandler(this.panlel_grid_3_Paint);
            // 
            // txt_product_no
            // 
            this.txt_product_no.Location = new System.Drawing.Point(170, 42);
            this.txt_product_no.Name = "txt_product_no";
            this.txt_product_no.Size = new System.Drawing.Size(100, 26);
            this.txt_product_no.TabIndex = 45;
            this.txt_product_no.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(6, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 20);
            this.label4.TabIndex = 44;
            this.label4.Text = "Product Order No";
            // 
            // lbl_created
            // 
            this.lbl_created.AutoSize = true;
            this.lbl_created.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_created.ForeColor = System.Drawing.Color.Black;
            this.lbl_created.Location = new System.Drawing.Point(173, 15);
            this.lbl_created.Name = "lbl_created";
            this.lbl_created.Size = new System.Drawing.Size(84, 20);
            this.lbl_created.TabIndex = 5;
            this.lbl_created.Text = "CreatedBy";
            // 
            // combo_approved
            // 
            this.combo_approved.FormattingEnabled = true;
            this.combo_approved.Location = new System.Drawing.Point(1055, 40);
            this.combo_approved.Name = "combo_approved";
            this.combo_approved.Size = new System.Drawing.Size(121, 28);
            this.combo_approved.TabIndex = 43;
            // 
            // lbl_approved_by
            // 
            this.lbl_approved_by.AutoSize = true;
            this.lbl_approved_by.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_approved_by.ForeColor = System.Drawing.Color.Black;
            this.lbl_approved_by.Location = new System.Drawing.Point(932, 43);
            this.lbl_approved_by.Name = "lbl_approved_by";
            this.lbl_approved_by.Size = new System.Drawing.Size(95, 20);
            this.lbl_approved_by.TabIndex = 1;
            this.lbl_approved_by.Text = "ApprovedBy";
            // 
            // lbl_created_by
            // 
            this.lbl_created_by.AutoSize = true;
            this.lbl_created_by.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_created_by.ForeColor = System.Drawing.Color.Black;
            this.lbl_created_by.Location = new System.Drawing.Point(8, 15);
            this.lbl_created_by.Name = "lbl_created_by";
            this.lbl_created_by.Size = new System.Drawing.Size(84, 20);
            this.lbl_created_by.TabIndex = 0;
            this.lbl_created_by.Text = "CreatedBy";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkCyan;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(424, 42);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(162, 31);
            this.button5.TabIndex = 41;
            this.button5.Text = "Approve Quotation";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.TabIndexChanged += new System.EventHandler(this.button5_TabIndexChanged);
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_order_rec
            // 
            this.btn_order_rec.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_order_rec.FlatAppearance.BorderSize = 0;
            this.btn_order_rec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_order_rec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_order_rec.ForeColor = System.Drawing.Color.White;
            this.btn_order_rec.Location = new System.Drawing.Point(607, 41);
            this.btn_order_rec.Name = "btn_order_rec";
            this.btn_order_rec.Size = new System.Drawing.Size(162, 31);
            this.btn_order_rec.TabIndex = 42;
            this.btn_order_rec.Text = "Order Recieved";
            this.btn_order_rec.UseVisualStyleBackColor = false;
            this.btn_order_rec.Click += new System.EventHandler(this.btn_order_rec_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Location = new System.Drawing.Point(0, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1422, 294);
            this.panel2.TabIndex = 36;
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.Controls.Add(this.txt_address);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txt_c_id);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.txt_Email);
            this.groupBox2.Controls.Add(this.lbl_Email);
            this.groupBox2.Controls.Add(this.txt_Fax);
            this.groupBox2.Controls.Add(this.lbl_Fax);
            this.groupBox2.Controls.Add(this.txt_Tele);
            this.groupBox2.Controls.Add(this.lbl_Tele);
            this.groupBox2.Controls.Add(this.txt_Desig);
            this.groupBox2.Controls.Add(this.lbl_Desig);
            this.groupBox2.Controls.Add(this.txt_Cell);
            this.groupBox2.Controls.Add(this.lbl_Cell);
            this.groupBox2.Controls.Add(this.txt_Cont_Per);
            this.groupBox2.Controls.Add(this.lbl_Cont_Per);
            this.groupBox2.Controls.Add(this.txt_Comp_N);
            this.groupBox2.Controls.Add(this.lbl_Comp_N);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(1, 93);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox2.Size = new System.Drawing.Size(1415, 101);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CustomerDetails";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // txt_address
            // 
            this.txt_address.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_address.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_address.Location = new System.Drawing.Point(1017, 53);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(147, 22);
            this.txt_address.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(1016, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 16);
            this.label8.TabIndex = 1006;
            this.label8.Text = "Address";
            // 
            // txt_c_id
            // 
            this.txt_c_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_c_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_c_id.Location = new System.Drawing.Point(5, 53);
            this.txt_c_id.Name = "txt_c_id";
            this.txt_c_id.Size = new System.Drawing.Size(37, 22);
            this.txt_c_id.TabIndex = 1003;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(5, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 16);
            this.label6.TabIndex = 1002;
            this.label6.Text = "ID";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkCyan;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(1168, 30);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(131, 49);
            this.button3.TabIndex = 20;
            this.button3.Text = "Add New Customer";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkCyan;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(1304, 30);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 49);
            this.button4.TabIndex = 21;
            this.button4.Text = "Customer List";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txt_Email
            // 
            this.txt_Email.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_Email.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Email.Location = new System.Drawing.Point(868, 53);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(146, 22);
            this.txt_Email.TabIndex = 18;
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email.ForeColor = System.Drawing.Color.Black;
            this.lbl_Email.Location = new System.Drawing.Point(869, 31);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(42, 16);
            this.lbl_Email.TabIndex = 17;
            this.lbl_Email.Text = "Email";
            // 
            // txt_Fax
            // 
            this.txt_Fax.Location = new System.Drawing.Point(724, 53);
            this.txt_Fax.Name = "txt_Fax";
            this.txt_Fax.Size = new System.Drawing.Size(140, 22);
            this.txt_Fax.TabIndex = 17;
            // 
            // lbl_Fax
            // 
            this.lbl_Fax.AutoSize = true;
            this.lbl_Fax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fax.ForeColor = System.Drawing.Color.Black;
            this.lbl_Fax.Location = new System.Drawing.Point(723, 31);
            this.lbl_Fax.Name = "lbl_Fax";
            this.lbl_Fax.Size = new System.Drawing.Size(40, 16);
            this.lbl_Fax.TabIndex = 13;
            this.lbl_Fax.Text = "Fax #";
            // 
            // txt_Tele
            // 
            this.txt_Tele.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_Tele.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Tele.Location = new System.Drawing.Point(591, 53);
            this.txt_Tele.Name = "txt_Tele";
            this.txt_Tele.Size = new System.Drawing.Size(132, 22);
            this.txt_Tele.TabIndex = 16;
            // 
            // lbl_Tele
            // 
            this.lbl_Tele.AutoSize = true;
            this.lbl_Tele.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tele.ForeColor = System.Drawing.Color.Black;
            this.lbl_Tele.Location = new System.Drawing.Point(588, 31);
            this.lbl_Tele.Name = "lbl_Tele";
            this.lbl_Tele.Size = new System.Drawing.Size(74, 16);
            this.lbl_Tele.TabIndex = 9;
            this.lbl_Tele.Text = "Telephone";
            // 
            // txt_Desig
            // 
            this.txt_Desig.Location = new System.Drawing.Point(319, 53);
            this.txt_Desig.Name = "txt_Desig";
            this.txt_Desig.Size = new System.Drawing.Size(138, 22);
            this.txt_Desig.TabIndex = 14;
            // 
            // lbl_Desig
            // 
            this.lbl_Desig.AutoSize = true;
            this.lbl_Desig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Desig.ForeColor = System.Drawing.Color.Black;
            this.lbl_Desig.Location = new System.Drawing.Point(316, 30);
            this.lbl_Desig.Name = "lbl_Desig";
            this.lbl_Desig.Size = new System.Drawing.Size(80, 16);
            this.lbl_Desig.TabIndex = 7;
            this.lbl_Desig.Text = "Designation";
            // 
            // txt_Cell
            // 
            this.txt_Cell.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_Cell.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_Cell.Location = new System.Drawing.Point(462, 53);
            this.txt_Cell.Name = "txt_Cell";
            this.txt_Cell.Size = new System.Drawing.Size(126, 22);
            this.txt_Cell.TabIndex = 15;
            // 
            // lbl_Cell
            // 
            this.lbl_Cell.AutoSize = true;
            this.lbl_Cell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cell.ForeColor = System.Drawing.Color.Black;
            this.lbl_Cell.Location = new System.Drawing.Point(459, 30);
            this.lbl_Cell.Name = "lbl_Cell";
            this.lbl_Cell.Size = new System.Drawing.Size(41, 16);
            this.lbl_Cell.TabIndex = 5;
            this.lbl_Cell.Text = "Cell #";
            // 
            // lbl_Cont_Per
            // 
            this.lbl_Cont_Per.AutoSize = true;
            this.lbl_Cont_Per.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cont_Per.ForeColor = System.Drawing.Color.Black;
            this.lbl_Cont_Per.Location = new System.Drawing.Point(173, 30);
            this.lbl_Cont_Per.Name = "lbl_Cont_Per";
            this.lbl_Cont_Per.Size = new System.Drawing.Size(99, 16);
            this.lbl_Cont_Per.TabIndex = 3;
            this.lbl_Cont_Per.Text = "Contact Person";
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.button8);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.txt_issued);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txt_validity);
            this.groupBox1.Controls.Add(this.txt_T_Condition);
            this.groupBox1.Controls.Add(this.lbl_T_Condititon);
            this.groupBox1.Controls.Add(this.txt_Pay_Term);
            this.groupBox1.Controls.Add(this.lbl_Pay_Term);
            this.groupBox1.Controls.Add(this.lbl_Val_upto);
            this.groupBox1.Controls.Add(this.txt_Lead_Time);
            this.groupBox1.Controls.Add(this.lbl_Lead_Time);
            this.groupBox1.Controls.Add(this.txt_Subject);
            this.groupBox1.Controls.Add(this.lbl_Subject);
            this.groupBox1.Controls.Add(this.txt_Year);
            this.groupBox1.Controls.Add(this.lbl_Year);
            this.groupBox1.Controls.Add(this.txt_Update_Status);
            this.groupBox1.Controls.Add(this.lbl_Update_Status);
            this.groupBox1.Controls.Add(this.txt_Rev_Sta);
            this.groupBox1.Controls.Add(this.lbl_Rev_Sta);
            this.groupBox1.Controls.Add(this.txt_Quot_Num);
            this.groupBox1.Controls.Add(this.lbl_Quot_Num);
            this.groupBox1.Controls.Add(this.txt_Ref);
            this.groupBox1.Controls.Add(this.lbl_Ref);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(0, -3);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(1415, 113);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quotation Details";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkCyan;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(383, 11);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(72, 24);
            this.button8.TabIndex = 23;
            this.button8.Text = "Next";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkCyan;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(277, 11);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(72, 24);
            this.button7.TabIndex = 22;
            this.button7.Text = "Next";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // txt_issued
            // 
            this.txt_issued.CustomFormat = "dd/M/yyyy";
            this.txt_issued.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_issued.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_issued.Location = new System.Drawing.Point(914, 65);
            this.txt_issued.Name = "txt_issued";
            this.txt_issued.Size = new System.Drawing.Size(115, 22);
            this.txt_issued.TabIndex = 9;
            this.txt_issued.Value = new System.DateTime(2021, 12, 10, 0, 0, 0, 0);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(911, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "Issued At";
            // 
            // txt_validity
            // 
            this.txt_validity.CustomFormat = "dd/M/yyyy";
            this.txt_validity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_validity.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_validity.Location = new System.Drawing.Point(1035, 65);
            this.txt_validity.Name = "txt_validity";
            this.txt_validity.Size = new System.Drawing.Size(112, 22);
            this.txt_validity.TabIndex = 10;
            this.txt_validity.Value = new System.DateTime(2021, 12, 10, 0, 0, 0, 0);
            // 
            // txt_T_Condition
            // 
            this.txt_T_Condition.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_T_Condition.Location = new System.Drawing.Point(1151, 35);
            this.txt_T_Condition.Multiline = true;
            this.txt_T_Condition.Name = "txt_T_Condition";
            this.txt_T_Condition.Size = new System.Drawing.Size(250, 56);
            this.txt_T_Condition.TabIndex = 11;
            this.txt_T_Condition.Text = "\r\n";
            // 
            // lbl_T_Condititon
            // 
            this.lbl_T_Condititon.AutoSize = true;
            this.lbl_T_Condititon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_T_Condititon.ForeColor = System.Drawing.Color.Black;
            this.lbl_T_Condititon.Location = new System.Drawing.Point(1148, 13);
            this.lbl_T_Condititon.Name = "lbl_T_Condititon";
            this.lbl_T_Condititon.Size = new System.Drawing.Size(139, 16);
            this.lbl_T_Condititon.TabIndex = 19;
            this.lbl_T_Condititon.Text = "Terms and Conditions";
            // 
            // txt_Pay_Term
            // 
            this.txt_Pay_Term.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Pay_Term.Location = new System.Drawing.Point(782, 65);
            this.txt_Pay_Term.Name = "txt_Pay_Term";
            this.txt_Pay_Term.Size = new System.Drawing.Size(126, 22);
            this.txt_Pay_Term.TabIndex = 8;
            // 
            // lbl_Pay_Term
            // 
            this.lbl_Pay_Term.AutoSize = true;
            this.lbl_Pay_Term.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pay_Term.ForeColor = System.Drawing.Color.Black;
            this.lbl_Pay_Term.Location = new System.Drawing.Point(779, 40);
            this.lbl_Pay_Term.Name = "lbl_Pay_Term";
            this.lbl_Pay_Term.Size = new System.Drawing.Size(103, 16);
            this.lbl_Pay_Term.TabIndex = 17;
            this.lbl_Pay_Term.Text = "Payment Terms";
            // 
            // lbl_Val_upto
            // 
            this.lbl_Val_upto.AutoSize = true;
            this.lbl_Val_upto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Val_upto.ForeColor = System.Drawing.Color.Black;
            this.lbl_Val_upto.Location = new System.Drawing.Point(1032, 40);
            this.lbl_Val_upto.Name = "lbl_Val_upto";
            this.lbl_Val_upto.Size = new System.Drawing.Size(71, 16);
            this.lbl_Val_upto.TabIndex = 15;
            this.lbl_Val_upto.Text = "Valid Upto";
            // 
            // txt_Lead_Time
            // 
            this.txt_Lead_Time.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Lead_Time.Location = new System.Drawing.Point(685, 65);
            this.txt_Lead_Time.Name = "txt_Lead_Time";
            this.txt_Lead_Time.Size = new System.Drawing.Size(92, 22);
            this.txt_Lead_Time.TabIndex = 7;
            // 
            // lbl_Lead_Time
            // 
            this.lbl_Lead_Time.AutoSize = true;
            this.lbl_Lead_Time.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lead_Time.ForeColor = System.Drawing.Color.Black;
            this.lbl_Lead_Time.Location = new System.Drawing.Point(682, 40);
            this.lbl_Lead_Time.Name = "lbl_Lead_Time";
            this.lbl_Lead_Time.Size = new System.Drawing.Size(73, 16);
            this.lbl_Lead_Time.TabIndex = 13;
            this.lbl_Lead_Time.Text = "Lead Time";
            // 
            // txt_Subject
            // 
            this.txt_Subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Subject.Location = new System.Drawing.Point(574, 65);
            this.txt_Subject.Name = "txt_Subject";
            this.txt_Subject.Size = new System.Drawing.Size(107, 22);
            this.txt_Subject.TabIndex = 6;
            // 
            // lbl_Subject
            // 
            this.lbl_Subject.AutoSize = true;
            this.lbl_Subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subject.ForeColor = System.Drawing.Color.Black;
            this.lbl_Subject.Location = new System.Drawing.Point(571, 40);
            this.lbl_Subject.Name = "lbl_Subject";
            this.lbl_Subject.Size = new System.Drawing.Size(53, 16);
            this.lbl_Subject.TabIndex = 11;
            this.lbl_Subject.Text = "Subject";
            // 
            // txt_Year
            // 
            this.txt_Year.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Year.Location = new System.Drawing.Point(502, 65);
            this.txt_Year.Name = "txt_Year";
            this.txt_Year.Size = new System.Drawing.Size(67, 22);
            this.txt_Year.TabIndex = 5;
            this.txt_Year.TextChanged += new System.EventHandler(this.txt_Year_TextChanged);
            // 
            // lbl_Year
            // 
            this.lbl_Year.AutoSize = true;
            this.lbl_Year.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Year.ForeColor = System.Drawing.Color.Black;
            this.lbl_Year.Location = new System.Drawing.Point(498, 40);
            this.lbl_Year.Name = "lbl_Year";
            this.lbl_Year.Size = new System.Drawing.Size(37, 16);
            this.lbl_Year.TabIndex = 9;
            this.lbl_Year.Text = "Year";
            // 
            // txt_Update_Status
            // 
            this.txt_Update_Status.Enabled = false;
            this.txt_Update_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Update_Status.Location = new System.Drawing.Point(277, 65);
            this.txt_Update_Status.Name = "txt_Update_Status";
            this.txt_Update_Status.Size = new System.Drawing.Size(103, 22);
            this.txt_Update_Status.TabIndex = 3;
            this.txt_Update_Status.Text = "0";
            this.txt_Update_Status.TextChanged += new System.EventHandler(this.txt_Update_Status_TextChanged);
            // 
            // lbl_Update_Status
            // 
            this.lbl_Update_Status.AutoSize = true;
            this.lbl_Update_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Update_Status.ForeColor = System.Drawing.Color.Black;
            this.lbl_Update_Status.Location = new System.Drawing.Point(276, 41);
            this.lbl_Update_Status.Name = "lbl_Update_Status";
            this.lbl_Update_Status.Size = new System.Drawing.Size(93, 16);
            this.lbl_Update_Status.TabIndex = 7;
            this.lbl_Update_Status.Text = "Update Status";
            // 
            // txt_Rev_Sta
            // 
            this.txt_Rev_Sta.Enabled = false;
            this.txt_Rev_Sta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Rev_Sta.Location = new System.Drawing.Point(383, 65);
            this.txt_Rev_Sta.Name = "txt_Rev_Sta";
            this.txt_Rev_Sta.Size = new System.Drawing.Size(114, 22);
            this.txt_Rev_Sta.TabIndex = 4;
            this.txt_Rev_Sta.Text = "0";
            this.txt_Rev_Sta.TextChanged += new System.EventHandler(this.txt_Rev_Sta_TextChanged);
            // 
            // lbl_Rev_Sta
            // 
            this.lbl_Rev_Sta.AutoSize = true;
            this.lbl_Rev_Sta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rev_Sta.ForeColor = System.Drawing.Color.Black;
            this.lbl_Rev_Sta.Location = new System.Drawing.Point(384, 40);
            this.lbl_Rev_Sta.Name = "lbl_Rev_Sta";
            this.lbl_Rev_Sta.Size = new System.Drawing.Size(101, 16);
            this.lbl_Rev_Sta.TabIndex = 5;
            this.lbl_Rev_Sta.Text = "Revision Status";
            // 
            // txt_Quot_Num
            // 
            this.txt_Quot_Num.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Quot_Num.Location = new System.Drawing.Point(151, 65);
            this.txt_Quot_Num.Name = "txt_Quot_Num";
            this.txt_Quot_Num.Size = new System.Drawing.Size(123, 22);
            this.txt_Quot_Num.TabIndex = 2;
            // 
            // lbl_Quot_Num
            // 
            this.lbl_Quot_Num.AutoSize = true;
            this.lbl_Quot_Num.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quot_Num.ForeColor = System.Drawing.Color.Black;
            this.lbl_Quot_Num.Location = new System.Drawing.Point(149, 41);
            this.lbl_Quot_Num.Name = "lbl_Quot_Num";
            this.lbl_Quot_Num.Size = new System.Drawing.Size(116, 16);
            this.lbl_Quot_Num.TabIndex = 3;
            this.lbl_Quot_Num.Text = "Quotation Number";
            // 
            // txt_Ref
            // 
            this.txt_Ref.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Ref.Location = new System.Drawing.Point(5, 65);
            this.txt_Ref.Name = "txt_Ref";
            this.txt_Ref.Size = new System.Drawing.Size(143, 22);
            this.txt_Ref.TabIndex = 1;
            this.txt_Ref.Text = "0";
            // 
            // lbl_Ref
            // 
            this.lbl_Ref.AutoSize = true;
            this.lbl_Ref.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ref.ForeColor = System.Drawing.Color.Black;
            this.lbl_Ref.Location = new System.Drawing.Point(3, 41);
            this.lbl_Ref.Name = "lbl_Ref";
            this.lbl_Ref.Size = new System.Drawing.Size(81, 16);
            this.lbl_Ref.TabIndex = 0;
            this.lbl_Ref.Text = "Reference #";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lbl_date);
            this.panel1.Controls.Add(this.lbl_time);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1586, 50);
            this.panel1.TabIndex = 34;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 15.75F);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(1247, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(152, 24);
            this.label12.TabIndex = 38;
            this.label12.Text = "user_logged_in";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 15.75F);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(1190, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 24);
            this.label13.TabIndex = 37;
            this.label13.Text = "User:";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(675, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Preview Quotation";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Preview_Quote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1424, 841);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panlel_grid_3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Preview_Quote";
            this.Text = "Preview_Quote";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Preview_Quote_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.product_table_pdf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Products_Table)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panlel_grid_3.ResumeLayout(false);
            this.panlel_grid_3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtGSTAmount;
        private System.Windows.Forms.TextBox txt_p_id;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lbl_Quantity;
        private System.Windows.Forms.TextBox txtUnitPrice;
        private System.Windows.Forms.Label lbl_Unit_Price;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtUnit;
        private System.Windows.Forms.Label lbl_Unit;
        private System.Windows.Forms.TextBox txtPsize;
        private System.Windows.Forms.Label lbl_Size;
        private System.Windows.Forms.Label lbl_Desc;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtTotalPriceGST;
        private System.Windows.Forms.TextBox txtGST;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lbl_Comp_N;
        private System.Windows.Forms.TextBox txt_total_price;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panlel_grid_3;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_c_id;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.TextBox txt_Fax;
        private System.Windows.Forms.Label lbl_Fax;
        private System.Windows.Forms.TextBox txt_Tele;
        private System.Windows.Forms.Label lbl_Tele;
        private System.Windows.Forms.TextBox txt_Desig;
        private System.Windows.Forms.Label lbl_Desig;
        private System.Windows.Forms.TextBox txt_Cell;
        private System.Windows.Forms.Label lbl_Cell;
        private System.Windows.Forms.Label lbl_Cont_Per;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_T_Condition;
        private System.Windows.Forms.Label lbl_T_Condititon;
        private System.Windows.Forms.TextBox txt_Pay_Term;
        private System.Windows.Forms.Label lbl_Pay_Term;
        private System.Windows.Forms.Label lbl_Val_upto;
        private System.Windows.Forms.TextBox txt_Lead_Time;
        private System.Windows.Forms.Label lbl_Lead_Time;
        private System.Windows.Forms.Label lbl_Subject;
        private System.Windows.Forms.TextBox txt_Year;
        private System.Windows.Forms.Label lbl_Year;
        private System.Windows.Forms.Label lbl_Update_Status;
        private System.Windows.Forms.Label lbl_Rev_Sta;
        private System.Windows.Forms.Label lbl_Quot_Num;
        private System.Windows.Forms.Label lbl_Ref;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txt_Quot_Num;
        public System.Windows.Forms.TextBox txt_Update_Status;
        public System.Windows.Forms.TextBox txt_Rev_Sta;
        public System.Windows.Forms.TextBox txt_Ref;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_order_rec;
        private System.Windows.Forms.Label lbl_approved_by;
        private System.Windows.Forms.Label lbl_created_by;
        private System.Windows.Forms.Label lbl_created;
        private System.Windows.Forms.ComboBox combo_approved;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        public System.Windows.Forms.ComboBox txt_desc;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_discount_price;
        private System.Windows.Forms.Label lbl_discount;
        private System.Windows.Forms.TextBox txt_Discount;
        private System.Windows.Forms.TextBox txt_disc_price;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_disc;
        private System.Windows.Forms.TextBox txt_discount_price;
        private System.Windows.Forms.DataGridView product_table_pdf;
        private System.Windows.Forms.TextBox txt_product_no;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView Products_Table;
        private System.Windows.Forms.Button button9;
        public System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_note2;
        private System.Windows.Forms.TextBox txt_note1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_recived;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_remain;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_percentage;
        private System.Windows.Forms.TextBox unit_txt;
        public System.Windows.Forms.TextBox txt_Comp_N;
        public System.Windows.Forms.TextBox txt_Cont_Per;
        public System.Windows.Forms.DateTimePicker txt_issued;
        public System.Windows.Forms.DateTimePicker txt_validity;
        public System.Windows.Forms.TextBox txt_Subject;
    }
}