﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace Quotation_management_system
{
    public partial class AddCustomers : Form
    {
        private MySqlConnection con;
        public AddCustomers()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =star_corp_qms; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
           //  con = new MySqlConnection("Server =192.168.100.111; Port =3306; Database =star_corp_qms; user=star_corporation; password =star@12345; Connection Reset=false;convert zero datetime = True;SslMode=None;");
         
        }

        private void button1_Click(object sender, EventArgs e)  
        {
            // '" + txt_Comp_name.Text + "','" + txt_cont_per.Text + "','" + txt_Desg.Text + "','" + txt_cell.Text + "','" + txt_tel.Text + "','" + txt_fax.Text + "','" + txt_email.Text + "'
            try
            {
               // string query = "`add_customer`(@companyname,@contactperson,@designation,@cellnum,@telnum,@faxnum,@email)";
               // INSERT INTO customer(company_name, contact_person, designation, cell_num, tel_num, fax_num, email) VALUES(@companyname, @contactperson, @designation, @cellnum, @telnum, @faxnum, @email)
               
                MySqlParameter[] pms = new MySqlParameter[8];
                pms[0] = new MySqlParameter("companyname", MySqlDbType.VarChar);
                pms[0].Value = txt_Comp_name.Text;      
                pms[1] = new MySqlParameter("contactperson", MySqlDbType.VarChar);
                pms[1].Value = txt_cont_per.Text;
                pms[2] = new MySqlParameter("designation", MySqlDbType.VarChar);
                pms[2].Value = txt_Desg.Text;
                pms[3] = new MySqlParameter("cellnum", MySqlDbType.VarChar);
                pms[3].Value = txt_cell.Text;
                pms[4] = new MySqlParameter("telnum", MySqlDbType.VarChar);
                pms[4].Value = txt_tel.Text;
                pms[5] = new MySqlParameter("faxnum", MySqlDbType.VarChar);
                pms[5].Value = txt_fax.Text;
                pms[6] = new MySqlParameter("email", MySqlDbType.VarChar);
                pms[6].Value = txt_email.Text;
                pms[7] = new MySqlParameter("address", MySqlDbType.VarChar);
                pms[7].Value = txt_address.Text;

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "add_customer";
                cmd.Parameters.AddRange(pms);

                con.Open();
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();

                //cmd.Parameters.AddWithValue("@companyname", txt_Comp_name.Text);
                //cmd.Parameters.AddWithValue("@contactperson", txt_cont_per.Text);
                //cmd.Parameters.AddWithValue("@designation", txt_Desg.Text);
                //cmd.Parameters.AddWithValue("@cellnum", txt_cell.Text);
                //cmd.Parameters.AddWithValue("@telnum", txt_tel.Text);
                //cmd.Parameters.AddWithValue("@faxnum", txt_fax.Text);
                //cmd.Parameters.AddWithValue("@email", txt_email.Text);
   

                MessageBox.Show("New customer is successfully saved in database", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txt_Comp_name.Clear();
                txt_cont_per.Clear();
                txt_address.Clear();
                txt_Desg.Clear();
                txt_cell.Clear();
                txt_tel.Clear();
                txt_fax.Clear();
                txt_email.Clear();

                if (Application.OpenForms.OfType<New_Quote>().Any())
                { 
                New_Quote master = (New_Quote)Application.OpenForms["New_Quote"];
                master.customer_name_search();
                }
                else
                {

                }
               
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
            bind_New_Quote_customer();
        }

        private void AddCustomers_Load(object sender, EventArgs e)
        {
            bind_New_Quote_customer();
        }
        private void bind_New_Quote_customer()
        {
            //SELECT MAX(c_id)+1 AS c_id FROM quotations
            using (MySqlCommand cmd = new MySqlCommand("SELECT MAX(c_id)+1 AS c_id FROM customer ", con))
            {
                cmd.CommandType = CommandType.Text;
                con.Open();
                txtid.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
